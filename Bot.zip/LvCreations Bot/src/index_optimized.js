const {
  ActionRowBuilder,
  ActivityType,
  ButtonBuilder,
  ButtonStyle,
  Client,
  EmbedBuilder,
  Events,
  GatewayIntentBits,
  Partials,
  PermissionFlagsBits,
  REST,
  Routes,
  SlashCommandBuilder,
  ChannelType
} = require('discord.js');
const {
  AudioPlayerStatus,
  createAudioPlayer,
  createAudioResource,
  entersState,
  joinVoiceChannel,
  VoiceConnectionStatus
} = require('@discordjs/voice');
const play = require('play-dl');
const config = require('./config');
const storage = require('./storage');
const crypto = require('crypto');

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessageReactions,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.DirectMessages
  ],
  partials: [Partials.Message, Partials.Channel, Partials.Reaction]
});

// Global state management
const queues = new Map();
const joinTimes = new Map();
const raidModeUntil = new Map();
const captchaCodes = new Map();
const levelCooldowns = new Map();
const warns = new Map();
const reminders = new Map();
const pollVotes = new Map();

const statuses = [
  { name: '/help - Aide Complète', type: ActivityType.Watching },
  { name: 'LvCreations Bot v2.0', type: ActivityType.Playing },
  { name: '43+ Commandes', type: ActivityType.Watching },
  { name: 'Discord Bot Pro', type: ActivityType.Playing },
  { name: 'Musique, Modération & Plus', type: ActivityType.Watching },
  { name: '/play pour la Musique', type: ActivityType.Listening },
  { name: 'tes Serveurs', type: ActivityType.Watching },
  { name: 'Modération Avancée', type: ActivityType.Playing },
  { name: 'Raid Protection 🛡️', type: ActivityType.Watching },
  { name: 'Giveaways & Tickets', type: ActivityType.Playing }
];

let currentStatusIndex = 0;
let botStartTime = Date.now();
const botLogs = [];
let statusInterval = null;
let voiceConnectInterval = null;

const addLog = (message) => {
  try {
    const timestamp = new Date().toLocaleString('fr-FR');
    const log = `[${timestamp}] ${message}`;
    botLogs.push(log);
    if (botLogs.length > 100) botLogs.shift();
    console.log(log);
  } catch (error) {
    console.error('Erreur logging:', error.message);
  }
};

// ============ COMMAND DEFINITIONS ============
const commands = [
  new SlashCommandBuilder().setName('kick').setDescription('Kick un membre').addUserOption(opt => opt.setName('membre').setDescription('Membre').setRequired(true)).addStringOption(opt => opt.setName('raison').setDescription('Raison')).setDefaultMemberPermissions(PermissionFlagsBits.KickMembers),
  new SlashCommandBuilder().setName('ban').setDescription('Ban un membre').addUserOption(opt => opt.setName('membre').setDescription('Membre').setRequired(true)).addStringOption(opt => opt.setName('raison').setDescription('Raison')).setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),
  new SlashCommandBuilder().setName('timeout').setDescription('Timeout un membre').addUserOption(opt => opt.setName('membre').setDescription('Membre').setRequired(true)).addStringOption(opt => opt.setName('duree').setDescription('10m, 2h, 1d').setRequired(true)).addStringOption(opt => opt.setName('raison').setDescription('Raison')).setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),
  new SlashCommandBuilder().setName('untimeout').setDescription('Retirer un timeout').addUserOption(opt => opt.setName('membre').setDescription('Membre').setRequired(true)).setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),
  new SlashCommandBuilder().setName('clear').setDescription('Supprimer des messages').addIntegerOption(opt => opt.setName('nombre').setDescription('Nombre').setRequired(true)).setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),
  new SlashCommandBuilder().setName('ticket').setDescription('Créer ou fermer un ticket').addStringOption(opt => opt.setName('action').setDescription('create/close').setRequired(true).addChoices({ name: 'create', value: 'create' }, { name: 'close', value: 'close' })),
  new SlashCommandBuilder().setName('ticketpanel').setDescription('Envoyer un panneau de tickets').setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
  new SlashCommandBuilder().setName('verify').setDescription('Valider le captcha').addStringOption(opt => opt.setName('code').setDescription('Code').setRequired(true)),
  new SlashCommandBuilder().setName('raidmode').setDescription('Activer/désactiver le raid mode').addStringOption(opt => opt.setName('action').setDescription('on/off').setRequired(true).addChoices({ name: 'on', value: 'on' }, { name: 'off', value: 'off' })).setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
  new SlashCommandBuilder().setName('rank').setDescription('Voir le niveau').addUserOption(opt => opt.setName('membre').setDescription('Membre')),
  new SlashCommandBuilder().setName('giveaway').setDescription('Lancer un giveaway').addStringOption(opt => opt.setName('duree').setDescription('10m, 2h, 1d').setRequired(true)).addIntegerOption(opt => opt.setName('gagnants').setDescription('Nombre').setRequired(true)).addStringOption(opt => opt.setName('prix').setDescription('Prix').setRequired(true)).setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
  new SlashCommandBuilder().setName('reroll').setDescription('Reroll un giveaway').addStringOption(opt => opt.setName('message_id').setDescription('ID du message').setRequired(true)).addIntegerOption(opt => opt.setName('gagnants').setDescription('Nombre').setRequired(false)).setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
  new SlashCommandBuilder().setName('rr').setDescription('Reaction roles').addStringOption(opt => opt.setName('action').setDescription('add/remove').setRequired(true).addChoices({ name: 'add', value: 'add' }, { name: 'remove', value: 'remove' })).addStringOption(opt => opt.setName('message_id').setDescription('ID du message').setRequired(true)).addStringOption(opt => opt.setName('emoji').setDescription('Emoji').setRequired(true)).addRoleOption(opt => opt.setName('role').setDescription('Rôle').setRequired(true)).setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles),
  new SlashCommandBuilder().setName('join').setDescription('Rejoindre le vocal'),
  new SlashCommandBuilder().setName('leave').setDescription('Quitter le vocal'),
  new SlashCommandBuilder().setName('play').setDescription('Jouer une musique').addStringOption(opt => opt.setName('query').setDescription('Lien ou recherche').setRequired(true)),
  new SlashCommandBuilder().setName('pause').setDescription('Pause la musique'),
  new SlashCommandBuilder().setName('resume').setDescription('Reprendre la musique'),
  new SlashCommandBuilder().setName('skip').setDescription('Passer la musique'),
  new SlashCommandBuilder().setName('stop').setDescription('Stopper la musique'),
  new SlashCommandBuilder().setName('queue').setDescription('Afficher la file'),
  new SlashCommandBuilder().setName('warn').setDescription('Avertir un membre').addUserOption(opt => opt.setName('membre').setDescription('Membre').setRequired(true)).addStringOption(opt => opt.setName('raison').setDescription('Raison').setRequired(true)).setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),
  new SlashCommandBuilder().setName('warns').setDescription('Voir les avertissements').addUserOption(opt => opt.setName('membre').setDescription('Membre')),
  new SlashCommandBuilder().setName('clearwarn').setDescription('Effacer les avertissements').addUserOption(opt => opt.setName('membre').setDescription('Membre').setRequired(true)).setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),
  new SlashCommandBuilder().setName('mute').setDescription('Mute un membre en vocal').addUserOption(opt => opt.setName('membre').setDescription('Membre').setRequired(true)).setDefaultMemberPermissions(PermissionFlagsBits.MuteMembers),
  new SlashCommandBuilder().setName('unmute').setDescription('Unmute un membre en vocal').addUserOption(opt => opt.setName('membre').setDescription('Membre').setRequired(true)).setDefaultMemberPermissions(PermissionFlagsBits.MuteMembers),
  new SlashCommandBuilder().setName('remind').setDescription('Créer un rappel').addStringOption(opt => opt.setName('duree').setDescription('10m, 2h, 1d').setRequired(true)).addStringOption(opt => opt.setName('message').setDescription('Message').setRequired(true)),
  new SlashCommandBuilder().setName('poll').setDescription('Créer un sondage').addStringOption(opt => opt.setName('question').setDescription('Question').setRequired(true)).addStringOption(opt => opt.setName('option1').setDescription('Option 1').setRequired(true)).addStringOption(opt => opt.setName('option2').setDescription('Option 2').setRequired(true)).addStringOption(opt => opt.setName('option3').setDescription('Option 3').setRequired(false)).addStringOption(opt => opt.setName('option4').setDescription('Option 4').setRequired(false)),
  new SlashCommandBuilder().setName('userinfo').setDescription('Info sur un utilisateur').addUserOption(opt => opt.setName('membre').setDescription('Membre')),
  new SlashCommandBuilder().setName('serverinfo').setDescription('Info sur le serveur'),
  new SlashCommandBuilder().setName('avatar').setDescription('Afficher l\'avatar').addUserOption(opt => opt.setName('membre').setDescription('Membre')),
  new SlashCommandBuilder().setName('ping').setDescription('Latence du bot'),
  new SlashCommandBuilder().setName('help').setDescription('Liste des commandes'),
  new SlashCommandBuilder().setName('announce').setDescription('Faire une annonce').addStringOption(opt => opt.setName('titre').setDescription('Titre').setRequired(true)).addStringOption(opt => opt.setName('message').setDescription('Message').setRequired(true)).addChannelOption(opt => opt.setName('canal').setDescription('Canal').setRequired(false)).setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
  new SlashCommandBuilder().setName('stats').setDescription('Statistiques du serveur'),
  new SlashCommandBuilder().setName('suggestion').setDescription('Faire une suggestion').addStringOption(opt => opt.setName('titre').setDescription('Titre').setRequired(true)).addStringOption(opt => opt.setName('description').setDescription('Description').setRequired(true)),
  new SlashCommandBuilder().setName('setup').setDescription('Configuration du serveur').addStringOption(opt => opt.setName('option').setDescription('Quoi configurer').setRequired(true).addChoices({ name: 'log-channel', value: 'logchannel' }, { name: 'welcome-channel', value: 'welcomechannel' }, { name: 'level-channel', value: 'levelchannel' }, { name: 'ticket-category', value: 'ticketcategory' })).addChannelOption(opt => opt.setName('canal').setDescription('Canal/Catégorie').setRequired(true)).setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
  new SlashCommandBuilder().setName('8ball').setDescription('Question à la boule magique').addStringOption(opt => opt.setName('question').setDescription('Ta question').setRequired(true)),
  new SlashCommandBuilder().setName('dice').setDescription('Lancer un dé').addIntegerOption(opt => opt.setName('faces').setDescription('Nombre de faces').setRequired(false)),
  new SlashCommandBuilder().setName('report').setDescription('Signaler un utilisateur').addUserOption(opt => opt.setName('utilisateur').setDescription('Utilisateur').setRequired(true)).addStringOption(opt => opt.setName('raison').setDescription('Raison').setRequired(true)),
  new SlashCommandBuilder().setName('bug').setDescription('Signaler un bug').addStringOption(opt => opt.setName('description').setDescription('Description du bug').setRequired(true)),
  new SlashCommandBuilder().setName('joke').setDescription('Une blague aléatoire'),
  new SlashCommandBuilder().setName('quote').setDescription('Une citation aléatoire'),
  new SlashCommandBuilder().setName('slots').setDescription('Jeu des machines à sous'),
  new SlashCommandBuilder().setName('rps').setDescription('Pierre-Papier-Ciseaux').addStringOption(opt => opt.setName('choix').setDescription('Ton choix').setRequired(true).addChoices({ name: 'Pierre', value: 'pierre' }, { name: 'Papier', value: 'papier' }, { name: 'Ciseaux', value: 'ciseaux' })),
  new SlashCommandBuilder().setName('calc').setDescription('Calculatrice').addStringOption(opt => opt.setName('expression').setDescription('Ex: 5+3*2').setRequired(true)),
  new SlashCommandBuilder().setName('afk').setDescription('Mettre un statut AFK').addStringOption(opt => opt.setName('raison').setDescription('Raison').setRequired(false)),
  new SlashCommandBuilder().setName('color').setDescription('Créer une couleur personnalisée').addStringOption(opt => opt.setName('nom').setDescription('Nom de la couleur').setRequired(true)).addStringOption(opt => opt.setName('hex').setDescription('Couleur hex (ex: FF0000)').setRequired(true)).setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles),
  new SlashCommandBuilder().setName('botinfo').setDescription('Infos sur le bot'),
  new SlashCommandBuilder().setName('uptime').setDescription('Durée d\'activité du bot'),
  new SlashCommandBuilder().setName('setstatus').setDescription('Changer le statut du bot').addStringOption(opt => opt.setName('statut').setDescription('Nouveau statut').setRequired(true)).setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
  new SlashCommandBuilder().setName('reload').setDescription('Redémarrer le bot').setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
  new SlashCommandBuilder().setName('poweroff').setDescription('Arrêter le bot').setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
  new SlashCommandBuilder().setName('eval').setDescription('Exécuter du code (Admin uniquement)').addStringOption(opt => opt.setName('code').setDescription('Code à exécuter').setRequired(true)).setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
  new SlashCommandBuilder().setName('logs').setDescription('Voir les derniers logs du bot').setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
].map(cmd => cmd.toJSON());

// ============ UTILITY FUNCTIONS ============
const parseDuration = (value) => {
  if (!value) return null;
  const unit = value.slice(-1);
  const amount = Number.parseInt(value.slice(0, -1), 10);
  if (!['s', 'm', 'h', 'd'].includes(unit) || Number.isNaN(amount) || amount <= 0) return null;
  const seconds = { s: amount, m: amount * 60, h: amount * 3600, d: amount * 86400 }[unit];
  return seconds;
};

const ensureGuildQueue = (guildId) => {
  if (!queues.has(guildId)) {
    const player = createAudioPlayer();
    queues.set(guildId, { player, tracks: [], connection: null, textChannelId: null });
  }
  return queues.get(guildId);
};

const playNext = async (guildId) => {
  try {
    const queue = ensureGuildQueue(guildId);
    if (!queue || !queue.tracks.length) return;

    const track = queue.tracks.shift();
    if (!track || !track.url) return;

    try {
      const stream = await play.stream(track.url);
      const resource = createAudioResource(stream.stream, { inputType: stream.type });
      queue.player.play(resource);

      queue.player.once(AudioPlayerStatus.Idle, () => playNext(guildId).catch(() => {}));

      if (queue.textChannelId) {
        const channel = await client.channels.fetch(queue.textChannelId).catch(() => null);
        if (channel?.isTextBased()) {
          channel.send(`🎵 Lecture: **${track.title || 'Chanson'}**`).catch(() => {});
        }
      }
    } catch (error) {
      addLog(`Erreur stream: ${error.message}`);
      playNext(guildId).catch(() => {});
    }
  } catch (error) {
    addLog(`Erreur playNext: ${error.message}`);
  }
};

const connectToVoice = async (interaction) => {
  try {
    const member = await interaction.guild.members.fetch(interaction.user.id).catch(() => null);
    if (!member?.voice?.channel) {
      await interaction.reply({ content: '❌ Tu dois être en vocal.', ephemeral: true });
      return null;
    }

    const voiceChannel = member.voice.channel;
    const queue = ensureGuildQueue(interaction.guild.id);
    
    if (queue.connection && queue.connection.state.status !== VoiceConnectionStatus.Destroyed) {
      return queue;
    }

    const connection = joinVoiceChannel({
      channelId: voiceChannel.id,
      guildId: voiceChannel.guild.id,
      adapterCreator: voiceChannel.guild.voiceAdapterCreator
    });

    await entersState(connection, VoiceConnectionStatus.Ready, 20_000).catch(() => null);
    connection.subscribe(queue.player);
    queue.connection = connection;
    return queue;
  } catch (error) {
    addLog(`Erreur connectToVoice: ${error.message}`);
    return null;
  }
};

const sendCaptcha = async (member, code) => {
  try {
    const message = `Bienvenue ${member.user.username} !\nPour vérifier ton compte: /verify code: ${code}\nExpiration: ${config.CAPTCHA_EXPIRE_SECONDS}s`;
    await member.send(message).catch(() => {});
    
    if (config.CAPTCHA_CHANNEL_ID) {
      const channel = member.guild.channels.cache.get(String(config.CAPTCHA_CHANNEL_ID));
      if (channel?.isTextBased()) {
        channel.send(`${member} ${message}`).catch(() => {});
      }
    }
  } catch (error) {
    addLog(`Erreur sendCaptcha: ${error.message}`);
  }
};

const applyCaptchaRoles = async (member) => {
  try {
    if (config.UNVERIFIED_ROLE_ID) {
      const role = member.guild.roles.cache.get(String(config.UNVERIFIED_ROLE_ID));
      if (role) await member.roles.add(role).catch(() => {});
    }
    if (config.VERIFIED_ROLE_ID) {
      const role = member.guild.roles.cache.get(String(config.VERIFIED_ROLE_ID));
      if (role) await member.roles.remove(role).catch(() => {});
    }
  } catch (error) {
    addLog(`Erreur applyCaptchaRoles: ${error.message}`);
  }
};

const getLogChannel = (guild) => {
  if (!config.LOG_CHANNEL_ID) return null;
  return guild.channels.cache.get(String(config.LOG_CHANNEL_ID)) || null;
};

const createTicketChannel = async (guild, user) => {
  try {
    let category = null;
    if (config.TICKET_CATEGORY_ID) {
      const channel = guild.channels.cache.get(String(config.TICKET_CATEGORY_ID));
      if (channel?.isCategory?.()) category = channel;
    }
    
    if (!category) {
      category = await guild.channels.create({ name: 'Tickets', type: ChannelType.GuildCategory }).catch(() => null);
    }

    if (!category) return null;

    const overwrites = [
      { id: guild.roles.everyone.id, deny: ['ViewChannel'] },
      { id: user.id, allow: ['ViewChannel', 'SendMessages'] }
    ];

    if (config.STAFF_ROLE_ID) {
      overwrites.push({ id: String(config.STAFF_ROLE_ID), allow: ['ViewChannel', 'SendMessages'] });
    }

    const channel = await guild.channels.create({
      name: `ticket-${user.username.toLowerCase()}`,
      type: ChannelType.GuildText,
      parent: category.id,
      permissionOverwrites: overwrites
    }).catch(() => null);

    if (!channel) return null;

    storage.setTicket(channel.id, user.id, 'open');

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('ticket_close').setLabel('Fermer le ticket').setStyle(ButtonStyle.Danger)
    );

    await channel.send({ content: `${user} ticket créé.`, components: [row] }).catch(() => {});
    return channel;
  } catch (error) {
    addLog(`Erreur createTicketChannel: ${error.message}`);
    return null;
  }
};

const registerCommands = async () => {
  if (!config.DISCORD_TOKEN || !config.CLIENT_ID) {
    console.error('❌ DISCORD_TOKEN ou CLIENT_ID manquant');
    return;
  }

  const rest = new REST({ version: '10' }).setToken(config.DISCORD_TOKEN);
  
  try {
    if (config.GUILD_ID && config.SYNC_COMMANDS) {
      console.log(`📤 Synchronisation au serveur ${config.GUILD_ID}...`);
      await rest.put(Routes.applicationGuildCommands(config.CLIENT_ID, String(config.GUILD_ID)), { body: commands });
      console.log(`✅ Commandes synchronisées !`);
      return;
    }
    
    console.log(`📤 Synchronisation globale...`);
    await rest.put(Routes.applicationCommands(config.CLIENT_ID), { body: commands });
    console.log(`✅ Commandes synchronisées globalement !`);
  } catch (error) {
    console.error(`❌ Erreur sync:`, error.message);
    
    try {
      console.log(`🔄 Fallback: synchro globale...`);
      await rest.put(Routes.applicationCommands(config.CLIENT_ID), { body: commands });
      console.log(`✅ Fallback réussi !`);
    } catch (fallbackError) {
      console.error(`❌ Fallback échoué:`, fallbackError.message);
    }
  }
};

// ============ CLIENT EVENTS ============
client.once(Events.ClientReady, async () => {
  await registerCommands();
  console.log(`✅ Connecté en tant que ${client.user.tag}`);
  
  // Status rotation
  const changeStatus = () => {
    try {
      const status = statuses[currentStatusIndex];
      client.user.setActivity(status.name, { type: status.type }).catch(() => {});
      currentStatusIndex = (currentStatusIndex + 1) % statuses.length;
    } catch (error) {
      addLog(`Erreur status: ${error.message}`);
    }
  };
  
  changeStatus();
  if (statusInterval) clearInterval(statusInterval);
  statusInterval = setInterval(changeStatus, 2 * 60 * 1000);
  console.log(`✅ Système de statuts activé`);
  
  // 24h voice connection
  if (config.VOICE_CHANNEL_24H) {
    const connectTo24hVoice = async () => {
      try {
        const channel = await client.channels.fetch(String(config.VOICE_CHANNEL_24H)).catch(() => null);
        if (!channel?.isVoiceBased?.()) return;
        
        const queue = ensureGuildQueue(channel.guildId);
        if (queue.connection?.state.status !== VoiceConnectionStatus.Destroyed) return;
        
        const connection = joinVoiceChannel({
          channelId: channel.id,
          guildId: channel.guild.id,
          adapterCreator: channel.guild.voiceAdapterCreator
        });
        
        await entersState(connection, VoiceConnectionStatus.Ready, 20_000).catch(() => null);
        connection.subscribe(queue.player);
        queue.connection = connection;
        
        console.log(`🎤 24h connecté: ${channel.name}`);
        
        connection.on(VoiceConnectionStatus.Disconnected, async () => {
          try {
            await Promise.race([
              entersState(connection, VoiceConnectionStatus.Signalling, 5_000),
              entersState(connection, VoiceConnectionStatus.Connecting, 5_000)
            ]);
          } catch (error) {
            console.log(`🔄 Reconnexion 24h...`);
            setTimeout(connectTo24hVoice, 5000);
          }
        });
      } catch (error) {
        addLog(`Erreur 24h: ${error.message}`);
      }
    };
    
    connectTo24hVoice();
  }
});

client.on(Events.GuildMemberAdd, async (member) => {
  try {
    const guildId = member.guild.id;
    const now = Date.now();
    const window = (config.RAID_WINDOW_SECONDS || 20) * 1000;
    const list = joinTimes.get(guildId) || [];
    list.push(now);
    joinTimes.set(guildId, list.filter(t => t >= now - window));

    if (config.RAID_MAX_JOINS && config.RAID_MODE_DURATION && joinTimes.get(guildId).length >= config.RAID_MAX_JOINS) {
      raidModeUntil.set(guildId, Date.now() + config.RAID_MODE_DURATION * 1000);
    }

    if (raidModeUntil.get(guildId) && Date.now() < raidModeUntil.get(guildId)) {
      if (config.RAID_ACTION === 'kick') {
        member.kick('Raid protection').catch(() => {});
        return;
      }
    }

    if (config.WELCOME_CHANNEL_ID) {
      const channel = member.guild.channels.cache.get(String(config.WELCOME_CHANNEL_ID));
      if (channel?.isTextBased?.()) {
        const embed = new EmbedBuilder().setTitle('Bienvenue').setDescription(`Bienvenue ${member} !`).setColor(0x57F287);
        channel.send({ embeds: [embed] }).catch(() => {});
      }
    }

    if (!config.CAPTCHA_ENABLED) return;

    const code = crypto.randomBytes(3).toString('hex');
    const expiresAt = Date.now() + (config.CAPTCHA_EXPIRE_SECONDS || 600) * 1000;
    captchaCodes.set(member.id, { code, expiresAt, guildId });
    await applyCaptchaRoles(member);
    await sendCaptcha(member, code);
  } catch (error) {
    addLog(`Erreur GuildMemberAdd: ${error.message}`);
  }
});

client.on(Events.GuildMemberRemove, async (member) => {
  try {
    if (!config.WELCOME_CHANNEL_ID) return;
    const channel = member.guild.channels.cache.get(String(config.WELCOME_CHANNEL_ID));
    if (!channel?.isTextBased?.()) return;
    const embed = new EmbedBuilder().setTitle('Au revoir').setDescription(`${member.user.tag} a quitté.`).setColor(0xED4245);
    channel.send({ embeds: [embed] }).catch(() => {});
  } catch (error) {
    addLog(`Erreur GuildMemberRemove: ${error.message}`);
  }
});

client.on(Events.MessageCreate, async (message) => {
  try {
    if (!message.guild || message.author.bot) return;
    const now = Date.now();
    const last = levelCooldowns.get(message.author.id) || 0;
    if (now - last < 30_000) return;
    levelCooldowns.set(message.author.id, now);

    const xpGain = Math.floor(Math.random() * 11) + 5;
    const row = storage.getLevel(message.author.id);
    let xp = row ? row.xp + xpGain : xpGain;
    let level = row ? row.level : 1;
    let next = level * 100;
    let leveled = false;

    while (xp >= next) {
      xp -= next;
      level += 1;
      next = level * 100;
      leveled = true;
    }

    storage.setLevel(message.author.id, xp, level);

    if (leveled) {
      const channelId = config.LEVEL_CHANNEL_ID || message.channel.id;
      const channel = message.guild.channels.cache.get(String(channelId));
      if (channel?.isTextBased?.()) channel.send(`${message.author} a atteint le niveau ${level} !`).catch(() => {});
    }
  } catch (error) {
    addLog(`Erreur MessageCreate: ${error.message}`);
  }
});

client.on(Events.MessageDelete, async (message) => {
  try {
    if (!message.guild || message.author?.bot) return;
    const channel = getLogChannel(message.guild);
    if (!channel) return;
    const embed = new EmbedBuilder().setTitle('🗑️ Message supprimé').addFields(
      { name: 'Auteur', value: message.author?.tag || 'Inconnu', inline: false },
      { name: 'Salon', value: `${message.channel}`, inline: false }
    ).setColor(0xFEE75C);
    if (message.content) embed.addFields({ name: 'Contenu', value: message.content.slice(0, 1000) });
    channel.send({ embeds: [embed] }).catch(() => {});
  } catch (error) {
    addLog(`Erreur MessageDelete: ${error.message}`);
  }
});

client.on(Events.MessageUpdate, async (oldMsg, newMsg) => {
  try {
    if (!oldMsg.guild || oldMsg.author?.bot) return;
    if (oldMsg.content === newMsg.content) return;
    const channel = getLogChannel(oldMsg.guild);
    if (!channel) return;
    const embed = new EmbedBuilder().setTitle('✏️ Message modifié').addFields(
      { name: 'Auteur', value: oldMsg.author?.tag || 'Inconnu', inline: false },
      { name: 'Salon', value: `${oldMsg.channel}`, inline: false },
      { name: 'Avant', value: oldMsg.content?.slice(0, 1000) || '(vide)', inline: false },
      { name: 'Après', value: newMsg.content?.slice(0, 1000) || '(vide)', inline: false }
    ).setColor(0x3498DB);
    channel.send({ embeds: [embed] }).catch(() => {});
  } catch (error) {
    addLog(`Erreur MessageUpdate: ${error.message}`);
  }
});

client.on(Events.MessageReactionAdd, async (reaction, user) => {
  try {
    if (user.bot) return;
    if (reaction.partial) await reaction.fetch().catch(() => {});
    const roleId = storage.getReactionRole(reaction.message.id, reaction.emoji.toString());
    if (!roleId) return;
    const member = await reaction.message.guild.members.fetch(user.id).catch(() => null);
    if (!member) return;
    const role = reaction.message.guild.roles.cache.get(String(roleId));
    if (role) member.roles.add(role).catch(() => {});
  } catch (error) {
    addLog(`Erreur ReactionAdd: ${error.message}`);
  }
});

client.on(Events.MessageReactionRemove, async (reaction, user) => {
  try {
    if (user.bot) return;
    if (reaction.partial) await reaction.fetch().catch(() => {});
    const roleId = storage.getReactionRole(reaction.message.id, reaction.emoji.toString());
    if (!roleId) return;
    const member = await reaction.message.guild.members.fetch(user.id).catch(() => null);
    if (!member) return;
    const role = reaction.message.guild.roles.cache.get(String(roleId));
    if (role) member.roles.remove(role).catch(() => {});
  } catch (error) {
    addLog(`Erreur ReactionRemove: ${error.message}`);
  }
});

// ============ INTERACTIONS ============
client.on(Events.InteractionCreate, async (interaction) => {
  try {
    if (interaction.isButton()) {
      if (interaction.customId === 'ticket_create') {
        const existing = storage.getTicketByUser(interaction.user.id);
        if (existing) {
          const channel = interaction.guild?.channels.cache.get(String(existing.channelId));
          return interaction.reply({ content: `❌ Ticket déjà ouvert: ${channel || 'inconnu'}`, ephemeral: true });
        }
        
        await interaction.deferReply({ ephemeral: true });
        const channel = await createTicketChannel(interaction.guild, interaction.user);
        
        if (!channel) {
          return interaction.editReply({ content: '❌ Impossible de créer le ticket.' });
        }
        
        const embed = new EmbedBuilder().setTitle('🎫 Ticket Créé').setDescription('Explique ton problème.').setColor(0x2ECC71);
        const row = new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId('ticket_close').setLabel('Fermer').setStyle(ButtonStyle.Danger)
        );
        
        await channel.send({ embeds: [embed], components: [row] }).catch(() => {});
        return interaction.editReply({ content: `✅ Ticket créé: ${channel}` });
      }

      if (interaction.customId === 'ticket_close') {
        const row = storage.getTicketByChannel(interaction.channelId);
        if (!row) return interaction.reply({ content: '❌ Pas un ticket.', ephemeral: true });
        
        const embed = new EmbedBuilder().setTitle('🎫 Fermé').setDescription(`Par ${interaction.user.tag}`).setColor(0xFF6B6B).setTimestamp();
        storage.closeTicket(interaction.channelId);
        await interaction.reply({ embeds: [embed] });
        
        setTimeout(() => {
          interaction.channel.delete().catch(() => {});
        }, 3000);
        return;
      }
    }

    if (!interaction.isChatInputCommand()) return;

    const { commandName } = interaction;

    // Mod commands
    if (commandName === 'kick') {
      const member = interaction.options.getMember('membre');
      const reason = interaction.options.getString('raison') || 'Aucune raison';
      if (!member) return interaction.reply({ content: 'Membre introuvable.', ephemeral: true });
      if (!member.kickable) return interaction.reply({ content: 'Impossible.', ephemeral: true });
      if (member.user.id === interaction.user.id) return interaction.reply({ content: 'Tu ne peux pas te kick toi-même.', ephemeral: true });
      
      await member.kick(reason).catch(() => {});
      const embed = new EmbedBuilder().setTitle('⚠️ Kick').addFields({ name: 'User', value: member.user.tag, inline: true }, { name: 'Raison', value: reason, inline: true }).setColor(0xFF6B6B).setTimestamp();
      const logChannel = getLogChannel(interaction.guild);
      if (logChannel) logChannel.send({ embeds: [embed] }).catch(() => {});
      return interaction.reply({ embeds: [embed] });
    }

    if (commandName === 'ban') {
      const member = interaction.options.getMember('membre');
      const reason = interaction.options.getString('raison') || 'Aucune raison';
      if (!member) return interaction.reply({ content: 'Membre introuvable.', ephemeral: true });
      if (!member.bannable) return interaction.reply({ content: 'Impossible.', ephemeral: true });
      if (member.user.id === interaction.user.id) return interaction.reply({ content: 'Tu ne peux pas te ban toi-même.', ephemeral: true });
      
      await member.ban({ reason, deleteMessageDays: 7 }).catch(() => {});
      const embed = new EmbedBuilder().setTitle('🚫 Ban').addFields({ name: 'User', value: member.user.tag, inline: true }, { name: 'Raison', value: reason, inline: true }).setColor(0xFF0000).setTimestamp();
      const logChannel = getLogChannel(interaction.guild);
      if (logChannel) logChannel.send({ embeds: [embed] }).catch(() => {});
      return interaction.reply({ embeds: [embed] });
    }

    if (commandName === 'timeout') {
      const member = interaction.options.getMember('membre');
      const duration = interaction.options.getString('duree');
      const reason = interaction.options.getString('raison') || 'Aucune raison';
      const seconds = parseDuration(duration);
      if (!member) return interaction.reply({ content: 'Membre introuvable.', ephemeral: true });
      if (!seconds) return interaction.reply({ content: 'Durée invalide (ex: 10m, 2h, 1d).', ephemeral: true });
      if (!member.moderatable) return interaction.reply({ content: 'Impossible.', ephemeral: true });
      if (seconds > 2419200) return interaction.reply({ content: 'Max 28 jours.', ephemeral: true });
      
      await member.timeout(seconds * 1000, reason).catch(() => {});
      const embed = new EmbedBuilder().setTitle('⏱️ Timeout').addFields({ name: 'User', value: member.user.tag, inline: true }, { name: 'Durée', value: duration, inline: true }, { name: 'Raison', value: reason, inline: true }).setColor(0xF39C12).setTimestamp();
      const logChannel = getLogChannel(interaction.guild);
      if (logChannel) logChannel.send({ embeds: [embed] }).catch(() => {});
      return interaction.reply({ embeds: [embed] });
    }

    if (commandName === 'untimeout') {
      const member = interaction.options.getMember('membre');
      if (!member) return interaction.reply({ content: 'Membre introuvable.', ephemeral: true });
      if (!member.moderatable) return interaction.reply({ content: 'Impossible.', ephemeral: true });
      
      await member.timeout(null).catch(() => {});
      const embed = new EmbedBuilder().setTitle('✅ Timeout Retiré').addFields({ name: 'User', value: member.user.tag, inline: true }).setColor(0x2ECC71).setTimestamp();
      return interaction.reply({ embeds: [embed] });
    }

    if (commandName === 'clear') {
      const amount = interaction.options.getInteger('nombre');
      if (amount <= 0 || amount > 100) return interaction.reply({ content: 'Entre 1 et 100.', ephemeral: true });
      const messages = await interaction.channel.bulkDelete(amount, true).catch(() => []);
      const embed = new EmbedBuilder().setTitle('🧹 Supprimé').addFields({ name: 'Nombre', value: `${messages.size || 0}`, inline: false }).setColor(0x3498DB).setTimestamp();
      const logChannel = getLogChannel(interaction.guild);
      if (logChannel) logChannel.send({ embeds: [embed] }).catch(() => {});
      return interaction.reply({ content: `🧹 ${messages.size || 0} messages supprimés.`, ephemeral: true });
    }

    if (commandName === 'ticket') {
      const action = interaction.options.getString('action');
      if (action === 'create') {
        const existing = storage.getTicketByUser(interaction.user.id);
        if (existing) {
          const channel = interaction.guild.channels.cache.get(String(existing.channelId));
          return interaction.reply({ content: `❌ Déjà ouvert: ${channel}`, ephemeral: true });
        }
        
        const channel = await createTicketChannel(interaction.guild, interaction.user);
        if (!channel) return interaction.reply({ content: '❌ Erreur création.', ephemeral: true });
        
        const embed = new EmbedBuilder().setTitle('🎫 Ticket').setDescription('Explique ton problème.').setColor(0x2ECC71);
        return interaction.reply({ content: `✅ Créé: ${channel}`, ephemeral: true });
      }
      
      const row = storage.getTicketByChannel(interaction.channelId);
      if (!row) return interaction.reply({ content: '❌ Pas un ticket.', ephemeral: true });
      
      await interaction.reply({ content: '✅ Fermeture...' });
      storage.closeTicket(interaction.channelId);
      
      setTimeout(() => {
        interaction.channel.delete().catch(() => {});
      }, 3000);
    }

    if (commandName === 'ticketpanel') {
      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('ticket_create').setLabel('🎫 Ticket').setStyle(ButtonStyle.Success)
      );
      const embed = new EmbedBuilder().setTitle('🎫 Support').setDescription('Clique pour créer un ticket.').setColor(0x5865F2);
      return interaction.reply({ embeds: [embed], components: [row] });
    }

    if (commandName === 'setup') {
      const option = interaction.options.getString('option');
      const channel = interaction.options.getChannel('canal');
      const messages = {
        logchannel: 'Logs configurés',
        welcomechannel: 'Bienvenue configuré',
        levelchannel: 'Niveaux configuré',
        ticketcategory: 'Tickets configuré'
      };
      const embed = new EmbedBuilder().setTitle('⚙️ Setup').addFields({ name: 'Option', value: option, inline: true }, { name: 'ID', value: channel.id, inline: true }).setColor(0x3498DB).setTimestamp();
      return interaction.reply({ embeds: [embed] });
    }

    if (commandName === 'verify') {
      const code = interaction.options.getString('code');
      const entry = captchaCodes.get(interaction.user.id);
      if (!entry) return interaction.reply({ content: 'Aucune vérif en attente.', ephemeral: true });
      if (entry.guildId !== interaction.guild.id) return interaction.reply({ content: 'Mauvais serveur.', ephemeral: true });
      if (Date.now() > entry.expiresAt) {
        captchaCodes.delete(interaction.user.id);
        return interaction.reply({ content: 'Code expiré.', ephemeral: true });
      }
      if (entry.code !== code) return interaction.reply({ content: 'Code invalide.', ephemeral: true });

      if (config.UNVERIFIED_ROLE_ID) {
        const role = interaction.guild.roles.cache.get(String(config.UNVERIFIED_ROLE_ID));
        if (role) await interaction.member.roles.remove(role).catch(() => {});
      }
      if (config.VERIFIED_ROLE_ID) {
        const role = interaction.guild.roles.cache.get(String(config.VERIFIED_ROLE_ID));
        if (role) await interaction.member.roles.add(role).catch(() => {});
      }

      captchaCodes.delete(interaction.user.id);
      return interaction.reply({ content: '✅ Vérifié !', ephemeral: true });
    }

    if (commandName === 'raidmode') {
      const action = interaction.options.getString('action');
      if (action === 'on') {
        const duration = (config.RAID_MODE_DURATION || 300) * 1000;
        raidModeUntil.set(interaction.guild.id, Date.now() + duration);
        return interaction.reply(`🛡️ Raid mode: ${duration / 1000}s`);
      }
      raidModeUntil.set(interaction.guild.id, 0);
      return interaction.reply('✅ Raid mode off.');
    }

    if (commandName === 'rank') {
      const member = interaction.options.getUser('membre') || interaction.user;
      const row = storage.getLevel(member.id);
      if (!row) return interaction.reply({ content: '❌ Pas de XP.', ephemeral: true });
      
      const embed = new EmbedBuilder().setTitle(`📊 ${member.tag}`).addFields({ name: 'Niveau', value: `${row.level}`, inline: true }, { name: 'XP', value: `${row.xp}`, inline: true }).setThumbnail(member.displayAvatarURL()).setColor(0xF39C12);
      return interaction.reply({ embeds: [embed] });
    }

    if (commandName === 'giveaway') {
      const duration = parseDuration(interaction.options.getString('duree'));
      const winners = interaction.options.getInteger('gagnants');
      const prize = interaction.options.getString('prix');
      if (!duration) return interaction.reply({ content: 'Durée invalide.', ephemeral: true });
      if (winners <= 0) return interaction.reply({ content: 'Nombre invalide.', ephemeral: true });
      
      const embed = new EmbedBuilder().setTitle('🎉 Giveaway').addFields({ name: 'Prix', value: prize, inline: false }, { name: 'Durée', value: interaction.options.getString('duree'), inline: false }, { name: 'Gagnants', value: `${winners}`, inline: false }).setColor(0x9B59B6);

      const message = await interaction.reply({ embeds: [embed], fetchReply: true });
      await message.react('🎉').catch(() => {});

      setTimeout(async () => {
        try {
          const fetched = await interaction.channel.messages.fetch(message.id).catch(() => null);
          if (!fetched) return;
          const reaction = fetched.reactions.cache.get('🎉');
          if (!reaction) return interaction.channel.send('❌ Aucune participation.').catch(() => {});
          const users = await reaction.users.fetch();
          const eligible = users.filter(u => !u.bot);
          if (eligible.size < winners) return interaction.channel.send('❌ Pas assez.').catch(() => {});
          const shuffled = [...eligible.values()].sort(() => 0.5 - Math.random());
          const selected = shuffled.slice(0, winners);
          interaction.channel.send(`🎉 Gagnant(s): ${selected.map(u => `<@${u.id}>`).join(', ')} | ${prize}`).catch(() => {});
        } catch (error) {
          addLog(`Erreur giveaway: ${error.message}`);
        }
      }, duration * 1000);
      return;
    }

    if (commandName === 'reroll') {
      const messageId = interaction.options.getString('message_id');
      const winners = interaction.options.getInteger('gagnants') || 1;
      const message = await interaction.channel.messages.fetch(messageId).catch(() => null);
      if (!message) return interaction.reply({ content: 'Message not found.', ephemeral: true });
      const reaction = message.reactions.cache.get('🎉');
      if (!reaction) return interaction.reply({ content: 'No reactions.', ephemeral: true });
      const users = await reaction.users.fetch();
      const eligible = users.filter(u => !u.bot);
      if (eligible.size < winners) return interaction.reply({ content: 'Not enough.', ephemeral: true });
      const shuffled = [...eligible.values()].sort(() => 0.5 - Math.random());
      const selected = shuffled.slice(0, winners);
      return interaction.reply(`🎉 ${selected.map(u => `<@${u.id}>`).join(', ')}`);
    }

    if (commandName === 'rr') {
      const action = interaction.options.getString('action');
      const messageId = interaction.options.getString('message_id');
      const emoji = interaction.options.getString('emoji');
      const role = interaction.options.getRole('role');
      const message = await interaction.channel.messages.fetch(messageId).catch(() => null);
      if (!message) return interaction.reply({ content: 'Message not found.', ephemeral: true });

      if (action === 'add') {
        storage.setReactionRole(messageId, emoji, role.id);
        await message.react(emoji).catch(() => {});
        return interaction.reply('✅ Added.');
      }

      storage.removeReactionRole(messageId, emoji);
      return interaction.reply('✅ Removed.');
    }

    if (commandName === 'join') {
      const queue = await connectToVoice(interaction);
      if (!queue) return;
      return interaction.reply('✅ Connecté.');
    }

    if (commandName === 'leave') {
      const queue = ensureGuildQueue(interaction.guild.id);
      if (queue?.connection) {
        queue.connection.destroy();
        queue.tracks = [];
        queue.player?.stop?.();
      }
      return interaction.reply('✅ Déconnecté.');
    }

    if (commandName === 'play') {
      try {
        const member = await interaction.guild.members.fetch(interaction.user.id).catch(() => null);
        if (!member?.voice?.channel) return interaction.reply({ content: '❌ Vocal requis.', ephemeral: true });
        
        const query = interaction.options.getString('query');
        await interaction.deferReply();
        
        const search = await play.search(query, { limit: 1 }).catch(() => null);
        if (!search?.length) return interaction.editReply('❌ Pas trouvé.');
        
        const track = search[0];
        const queue = ensureGuildQueue(interaction.guild.id);
        
        if (!queue.connection || queue.connection.state.status === VoiceConnectionStatus.Destroyed) {
          const voiceChannel = member.voice.channel;
          const connection = joinVoiceChannel({
            channelId: voiceChannel.id,
            guildId: voiceChannel.guild.id,
            adapterCreator: voiceChannel.guild.voiceAdapterCreator
          });
          await entersState(connection, VoiceConnectionStatus.Ready, 20_000).catch(() => null);
          connection.subscribe(queue.player);
          queue.connection = connection;
        }
        
        queue.tracks.push({ title: track.title || 'Unknown', url: track.url, thumbnail: track.thumbnail || '' });
        queue.textChannelId = interaction.channelId;
        
        const embed = new EmbedBuilder().setTitle('🎵 Ajoutée').setDescription(`[${track.title}](${track.url})`).setThumbnail(track.thumbnail || '').addFields({ name: 'Position', value: `${queue.tracks.length}`, inline: true }).setColor(0x9B59B6);
        
        if (queue.player.state.status !== AudioPlayerStatus.Playing) {
          await playNext(interaction.guild.id).catch(() => {});
        }
        
        return interaction.editReply({ embeds: [embed] });
      } catch (error) {
        addLog(`Erreur play: ${error.message}`);
        return interaction.editReply('❌ Erreur.');
      }
    }

    if (commandName === 'pause') {
      const queue = ensureGuildQueue(interaction.guild.id);
      if (queue?.player?.state.status !== AudioPlayerStatus.Playing) {
        return interaction.reply({ content: '❌ Pas de musique.', ephemeral: true });
      }
      queue.player.pause(true);
      return interaction.reply('⏸️ Pause.');
    }

    if (commandName === 'resume') {
      const queue = ensureGuildQueue(interaction.guild.id);
      if (queue?.player?.state.status === AudioPlayerStatus.Playing) {
        return interaction.reply({ content: '❌ Déjà en lecture.', ephemeral: true });
      }
      queue.player?.unpause?.();
      return interaction.reply('▶️ Reprise.');
    }

    if (commandName === 'skip') {
      const queue = ensureGuildQueue(interaction.guild.id);
      if (!queue?.tracks?.length) {
        return interaction.reply({ content: '❌ File vide.', ephemeral: true });
      }
      queue.player?.stop?.();
      return interaction.reply('⏭️ Passée.');
    }

    if (commandName === 'stop') {
      const queue = ensureGuildQueue(interaction.guild.id);
      queue.tracks = [];
      queue.player?.stop?.();
      return interaction.reply('⏹️ Stoppée.');
    }

    if (commandName === 'queue') {
      const queue = ensureGuildQueue(interaction.guild.id);
      if (!queue?.tracks?.length) {
        return interaction.reply({ content: '❌ Vide.', ephemeral: true });
      }
      
      const list = queue.tracks.slice(0, 10).map((t, i) => `**${i + 1}.** ${t.title}`).join('\n');
      const embed = new EmbedBuilder().setTitle('🎵 File').setDescription(list).setFooter({ text: `Total: ${queue.tracks.length}` }).setColor(0x9B59B6);
      return interaction.reply({ embeds: [embed] });
    }

    if (commandName === 'warn') {
      const member = interaction.options.getUser('membre');
      const raison = interaction.options.getString('raison');
      const guildId = interaction.guild.id;
      
      if (!warns.has(guildId)) warns.set(guildId, new Map());
      const guildWarns = warns.get(guildId);
      if (!guildWarns.has(member.id)) guildWarns.set(member.id, []);
      
      const warnCount = guildWarns.get(member.id).length + 1;
      guildWarns.get(member.id).push({ raison, date: new Date().toISOString(), by: interaction.user.id, byTag: interaction.user.tag });
      
      let action = '';
      if (warnCount === 3) {
        const memberObj = await interaction.guild.members.fetch(member.id).catch(() => null);
        if (memberObj) await memberObj.timeout(3600000, 'Auto-mute').catch(() => {});
        action = ' - Auto-mute 1h';
      } else if (warnCount >= 5) {
        const memberObj = await interaction.guild.members.fetch(member.id).catch(() => null);
        if (memberObj?.bannable) await memberObj.ban({ reason: 'Auto-ban: 5 warns' }).catch(() => {});
        action = ' - Auto-ban';
      }
      
      const embed = new EmbedBuilder().setTitle('⚠️ Warn').addFields({ name: 'User', value: member.tag, inline: true }, { name: 'Raison', value: raison, inline: false }, { name: 'Total', value: `${warnCount}/5`, inline: true }).setColor(0xFF6B6B).setTimestamp();
      if (action) embed.addFields({ name: 'Action', value: action, inline: false });
      
      const logChannel = getLogChannel(interaction.guild);
      if (logChannel) logChannel.send({ embeds: [embed] }).catch(() => {});
      
      return interaction.reply({ embeds: [embed] });
    }

    if (commandName === 'warns') {
      const member = interaction.options.getUser('membre') || interaction.user;
      const guildId = interaction.guild.id;
      const guildWarns = warns.get(guildId)?.get(member.id) || [];
      
      if (!guildWarns.length) {
        return interaction.reply({ content: '✅ Clean.', ephemeral: true });
      }
      
      const list = guildWarns.map((w, i) => `**${i + 1}.** ${w.raison}`).join('\n');
      const embed = new EmbedBuilder().setTitle(`⚠️ Warns: ${member.tag}`).setDescription(list).setFooter({ text: `Total: ${guildWarns.length}` }).setColor(0xFF6B6B);
      
      return interaction.reply({ embeds: [embed] });
    }

    if (commandName === 'clearwarn') {
      const member = interaction.options.getUser('membre');
      const guildId = interaction.guild.id;
      const previousCount = warns.get(guildId)?.get(member.id)?.length || 0;
      
      if (warns.has(guildId)) {
        warns.get(guildId).delete(member.id);
      }
      
      const embed = new EmbedBuilder().setTitle('🧹 Warns Effacés').addFields({ name: 'User', value: member.tag, inline: true }, { name: 'Nombre', value: `${previousCount}`, inline: true }).setColor(0x2ECC71).setTimestamp();
      
      const logChannel = getLogChannel(interaction.guild);
      if (logChannel) logChannel.send({ embeds: [embed] }).catch(() => {});
      
      return interaction.reply({ embeds: [embed] });
    }

    if (commandName === 'mute') {
      const user = interaction.options.getUser('membre');
      const member = await interaction.guild.members.fetch(user.id).catch(() => null);
      
      if (!member) return interaction.reply({ content: 'Pas trouvé.', ephemeral: true });
      if (!member.voice?.channel) return interaction.reply({ content: 'Pas en vocal.', ephemeral: true });
      
      await member.voice.setMute(true).catch(() => {});
      const embed = new EmbedBuilder().setTitle('🔇 Mute').addFields({ name: 'User', value: member.user.tag, inline: true }).setColor(0xFF9800).setTimestamp();
      return interaction.reply({ embeds: [embed] });
    }

    if (commandName === 'unmute') {
      const user = interaction.options.getUser('membre');
      const member = await interaction.guild.members.fetch(user.id).catch(() => null);
      
      if (!member) return interaction.reply({ content: 'Pas trouvé.', ephemeral: true });
      if (!member.voice?.channel) return interaction.reply({ content: 'Pas en vocal.', ephemeral: true });
      
      await member.voice.setMute(false).catch(() => {});
      const embed = new EmbedBuilder().setTitle('🔊 Unmute').addFields({ name: 'User', value: member.user.tag, inline: true }).setColor(0x2ECC71).setTimestamp();
      return interaction.reply({ embeds: [embed] });
    }

    if (commandName === 'remind') {
      const duration = parseDuration(interaction.options.getString('duree'));
      const message = interaction.options.getString('message');
      if (!duration) return interaction.reply({ content: 'Durée invalide.', ephemeral: true });
      
      const embed = new EmbedBuilder().setTitle('⏰ Rappel').addFields({ name: 'Message', value: message, inline: false }).setColor(0x3498DB);
      
      setTimeout(() => {
        interaction.user.send({ content: `⏰ **${message}**`, embeds: [embed] }).catch(() => {});
      }, duration * 1000);
      
      return interaction.reply({ embeds: [embed] });
    }

    if (commandName === 'poll') {
      const question = interaction.options.getString('question');
      const options = [
        interaction.options.getString('option1'),
        interaction.options.getString('option2'),
        interaction.options.getString('option3'),
        interaction.options.getString('option4')
      ].filter(Boolean);
      
      const emojis = ['1️⃣', '2️⃣', '3️⃣', '4️⃣'];
      const embed = new EmbedBuilder().setTitle('📊 Poll').setDescription(question).addFields(options.map((opt, i) => ({ name: emojis[i], value: opt, inline: false }))).setColor(0x3498DB);
      
      const msg = await interaction.reply({ embeds: [embed], fetchReply: true });
      for (let i = 0; i < options.length; i++) {
        await msg.react(emojis[i]).catch(() => {});
      }
    }

    if (commandName === 'userinfo') {
      const member = interaction.options.getUser('membre') || interaction.user;
      const memberObj = await interaction.guild.members.fetch(member.id).catch(() => null);
      const embed = new EmbedBuilder().setTitle(`${member.tag}`).addFields(
        { name: 'ID', value: member.id, inline: true },
        { name: 'Créé', value: `<t:${Math.floor(member.createdTimestamp / 1000)}:d>`, inline: true },
        { name: 'Rejoint', value: `<t:${Math.floor(memberObj?.joinedTimestamp / 1000 || 0)}:d>`, inline: true },
        { name: 'Rôles', value: memberObj?.roles?.cache?.filter?.(r => r.id !== interaction.guild.id)?.map?.(r => r.name)?.join?.(', ') || 'None', inline: false }
      ).setThumbnail(member.displayAvatarURL()).setColor(0x2ECC71);
      return interaction.reply({ embeds: [embed] });
    }

    if (commandName === 'serverinfo') {
      const guild = interaction.guild;
      const embed = new EmbedBuilder().setTitle(guild.name).addFields(
        { name: 'ID', value: guild.id, inline: true },
        { name: 'Membres', value: `${guild.memberCount}`, inline: true },
        { name: 'Créé', value: `<t:${Math.floor(guild.createdTimestamp / 1000)}:d>`, inline: true },
        { name: 'Rôles', value: `${guild.roles.cache.size}`, inline: true },
        { name: 'Canaux', value: `${guild.channels.cache.size}`, inline: true },
        { name: 'Propriétaire', value: `<@${guild.ownerId}>`, inline: true }
      ).setThumbnail(guild.iconURL()).setColor(0x9B59B6);
      return interaction.reply({ embeds: [embed] });
    }

    if (commandName === 'avatar') {
      const member = interaction.options.getUser('membre') || interaction.user;
      const embed = new EmbedBuilder().setTitle(`Avatar: ${member.tag}`).setImage(member.displayAvatarURL({ size: 1024 })).setColor(0x1ABC9C);
      return interaction.reply({ embeds: [embed] });
    }

    if (commandName === 'ping') {
      const msg = await interaction.reply({ content: 'Pong!', fetchReply: true });
      const latency = msg.createdTimestamp - interaction.createdTimestamp;
      return interaction.editReply(`🏓 ${latency}ms | API: ${client.ws.ping}ms`);
    }

    if (commandName === 'help') {
      const commands = [
        '**Modération**: /kick, /ban, /timeout, /warn, /mute, /unmute, /clearwarn, /clear',
        '**Tickets**: /ticket, /ticketpanel',
        '**Musique**: /play, /pause, /resume, /skip, /stop, /queue, /join, /leave',
        '**Giveaway**: /giveaway, /reroll',
        '**Systèmes**: /rank, /rr, /raidmode, /verify, /setup',
        '**Utilité**: /userinfo, /serverinfo, /avatar, /ping, /stats',
        '**Annonces**: /announce, /suggestion, /poll, /remind',
        '**Jeux**: /8ball, /dice, /joke, /quote, /slots, /rps, /calc, /afk, /color',
        '**Staff**: /botinfo, /uptime, /setstatus, /reload, /poweroff, /eval, /logs',
        '**Signalement**: /report, /bug'
      ];
      const embed = new EmbedBuilder().setTitle('📚 Aide').setDescription(commands.join('\n')).setColor(0xF39C12);
      return interaction.reply({ embeds: [embed] });
    }

    if (commandName === 'announce') {
      const titre = interaction.options.getString('titre');
      const message = interaction.options.getString('message');
      const canal = interaction.options.getChannel('canal') || interaction.channel;
      const embed = new EmbedBuilder().setTitle(`📣 ${titre}`).setDescription(message).setColor(0xE74C3C).setFooter({ text: `Par ${interaction.user.tag}` });
      await canal.send({ embeds: [embed] }).catch(() => {});
      return interaction.reply('✅ Envoyée.');
    }

    if (commandName === 'stats') {
      const guild = interaction.guild;
      const embed = new EmbedBuilder().setTitle('📊 Stats').addFields(
        { name: 'Serveur', value: guild.name, inline: true },
        { name: 'Membres', value: `${guild.memberCount}`, inline: true },
        { name: 'Bots', value: `${guild.members.cache.filter(m => m.user.bot).size}`, inline: true },
        { name: 'Texte', value: `${guild.channels.cache.filter(c => c.isTextBased?.()).size}`, inline: true },
        { name: 'Vocal', value: `${guild.channels.cache.filter(c => c.isVoiceBased?.()).size}`, inline: true },
        { name: 'Rôles', value: `${guild.roles.cache.size}`, inline: true }
      ).setColor(0x1ABC9C);
      return interaction.reply({ embeds: [embed] });
    }

    if (commandName === 'suggestion') {
      const titre = interaction.options.getString('titre');
      const description = interaction.options.getString('description');
      if (config.LOG_CHANNEL_ID) {
        const logChannel = interaction.guild.channels.cache.get(String(config.LOG_CHANNEL_ID));
        if (logChannel?.isTextBased?.()) {
          const embed = new EmbedBuilder().setTitle(`💡 ${titre}`).setDescription(description).setAuthor({ name: interaction.user.tag, iconURL: interaction.user.displayAvatarURL() }).setColor(0xF39C12);
          const msg = await logChannel.send({ embeds: [embed] });
          await msg.react('👍').catch(() => {});
          await msg.react('👎').catch(() => {});
        }
      }
      return interaction.reply('✅ Envoyée.');
    }

    if (commandName === '8ball') {
      const question = interaction.options.getString('question');
      const responses = ['Oui', 'Non', 'Peut-être', 'Absolument', 'Impossible', 'Demande plus tard', 'Très probable', 'Doute fortement'];
      const response = responses[Math.floor(Math.random() * responses.length)];
      const embed = new EmbedBuilder().setTitle('🔮 Boule').addFields({ name: 'Q', value: question, inline: false }, { name: 'R', value: response, inline: false }).setColor(0x9B59B6);
      return interaction.reply({ embeds: [embed] });
    }

    if (commandName === 'dice') {
      const faces = interaction.options.getInteger('faces') || 6;
      if (faces < 2 || faces > 100) return interaction.reply({ content: 'Entre 2 et 100.', ephemeral: true });
      const result = Math.floor(Math.random() * faces) + 1;
      const embed = new EmbedBuilder().setTitle('🎲 Dé').addFields({ name: 'Faces', value: `${faces}`, inline: true }, { name: 'Résultat', value: `**${result}**`, inline: true }).setColor(0x3498DB);
      return interaction.reply({ embeds: [embed] });
    }

    if (commandName === 'report') {
      const user = interaction.options.getUser('utilisateur');
      const raison = interaction.options.getString('raison');
      if (config.LOG_CHANNEL_ID) {
        const logChannel = interaction.guild.channels.cache.get(String(config.LOG_CHANNEL_ID));
        if (logChannel?.isTextBased?.()) {
          const embed = new EmbedBuilder().setTitle('🚨 Report').addFields({ name: 'User', value: user.tag, inline: true }, { name: 'Raison', value: raison, inline: false }).setColor(0xFF0000).setTimestamp();
          logChannel.send({ embeds: [embed] }).catch(() => {});
        }
      }
      return interaction.reply({ content: '✅ Report envoyé.', ephemeral: true });
    }

    if (commandName === 'bug') {
      const description = interaction.options.getString('description');
      if (config.LOG_CHANNEL_ID) {
        const logChannel = interaction.guild.channels.cache.get(String(config.LOG_CHANNEL_ID));
        if (logChannel?.isTextBased?.()) {
          const embed = new EmbedBuilder().setTitle('🐛 Bug').setDescription(description).setAuthor({ name: interaction.user.tag, iconURL: interaction.user.displayAvatarURL() }).setColor(0xFF6347).setTimestamp();
          logChannel.send({ embeds: [embed] }).catch(() => {});
        }
      }
      return interaction.reply('✅ Bug signalé !');
    }

    if (commandName === 'joke') {
      const jokes = ['Pourquoi les plongeurs plongent-ils toujours en arrière ? Sinon ils tombent dans le bateau !', 'Qu\'est-ce qu\'un crocodile qui surveille la pharmacie ? Un Lacoste-guard !'];
      const joke = jokes[Math.floor(Math.random() * jokes.length)];
      const embed = new EmbedBuilder().setTitle('😂 Blague').setDescription(joke).setColor(0xFFD700);
      return interaction.reply({ embeds: [embed] });
    }

    if (commandName === 'quote') {
      const quotes = ['La vie est ce qui arrive. - John Lennon', 'Le seul moyen de faire du bon travail est d\'aimer ce que tu fais. - Steve Jobs', 'La vraie intelligence c\'est de reconnaître son ignorance. - Socrate'];
      const quote = quotes[Math.floor(Math.random() * quotes.length)];
      const embed = new EmbedBuilder().setTitle('💭 Citation').setDescription(quote).setColor(0x1ABC9C);
      return interaction.reply({ embeds: [embed] });
    }

    if (commandName === 'slots') {
      const symbols = ['🍎', '🍊', '🍋', '🍌', '🍒', '💎'];
      const slot1 = symbols[Math.floor(Math.random() * symbols.length)];
      const slot2 = symbols[Math.floor(Math.random() * symbols.length)];
      const slot3 = symbols[Math.floor(Math.random() * symbols.length)];
      const win = slot1 === slot2 && slot2 === slot3;
      const embed = new EmbedBuilder().setTitle('🎰 Slots').setDescription(`**${slot1} ${slot2} ${slot3}**`).addFields({ name: 'R', value: win ? '🎉 GAGNÉ !' : '😢 Perdu...', inline: false }).setColor(win ? 0x2ECC71 : 0xFF6B6B);
      return interaction.reply({ embeds: [embed] });
    }

    if (commandName === 'rps') {
      const choix = interaction.options.getString('choix');
      const choices = ['pierre', 'papier', 'ciseaux'];
      const botChoice = choices[Math.floor(Math.random() * choices.length)];
      let result = '';
      if (choix === botChoice) result = '🤝 Égalité !';
      else if ((choix === 'pierre' && botChoice === 'ciseaux') || (choix === 'papier' && botChoice === 'pierre') || (choix === 'ciseaux' && botChoice === 'papier')) result = '🎉 Gagné !';
      else result = '😢 Perdu !';
      
      const embed = new EmbedBuilder().setTitle('✋ RPS').addFields({ name: 'Toi', value: choix, inline: true }, { name: 'Bot', value: botChoice, inline: true }, { name: 'R', value: result, inline: false }).setColor(0xF39C12);
      return interaction.reply({ embeds: [embed] });
    }

    if (commandName === 'calc') {
      try {
        const expr = interaction.options.getString('expression');
        if (!/^[0-9+\-*/().%\s]*$/.test(expr)) return interaction.reply({ content: '❌ Invalid.', ephemeral: true });
        const result = eval(expr);
        const embed = new EmbedBuilder().setTitle('🧮 Calc').addFields({ name: 'Expr', value: `\`${expr}\``, inline: true }, { name: 'R', value: `\`${result}\``, inline: true }).setColor(0x3498DB);
        return interaction.reply({ embeds: [embed] });
      } catch (e) {
        return interaction.reply({ content: '❌ Erreur.', ephemeral: true });
      }
    }

    if (commandName === 'afk') {
      const raison = interaction.options.getString('raison') || 'AFK';
      const member = await interaction.guild.members.fetch(interaction.user.id).catch(() => null);
      if (member) {
        await member.setNickname(`[AFK] ${member.user.username}`).catch(() => {});
      }
      const embed = new EmbedBuilder().setTitle('😴 AFK').addFields({ name: 'Raison', value: raison, inline: false }).setColor(0x95A5A6);
      return interaction.reply({ embeds: [embed] });
    }

    if (commandName === 'color') {
      const nom = interaction.options.getString('nom');
      const hex = interaction.options.getString('hex');
      try {
        const color = parseInt(hex.replace('#', ''), 16);
        const role = await interaction.guild.roles.create({
          name: nom,
          color: color,
          reason: `Par ${interaction.user.tag}`
        }).catch(() => null);
        if (!role) return interaction.reply({ content: '❌ Erreur.', ephemeral: true });
        await interaction.member.roles.add(role).catch(() => {});
        const embed = new EmbedBuilder().setTitle('🎨 Couleur').addFields({ name: 'Nom', value: nom, inline: true }, { name: 'Code', value: `#${hex}`, inline: true }).setColor(color);
        return interaction.reply({ embeds: [embed] });
      } catch (e) {
        return interaction.reply({ content: '❌ Hex invalide.', ephemeral: true });
      }
    }

    // Staff commands
    if (commandName === 'botinfo') {
      const embed = new EmbedBuilder().setTitle('🤖 Bot Info').addFields(
        { name: 'Nom', value: client.user.username, inline: true },
        { name: 'ID', value: client.user.id, inline: true },
        { name: 'Serveurs', value: String(client.guilds.cache.size), inline: true },
        { name: 'Utilisateurs', value: String(client.users.cache.size), inline: true },
        { name: 'Canaux', value: String(client.channels.cache.size), inline: true },
        { name: 'Commandes', value: '43+', inline: true }
      ).setColor(0x3498DB).setThumbnail(client.user.avatarURL()).setTimestamp();
      return interaction.reply({ embeds: [embed] });
    }

    if (commandName === 'uptime') {
      const uptime = Date.now() - botStartTime;
      const days = Math.floor(uptime / 86400000);
      const hours = Math.floor((uptime % 86400000) / 3600000);
      const minutes = Math.floor((uptime % 3600000) / 60000);
      const seconds = Math.floor((uptime % 60000) / 1000);
      
      const uptimeStr = `${days}j ${hours}h ${minutes}m ${seconds}s`;
      const embed = new EmbedBuilder().setTitle('⏱️ Uptime').setDescription(`**${uptimeStr}**`).setColor(0x2ECC71).setTimestamp();
      return interaction.reply({ embeds: [embed] });
    }

    if (commandName === 'setstatus') {
      const newStatus = interaction.options.getString('statut');
      await client.user.setActivity(newStatus, { type: ActivityType.Playing }).catch(() => {});
      addLog(`Statut: ${newStatus}`);
      const embed = new EmbedBuilder().setTitle('✅ Statut').setDescription(`\`${newStatus}\``).setColor(0x2ECC71);
      return interaction.reply({ embeds: [embed] });
    }

    if (commandName === 'reload') {
      const embed = new EmbedBuilder().setTitle('🔄 Restart').setDescription('Redémarrage...').setColor(0xF39C12);
      await interaction.reply({ embeds: [embed] });
      addLog('Restart par ' + interaction.user.tag);
      setTimeout(() => process.exit(0), 1000);
    }

    if (commandName === 'poweroff') {
      const embed = new EmbedBuilder().setTitle('⛔ Off').setDescription('Arrêt...').setColor(0xFF6B6B);
      await interaction.reply({ embeds: [embed] });
      addLog('Off par ' + interaction.user.tag);
      setTimeout(() => process.exit(0), 1000);
    }

    if (commandName === 'eval') {
      const code = interaction.options.getString('code');
      try {
        let result = eval(code);
        if (typeof result !== 'string') result = JSON.stringify(result, null, 2);
        if (result.length > 2000) result = result.substring(0, 1997) + '...';
        const embed = new EmbedBuilder().setTitle('📝 Eval').setDescription('```js\n' + result + '\n```').setColor(0x2ECC71);
        addLog(`Eval: ${code}`);
        return interaction.reply({ embeds: [embed] });
      } catch (error) {
        const embed = new EmbedBuilder().setTitle('❌ Eval Error').setDescription('```js\n' + error.message + '\n```').setColor(0xFF6B6B);
        addLog(`Eval Error: ${error.message}`);
        return interaction.reply({ embeds: [embed] });
      }
    }

    if (commandName === 'logs') {
      const logsText = botLogs.slice(-20).join('\n');
      const embed = new EmbedBuilder().setTitle('📋 Logs').setDescription('```\n' + (logsText || 'Aucun') + '\n```').setColor(0x3498DB);
      return interaction.reply({ embeds: [embed] });
    }
  } catch (error) {
    addLog(`Erreur: ${error.message}`);
    console.error('Erreur interaction:', error);
    try {
      if (!interaction.replied && !interaction.deferred) {
        await interaction.reply({ content: '❌ Erreur.', ephemeral: true });
      } else if (interaction.deferred) {
        await interaction.editReply({ content: '❌ Erreur.' });
      }
    } catch (e) {
      console.error('Impossible de répondre:', e.message);
    }
  }
});

// Cleanup on exit
process.on('SIGINT', () => {
  console.log('\n✅ Arrêt gracieux...');
  if (statusInterval) clearInterval(statusInterval);
  if (voiceConnectInterval) clearInterval(voiceConnectInterval);
  queues.forEach(queue => {
    if (queue.connection) queue.connection.destroy();
  });
  client.destroy();
  process.exit(0);
});

client.login(config.DISCORD_TOKEN);
