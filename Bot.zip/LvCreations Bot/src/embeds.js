// Module d'embeds professionnels
const { EmbedBuilder } = require('discord.js');

const createSuccessEmbed = (title, description) => {
  return new EmbedBuilder()
    .setTitle(`✅ ${title}`)
    .setDescription(description)
    .setColor(0x2ECC71)
    .setFooter({ text: '✨ LvCreations Bot' })
    .setTimestamp();
};

const createErrorEmbed = (title, description) => {
  return new EmbedBuilder()
    .setTitle(`❌ ${title}`)
    .setDescription(description)
    .setColor(0xE74C3C)
    .setFooter({ text: '⚠️ Erreur' })
    .setTimestamp();
};

const createWarningEmbed = (title, description) => {
  return new EmbedBuilder()
    .setTitle(`⚠️ ${title}`)
    .setDescription(description)
    .setColor(0xF39C12)
    .setFooter({ text: '⚡ Attention' })
    .setTimestamp();
};

const createInfoEmbed = (title, description) => {
  return new EmbedBuilder()
    .setTitle(`ℹ️ ${title}`)
    .setDescription(description)
    .setColor(0x3498DB)
    .setFooter({ text: 'ℹ️ Information' })
    .setTimestamp();
};

const createUserProfileEmbed = (user, member, level = 0, xp = 0) => {
  const joinDate = member?.joinedTimestamp ? `<t:${Math.floor(member.joinedTimestamp / 1000)}:R>` : 'Inconnu';
  const createdDate = `<t:${Math.floor(user.createdTimestamp / 1000)}:d>`;
  const roles = member?.roles?.cache
    ?.filter(r => r.id !== member.guild.id)
    ?.map(r => r.toString())
    ?.slice(0, 10)
    ?.join(', ') || 'Aucun rôle';
  
  const nextLevelXp = (level + 1) * 100;
  const progressBar = createProgressBar(xp, nextLevelXp, 15);
  
  return new EmbedBuilder()
    .setTitle(`👤 Profil de ${user.username}`)
    .setDescription(`**ID**: \`${user.id}\``)
    .setThumbnail(user.avatarURL({ size: 256 }))
    .addFields(
      { 
        name: '📊 Niveau', 
        value: `\`${level}\` • ${xp}/${nextLevelXp} XP`, 
        inline: true 
      },
      { 
        name: '⏱️ Statut', 
        value: user.bot ? '🤖 Bot' : '👤 Utilisateur', 
        inline: true 
      },
      { 
        name: '📅 Créé le', 
        value: createdDate, 
        inline: true 
      },
      { 
        name: '🎫 Rejoint', 
        value: joinDate, 
        inline: true 
      },
      { 
        name: '🏆 Rôles', 
        value: roles, 
        inline: false 
      },
      { 
        name: '⭐ Progression', 
        value: progressBar, 
        inline: false 
      }
    )
    .setColor(0x5865F2)
    .setFooter({ text: `Profil de ${user.username}` })
    .setTimestamp();
};

const createProgressBar = (current, max, length = 15) => {
  const percent = Math.min(100, (current / max) * 100);
  const filled = Math.round((percent / 100) * length);
  const bar = '█'.repeat(filled) + '░'.repeat(length - filled);
  return `[${bar}] ${percent.toFixed(1)}%`;
};

const createModerationEmbed = (action, member, reason, moderator) => {
  const actions = {
    'kick': { title: '🦶 Kick', color: 0xF39C12 },
    'ban': { title: '🚫 Ban', color: 0xE74C3C },
    'timeout': { title: '⏱️ Timeout', color: 0xFF6B6B },
    'warn': { title: '⚠️ Avertissement', color: 0xE67E22 },
    'mute': { title: '🔇 Mute', color: 0xFF9800 }
  };

  const actionData = actions[action] || { title: '⚡ Action', color: 0x95A5A6 };

  return new EmbedBuilder()
    .setTitle(actionData.title)
    .setDescription(`Action modérée contre ${member}`)
    .addFields(
      { 
        name: '👤 Utilisateur', 
        value: `${member.toString()}\n\`${member.id || member.user.id}\``, 
        inline: true 
      },
      { 
        name: '👮 Modérateur', 
        value: `${moderator.toString()}\n\`${moderator.id}\``, 
        inline: true 
      },
      { 
        name: '📝 Raison', 
        value: reason || '*Aucune raison spécifiée*', 
        inline: false 
      }
    )
    .setThumbnail(member.user?.avatarURL({ size: 128 }) || member.avatarURL?.({ size: 128 }))
    .setColor(actionData.color)
    .setFooter({ text: `Modération • ${new Date().toLocaleString('fr-FR')}` })
    .setTimestamp();
};

module.exports = {
  createSuccessEmbed,
  createErrorEmbed,
  createWarningEmbed,
  createInfoEmbed,
  createUserProfileEmbed,
  createModerationEmbed
};
