// Advanced Features Module - Features supplémentaires pour le bot
// Ce fichier contient des fonctionnalités avancées réutilisables

const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const utils = require('./utils');

// ==================== SYSTÈME DE REPUTATION ====================

const reputationSystem = new Map();

const addReputation = (userId, points = 1) => {
  const current = reputationSystem.get(userId) || 0;
  reputationSystem.set(userId, current + points);
  return current + points;
};

const getReputation = (userId) => {
  return reputationSystem.get(userId) || 0;
};

const getTopReputations = (limit = 10) => {
  return [...reputationSystem.entries()]
    .sort((a, b) => b[1] - a[1])
    .slice(0, limit);
};

// ==================== SYSTÈME DE BADGES ====================

const badgeSystem = {
  helper: { emoji: '🆘', name: 'Aide-Aide', description: 'Aide régulièrement les autres' },
  supporter: { emoji: '💪', name: 'Supporter', description: 'Soutien actif de la communauté' },
  admin: { emoji: '👑', name: 'Administrateur', description: 'Administrateur du serveur' },
  moderator: { emoji: '🛡️', name: 'Modérateur', description: 'Modérateur du serveur' },
  veteran: { emoji: '🎖️', name: 'Vétéran', description: 'Membre depuis plus de 6 mois' },
  active: { emoji: '⚡', name: 'Actif', description: 'Très actif dans la communauté' },
  verified: { emoji: '✅', name: 'Vérifié', description: 'Compte vérifié' },
  boosted: { emoji: '💎', name: 'Boosteur', description: 'Boosté le serveur' },
  developer: { emoji: '👨‍💻', name: 'Développeur', description: 'Développeur du projet' },
  artist: { emoji: '🎨', name: 'Artiste', description: 'Artiste talentueux' }
};

const getUserBadges = (userId, badges = []) => {
  return badges
    .filter(b => badgeSystem[b])
    .map(b => badgeSystem[b].emoji)
    .join(' ');
};

// ==================== SYSTÈME D'ACHIEVEMENTS ====================

const achievementSystem = new Map();

const achievements = {
  first_message: { emoji: '💬', name: 'Premier Message', description: 'Envoyer ton premier message' },
  level_10: { emoji: '📈', name: 'Niveau 10', description: 'Atteindre le niveau 10' },
  level_50: { emoji: '🚀', name: 'Niveau 50', description: 'Atteindre le niveau 50' },
  thousand_messages: { emoji: '💯', name: '1000 Messages', description: 'Envoyer 1000 messages' },
  giveaway_winner: { emoji: '🎉', name: 'Chanceux', description: 'Gagner un giveaway' },
  helpful: { emoji: '🙋', name: 'Aideur', description: 'Aider 10 personnes' }
};

const unlockAchievement = (userId, achievementId) => {
  if (!achievementSystem.has(userId)) achievementSystem.set(userId, []);
  const userAchievements = achievementSystem.get(userId);
  if (!userAchievements.includes(achievementId)) {
    userAchievements.push(achievementId);
    return true;
  }
  return false;
};

const getUserAchievements = (userId) => {
  return (achievementSystem.get(userId) || [])
    .filter(a => achievements[a])
    .map(a => achievements[a]);
};

// ==================== SYSTÈME DE QUIZ ====================

const quizzes = [
  {
    question: 'Combien de continents y a-t-il?',
    options: ['5', '6', '7', '8'],
    correct: 2
  },
  {
    question: 'Quel est le plus grand océan?',
    options: ['Atlantique', 'Pacifique', 'Indien', 'Arctique'],
    correct: 1
  },
  {
    question: 'Combien de cordes a une guitare classique?',
    options: ['4', '5', '6', '7'],
    correct: 2
  }
];

const getRandomQuiz = () => utils.getRandomElement(quizzes);

// ==================== SYSTÈME DE MOTS-CLÉS ====================

const keywordResponses = {
  'hello': 'Salut! 👋',
  'hi': 'Coucou! 👋',
  'hey': 'Ça va? 😊',
  'bye': 'Au revoir! 👋',
  'thanks': 'De rien! 😊',
  'help': 'Je suis là pour t\'aider! 💪',
  'love': 'L\'amour est beau ❤️',
  'sad': 'Ça ira mieux! 💙'
};

const getKeywordResponse = (message) => {
  const lowerMessage = message.toLowerCase();
  for (const [keyword, response] of Object.entries(keywordResponses)) {
    if (lowerMessage.includes(keyword)) return response;
  }
  return null;
};

// ==================== SYSTÈME DE COUNTDOWN ====================

const createCountdown = (endTime) => {
  const now = Date.now();
  const diff = endTime - now;
  if (diff <= 0) return 'Terminé!';
  return utils.formatDuration(diff);
};

// ==================== SYSTÈME D'EMBED AVANCÉ ====================

const createProgressEmbed = (title, items, color = 0x5865F2) => {
  const embed = new EmbedBuilder()
    .setTitle(title)
    .setColor(color);
  
  for (const [name, value] of Object.entries(items)) {
    if (typeof value === 'number') {
      embed.addFields({ 
        name, 
        value: utils.createBar(value, 100, 15),
        inline: false 
      });
    } else {
      embed.addFields({ name, value: String(value), inline: true });
    }
  }
  
  return embed;
};

const createListEmbed = (title, items, color = 0x5865F2) => {
  const embed = new EmbedBuilder()
    .setTitle(title)
    .setColor(color);
  
  const list = items
    .map((item, i) => `${i + 1}. ${item}`)
    .join('\n');
  
  embed.setDescription(list || 'Liste vide');
  return embed;
};

const createComparisonEmbed = (title, item1, item2, color = 0x5865F2) => {
  const embed = new EmbedBuilder()
    .setTitle(title)
    .setColor(color)
    .addFields(
      { name: '👤 Item 1', value: item1, inline: true },
      { name: '⚔️ vs', value: '---', inline: true },
      { name: '👤 Item 2', value: item2, inline: true }
    );
  
  return embed;
};

// ==================== SYSTÈME DE TAGS ====================

const tagsSystem = new Map();

const createTag = (guildId, tagName, content) => {
  if (!tagsSystem.has(guildId)) tagsSystem.set(guildId, new Map());
  tagsSystem.get(guildId).set(tagName.toLowerCase(), content);
};

const getTag = (guildId, tagName) => {
  return tagsSystem.get(guildId)?.get(tagName.toLowerCase());
};

const deleteTag = (guildId, tagName) => {
  return tagsSystem.get(guildId)?.delete(tagName.toLowerCase());
};

const listTags = (guildId) => {
  return [...(tagsSystem.get(guildId)?.keys() || [])];
};

// ==================== SYSTÈME DE PROFANITÉ ====================

const profanityFilter = (message) => {
  const bannedWords = ['bad', 'word', 'offensive'];
  return utils.containsProfanity(message, bannedWords);
};

// ==================== SYSTÈME DE COOLDOWN ====================

const createCooldown = (duration = 5000) => {
  const users = new Set();
  
  return {
    check: (userId) => !users.has(userId),
    use: (userId) => {
      users.add(userId);
      setTimeout(() => users.delete(userId), duration);
    }
  };
};

// ==================== STATISTIQUES AVANCÉES ====================

const createStatisticsEmbed = (guildId, guild) => {
  const members = guild.members.cache;
  const bots = members.filter(m => m.user.bot).size;
  const humans = members.size - bots;
  const roles = guild.roles.cache.size;
  const channels = guild.channels.cache.size;
  const onlineMembers = members.filter(m => m.user.presence?.status === 'online').size;
  
  return new EmbedBuilder()
    .setTitle(`📊 Statistiques de ${guild.name}`)
    .addFields(
      { name: '👥 Membres', value: utils.formatNumber(members.size), inline: true },
      { name: '👤 Humains', value: utils.formatNumber(humans), inline: true },
      { name: '🤖 Bots', value: utils.formatNumber(bots), inline: true },
      { name: '🟢 En ligne', value: utils.formatNumber(onlineMembers), inline: true },
      { name: '🎭 Rôles', value: utils.formatNumber(roles), inline: true },
      { name: '📝 Canaux', value: utils.formatNumber(channels), inline: true }
    )
    .setColor(0x5865F2)
    .setFooter({ text: 'Mis à jour à ' + new Date().toLocaleTimeString('fr-FR') })
    .setTimestamp();
};

// ==================== SYSTÈME DE NOTATIONS ====================

const ratingsSystem = new Map();

const addRating = (itemId, rating) => {
  if (!ratingsSystem.has(itemId)) ratingsSystem.set(itemId, []);
  ratingsSystem.get(itemId).push(rating);
};

const getAverageRating = (itemId) => {
  const ratings = ratingsSystem.get(itemId) || [];
  if (ratings.length === 0) return 0;
  return (ratings.reduce((a, b) => a + b, 0) / ratings.length).toFixed(2);
};

const getRatingStars = (rating) => {
  const fullStars = Math.floor(rating);
  const hasHalf = rating % 1 >= 0.5;
  return '⭐'.repeat(fullStars) + (hasHalf ? '✨' : '');
};

module.exports = {
  // Reputation
  addReputation,
  getReputation,
  getTopReputations,
  
  // Badges
  badgeSystem,
  getUserBadges,
  
  // Achievements
  achievementSystem,
  achievements,
  unlockAchievement,
  getUserAchievements,
  
  // Quiz
  quizzes,
  getRandomQuiz,
  
  // Keywords
  keywordResponses,
  getKeywordResponse,
  
  // Countdown
  createCountdown,
  
  // Embeds Avancés
  createProgressEmbed,
  createListEmbed,
  createComparisonEmbed,
  
  // Tags
  createTag,
  getTag,
  deleteTag,
  listTags,
  tagsSystem,
  
  // Profanité
  profanityFilter,
  
  // Cooldown
  createCooldown,
  
  // Stats
  createStatisticsEmbed,
  
  // Ratings
  addRating,
  getAverageRating,
  getRatingStars
};
