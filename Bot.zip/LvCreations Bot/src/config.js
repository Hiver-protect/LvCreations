const dotenv = require('dotenv');

dotenv.config();

const getString = (name, fallback = null) => {
  const value = process.env[name];
  if (!value || value.trim() === '') return fallback;
  return value.trim();
};

const getInt = (name, fallback = null) => {
  const value = process.env[name];
  if (!value || value.trim() === '') return fallback;
  const parsed = Number.parseInt(value, 10);
  return Number.isNaN(parsed) ? fallback : parsed;
};

const getBool = (name, fallback = false) => {
  const value = process.env[name];
  if (!value) return fallback;
  return ['1', 'true', 'yes', 'y', 'on'].includes(value.trim().toLowerCase());
};

module.exports = {
  DISCORD_TOKEN: (process.env.DISCORD_TOKEN || '').trim(),
  CLIENT_ID: (process.env.CLIENT_ID || '').trim(),
  GUILD_ID: getString('GUILD_ID'),
  LOG_CHANNEL_ID: getString('LOG_CHANNEL_ID'),
  WELCOME_CHANNEL_ID: getString('WELCOME_CHANNEL_ID'),
  LEVEL_CHANNEL_ID: getString('LEVEL_CHANNEL_ID'),
  TICKET_CATEGORY_ID: getString('TICKET_CATEGORY_ID'),
  STAFF_ROLE_ID: getString('STAFF_ROLE_ID'),
  GIVEAWAY_ROLE_ID: getString('GIVEAWAY_ROLE_ID'),
  CAPTCHA_ENABLED: getBool('CAPTCHA_ENABLED', true),
  CAPTCHA_CHANNEL_ID: getString('CAPTCHA_CHANNEL_ID'),
  UNVERIFIED_ROLE_ID: getString('UNVERIFIED_ROLE_ID'),
  VERIFIED_ROLE_ID: getString('VERIFIED_ROLE_ID'),
  CAPTCHA_EXPIRE_SECONDS: getInt('CAPTCHA_EXPIRE_SECONDS', 600),
  RAID_WINDOW_SECONDS: getInt('RAID_WINDOW_SECONDS', 20),
  RAID_MAX_JOINS: getInt('RAID_MAX_JOINS', 5),
  RAID_MODE_DURATION: getInt('RAID_MODE_DURATION', 300),
  RAID_ACTION: (process.env.RAID_ACTION || 'kick').trim().toLowerCase(),
  SYNC_COMMANDS: getBool('SYNC_COMMANDS', false),
  VOICE_CHANNEL_24H: getString('24H_VOICE_CHANNEL_ID'),
  AI_CHANNEL_ID: getString('AI_CHANNEL_ID'),
  GROQ_API_KEY: getString('GROQ_API_KEY')
};
