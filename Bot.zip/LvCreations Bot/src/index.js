const {
  ActionRowBuilder,
  ActivityType,
  ButtonBuilder,
  ButtonStyle,
  Client,
  EmbedBuilder,
  Events,
  GatewayIntentBits,
  Partials,
  PermissionFlagsBits,
  REST,
  Routes,
  SlashCommandBuilder,
  StringSelectMenuBuilder
} = require('discord.js');
const {
  AudioPlayerStatus,
  createAudioPlayer,
  createAudioResource,
  entersState,
  joinVoiceChannel,
  VoiceConnectionStatus
} = require('@discordjs/voice');
const play = require('play-dl');
const os = require('os');
const crypto = require('crypto');
const config = require('./config');
const storage = require('./storage');
const { getProtection, createProtectionEmbed } = require('./protections');
const { createSuccessEmbed, createErrorEmbed, createWarningEmbed, createInfoEmbed, createUserProfileEmbed, createModerationEmbed } = require('./embeds');
const utils = require('./utils');
const advanced = require('./advanced');

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessageReactions,
    GatewayIntentBits.MessageContent
  ],
  partials: [Partials.Message, Partials.Channel, Partials.Reaction]
});

const queues = new Map();
const joinTimes = new Map();
const raidModeUntil = new Map();
const captchaCodes = new Map();
const levelCooldowns = new Map();
const warns = new Map();
const reminders = new Map();
const pollVotes = new Map();

const STATS_CHANNEL_ID = '1467218273421758617';
const INFO_CHANNEL_ID = '1467295628374573148';
let statsMessageId = storage.getStatsMessageId();
let infoMessageId = storage.getInfoMessageId();
let statsInterval = null;

const statuses = [
  { name: '/help - Aide Complète', type: ActivityType.Watching },
  { name: 'LvCreations Bot v2.0', type: ActivityType.Playing },
  { name: '31+ Commandes', type: ActivityType.Watching },
  { name: 'Discord Bot Pro', type: ActivityType.Playing },
  { name: 'Musique, Modération & Plus', type: ActivityType.Watching },
  { name: '/play pour la Musique', type: ActivityType.Listening },
  { name: 'tes Serveurs', type: ActivityType.Watching },
  { name: 'Modération Avancée', type: ActivityType.Playing },
  { name: 'Raid Protection 🛡️', type: ActivityType.Watching },
  { name: 'Giveaways & Tickets', type: ActivityType.Playing }
];

let currentStatusIndex = 0;
let botStartTime = Date.now();
const botLogs = [];

const parseDuration = (str) => {
  if (!str) return null;
  const match = str.match(/^(\d+)([smhd])$/);
  if (!match) return null;
  const [, num, unit] = match;
  const n = parseInt(num, 10);
  if (isNaN(n)) return null;
  switch (unit) {
    case 's': return n;
    case 'm': return n * 60;
    case 'h': return n * 3600;
    case 'd': return n * 86400;
    default: return null;
  }
};

const addLog = (message, type = 'INFO', details = {}) => {
  const timestamp = new Date().toLocaleString('fr-FR');
  const log = `[${timestamp}] ${message}`;
  botLogs.push(log);
  if (botLogs.length > 100) botLogs.shift();
  console.log(log);
  
  // Send to Discord if channel is configured (non-blocking)
  if (config.LOG_CHANNEL_ID && client.isReady?.()) {
    setImmediate(async () => {
      try {
        const channel = await client.channels.fetch(config.LOG_CHANNEL_ID).catch(() => null);
        if (channel && channel.isTextBased?.()) {
          const embed = new EmbedBuilder()
            .setTitle(`📋 [${type}] ${message}`)
            .setColor(type === 'ERROR' ? 0xFF0000 : type === 'SUCCESS' ? 0x00FF00 : type === 'WARNING' ? 0xFFFF00 : 0x0099FF)
            .addFields(
              { name: '⏰ Timestamp', value: timestamp, inline: true },
              { name: '🤖 Bot Status', value: client.user?.tag || 'N/A', inline: true },
              { name: '📊 Uptime', value: `${Math.floor((Date.now() - botStartTime) / 1000)}s`, inline: true }
            );
          
          if (Object.keys(details).length > 0) {
            Object.entries(details).forEach(([key, value]) => {
              embed.addFields({ name: key, value: String(value).substring(0, 1024), inline: false });
            });
          }
          
          embed.setFooter({ text: `Guild: ${client.guilds.cache.size} | Users: ${client.users.cache.size}` })
            .setTimestamp();
          
          await channel.send({ embeds: [embed] }).catch(() => {});
        }
      } catch (error) {
        // Silently fail
      }
    });
  }
};

// AI Chat Function - Groq API
const generateAIResponse = async (userMessage) => {
  try {
    // Initialiser Groq avec la clé API
    const Groq = require('groq-sdk');
    const groqClient = new Groq({
      apiKey: config.GROQ_API_KEY
    });
    
    const response = await groqClient.chat.completions.create({
      messages: [
        {
          role: 'system',
          content: 'Tu es une IA québécoise nommée LvCreations IA. Tu parles en québécois avec des expressions comme "Yo", "Mon chum", "Ça va-tu", "Pantoute", "Eille", etc. Réponds toujours en français québécois. Sois amical, naturel et utile.'
        },
        {
          role: 'user',
          content: userMessage
        }
      ],
      model: 'llama-3.3-70b-versatile',
      temperature: 0.7,
      max_tokens: 500
    });

    let aiResponse = response.choices[0]?.message?.content || 'Yo, j\'ai pas pu trouver de réponse! 😅';
    
    // Limiter à 2000 caractères pour Discord
    if (aiResponse.length > 2000) {
      aiResponse = aiResponse.substring(0, 1997) + '...';
    }
    
    return aiResponse;
  } catch (error) {
    console.error('Erreur Groq:', error.message);
    return 'Yo, j\'ai eu un problème avec l\'IA! Réessaye! 😅';
  }
};

const commands = [
  new SlashCommandBuilder()
    .setName('kick')
    .setDescription('Kick un membre')
    .addUserOption(opt => opt.setName('membre').setDescription('Membre').setRequired(true))
    .addStringOption(opt => opt.setName('raison').setDescription('Raison'))
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers),
  new SlashCommandBuilder()
    .setName('ban')
    .setDescription('Ban un membre')
    .addUserOption(opt => opt.setName('membre').setDescription('Membre').setRequired(true))
    .addStringOption(opt => opt.setName('raison').setDescription('Raison'))
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),
  new SlashCommandBuilder()
    .setName('timeout')
    .setDescription('Timeout un membre')
    .addUserOption(opt => opt.setName('membre').setDescription('Membre').setRequired(true))
    .addStringOption(opt => opt.setName('duree').setDescription('10m, 2h, 1d').setRequired(true))
    .addStringOption(opt => opt.setName('raison').setDescription('Raison'))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),
  new SlashCommandBuilder()
    .setName('untimeout')
    .setDescription('Retirer un timeout')
    .addUserOption(opt => opt.setName('membre').setDescription('Membre').setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),
  new SlashCommandBuilder()
    .setName('clear')
    .setDescription('Supprimer des messages')
    .addIntegerOption(opt => opt.setName('nombre').setDescription('Nombre').setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),
  new SlashCommandBuilder()
    .setName('ticket')
    .setDescription('Créer ou fermer un ticket')
    .addStringOption(opt =>
      opt.setName('action')
        .setDescription('create/close')
        .setRequired(true)
        .addChoices({ name: 'create', value: 'create' }, { name: 'close', value: 'close' })
    ),
  new SlashCommandBuilder()
    .setName('ticketpanel')
    .setDescription('Envoyer un panneau de tickets')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
  new SlashCommandBuilder()
    .setName('verify')
    .setDescription('Valider le captcha')
    .addStringOption(opt => opt.setName('code').setDescription('Code').setRequired(true)),
  new SlashCommandBuilder()
    .setName('raidmode')
    .setDescription('Activer/désactiver le raid mode')
    .addStringOption(opt =>
      opt.setName('action')
        .setDescription('on/off')
        .setRequired(true)
        .addChoices({ name: 'on', value: 'on' }, { name: 'off', value: 'off' })
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
  new SlashCommandBuilder()
    .setName('rank')
    .setDescription('Voir le niveau')
    .addUserOption(opt => opt.setName('membre').setDescription('Membre')),
  new SlashCommandBuilder()
    .setName('giveaway')
    .setDescription('Lancer un giveaway')
    .addStringOption(opt => opt.setName('duree').setDescription('10m, 2h, 1d').setRequired(true))
    .addIntegerOption(opt => opt.setName('gagnants').setDescription('Nombre').setRequired(true))
    .addStringOption(opt => opt.setName('prix').setDescription('Prix').setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
  new SlashCommandBuilder()
    .setName('reroll')
    .setDescription('Reroll un giveaway')
    .addStringOption(opt => opt.setName('message_id').setDescription('ID du message').setRequired(true))
    .addIntegerOption(opt => opt.setName('gagnants').setDescription('Nombre').setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
  new SlashCommandBuilder()
    .setName('rr')
    .setDescription('Reaction roles')
    .addStringOption(opt =>
      opt.setName('action')
        .setDescription('add/remove')
        .setRequired(true)
        .addChoices({ name: 'add', value: 'add' }, { name: 'remove', value: 'remove' })
    )
    .addStringOption(opt => opt.setName('message_id').setDescription('ID du message').setRequired(true))
    .addStringOption(opt => opt.setName('emoji').setDescription('Emoji').setRequired(true))
    .addRoleOption(opt => opt.setName('role').setDescription('Rôle').setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles),
  new SlashCommandBuilder()
    .setName('join')
    .setDescription('Rejoindre le vocal'),
  new SlashCommandBuilder()
    .setName('leave')
    .setDescription('Quitter le vocal'),
  new SlashCommandBuilder()
    .setName('play')
    .setDescription('Jouer une musique')
    .addStringOption(opt => opt.setName('query').setDescription('Lien ou recherche').setRequired(true)),
  new SlashCommandBuilder()
    .setName('pause')
    .setDescription('Pause la musique'),
  new SlashCommandBuilder()
    .setName('resume')
    .setDescription('Reprendre la musique'),
  new SlashCommandBuilder()
    .setName('skip')
    .setDescription('Passer la musique'),
  new SlashCommandBuilder()
    .setName('stop')
    .setDescription('Stopper la musique'),
  new SlashCommandBuilder()
    .setName('queue')
    .setDescription('Afficher la file'),
  new SlashCommandBuilder()
    .setName('warn')
    .setDescription('Avertir un membre')
    .addUserOption(opt => opt.setName('membre').setDescription('Membre').setRequired(true))
    .addStringOption(opt => opt.setName('raison').setDescription('Raison').setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),
  new SlashCommandBuilder()
    .setName('warns')
    .setDescription('Voir les avertissements')
    .addUserOption(opt => opt.setName('membre').setDescription('Membre')),
  new SlashCommandBuilder()
    .setName('clearwarn')
    .setDescription('Effacer les avertissements')
    .addUserOption(opt => opt.setName('membre').setDescription('Membre').setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),
  new SlashCommandBuilder()
    .setName('mute')
    .setDescription('Mute un membre en vocal')
    .addUserOption(opt => opt.setName('membre').setDescription('Membre').setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.MuteMembers),
  new SlashCommandBuilder()
    .setName('unmute')
    .setDescription('Unmute un membre en vocal')
    .addUserOption(opt => opt.setName('membre').setDescription('Membre').setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.MuteMembers),
  new SlashCommandBuilder()
    .setName('remind')
    .setDescription('Créer un rappel')
    .addStringOption(opt => opt.setName('duree').setDescription('10m, 2h, 1d').setRequired(true))
    .addStringOption(opt => opt.setName('message').setDescription('Message').setRequired(true)),
  new SlashCommandBuilder()
    .setName('poll')
    .setDescription('Créer un sondage')
    .addStringOption(opt => opt.setName('question').setDescription('Question').setRequired(true))
    .addStringOption(opt => opt.setName('option1').setDescription('Option 1').setRequired(true))
    .addStringOption(opt => opt.setName('option2').setDescription('Option 2').setRequired(true))
    .addStringOption(opt => opt.setName('option3').setDescription('Option 3').setRequired(false))
    .addStringOption(opt => opt.setName('option4').setDescription('Option 4').setRequired(false)),
  new SlashCommandBuilder()
    .setName('userinfo')
    .setDescription('Info sur un utilisateur')
    .addUserOption(opt => opt.setName('membre').setDescription('Membre')),
  new SlashCommandBuilder()
    .setName('serverinfo')
    .setDescription('Info sur le serveur'),
  new SlashCommandBuilder()
    .setName('avatar')
    .setDescription('Afficher l\'avatar')
    .addUserOption(opt => opt.setName('membre').setDescription('Membre')),
  new SlashCommandBuilder()
    .setName('ping')
    .setDescription('Latence du bot'),
  new SlashCommandBuilder()
    .setName('help')
    .setDescription('Liste des commandes'),
  new SlashCommandBuilder()
    .setName('announce')
    .setDescription('Faire une annonce')
    .addStringOption(opt => opt.setName('titre').setDescription('Titre').setRequired(true))
    .addStringOption(opt => opt.setName('message').setDescription('Message').setRequired(true))
    .addChannelOption(opt => opt.setName('canal').setDescription('Canal').setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
  new SlashCommandBuilder()
    .setName('stats')
    .setDescription('Statistiques du serveur'),
  new SlashCommandBuilder()
    .setName('suggestion')
    .setDescription('Faire une suggestion')
    .addStringOption(opt => opt.setName('titre').setDescription('Titre').setRequired(true))
    .addStringOption(opt => opt.setName('description').setDescription('Description').setRequired(true)),
  new SlashCommandBuilder()
    .setName('setup')
    .setDescription('Configuration du serveur')
    .addStringOption(opt =>
      opt.setName('option')
        .setDescription('Quoi configurer')
        .setRequired(true)
        .addChoices(
          { name: 'log-channel', value: 'logchannel' },
          { name: 'welcome-channel', value: 'welcomechannel' },
          { name: 'level-channel', value: 'levelchannel' },
          { name: 'ticket-category', value: 'ticketcategory' }
        )
    )
    .addChannelOption(opt => opt.setName('canal').setDescription('Canal/Catégorie').setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
  new SlashCommandBuilder()
    .setName('protections')
    .setDescription('Afficher l\'état des protections')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
  new SlashCommandBuilder()
    .setName('protectionsettings')
    .setDescription('Configurer les protections')
    .addStringOption(opt =>
      opt.setName('protection')
        .setDescription('Protection à configurer')
        .setRequired(true)
        .addChoices(
          { name: 'anti-spam', value: 'antispam' },
          { name: 'anti-raid', value: 'antiraid' },
          { name: 'anti-pub', value: 'antiads' },
          { name: 'automod', value: 'automod' },
          { name: 'logging', value: 'logging' }
        )
    )
    .addStringOption(opt =>
      opt.setName('action')
        .setDescription('Activer/Désactiver')
        .setRequired(true)
        .addChoices(
          { name: 'activer', value: 'on' },
          { name: 'désactiver', value: 'off' }
        )
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
  new SlashCommandBuilder()
    .setName('8ball')
    .setDescription('Question à la boule magique')
    .addStringOption(opt => opt.setName('question').setDescription('Ta question').setRequired(true)),
  new SlashCommandBuilder()
    .setName('dice')
    .setDescription('Lancer un dé')
    .addIntegerOption(opt => opt.setName('faces').setDescription('Nombre de faces').setRequired(false)),
  new SlashCommandBuilder()
    .setName('report')
    .setDescription('Signaler un utilisateur')
    .addUserOption(opt => opt.setName('utilisateur').setDescription('Utilisateur').setRequired(true))
    .addStringOption(opt => opt.setName('raison').setDescription('Raison').setRequired(true)),
  new SlashCommandBuilder()
    .setName('bug')
    .setDescription('Signaler un bug')
    .addStringOption(opt => opt.setName('description').setDescription('Description du bug').setRequired(true)),
  new SlashCommandBuilder()
    .setName('joke')
    .setDescription('Une blague aléatoire'),
  new SlashCommandBuilder()
    .setName('quote')
    .setDescription('Une citation aléatoire'),
  new SlashCommandBuilder()
    .setName('slots')
    .setDescription('Jeu des machines à sous'),
  new SlashCommandBuilder()
    .setName('rps')
    .setDescription('Pierre-Papier-Ciseaux')
    .addStringOption(opt =>
      opt.setName('choix')
        .setDescription('Ton choix')
        .setRequired(true)
        .addChoices(
          { name: 'Pierre', value: 'pierre' },
          { name: 'Papier', value: 'papier' },
          { name: 'Ciseaux', value: 'ciseaux' }
        )
    ),
  new SlashCommandBuilder()
    .setName('calc')
    .setDescription('Calculatrice')
    .addStringOption(opt => opt.setName('expression').setDescription('Ex: 5+3*2').setRequired(true)),
  new SlashCommandBuilder()
    .setName('afk')
    .setDescription('Mettre un statut AFK')
    .addStringOption(opt => opt.setName('raison').setDescription('Raison').setRequired(false)),
  new SlashCommandBuilder()
    .setName('color')
    .setDescription('Créer une couleur personnalisée')
    .addStringOption(opt => opt.setName('nom').setDescription('Nom de la couleur').setRequired(true))
    .addStringOption(opt => opt.setName('hex').setDescription('Couleur hex (ex: FF0000)').setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles),
  new SlashCommandBuilder()
    .setName('botinfo')
    .setDescription('Infos sur le bot'),
  new SlashCommandBuilder()
    .setName('uptime')
    .setDescription('Durée d\'activité du bot'),
  new SlashCommandBuilder()
    .setName('setstatus')
    .setDescription('Changer le statut du bot')
    .addStringOption(opt => opt.setName('statut').setDescription('Nouveau statut').setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
  new SlashCommandBuilder()
    .setName('reload')
    .setDescription('Redémarrer le bot')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
  new SlashCommandBuilder()
    .setName('poweroff')
    .setDescription('Arrêter le bot')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
  new SlashCommandBuilder()
    .setName('logs')
    .setDescription('Voir les derniers logs du bot')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
  new SlashCommandBuilder()
    .setName('leaderboard')
    .setDescription('Voir le classement XP'),
  new SlashCommandBuilder()
    .setName('serverstat')
    .setDescription('Statistiques détaillées du serveur'),
  new SlashCommandBuilder()
    .setName('memberslist')
    .setDescription('Liste les top membres'),
  new SlashCommandBuilder()
    .setName('invite')
    .setDescription('Obtenir le lien d\'invitation du bot'),
  new SlashCommandBuilder()
    .setName('support')
    .setDescription('Accéder au support'),
  new SlashCommandBuilder()
    .setName('randomquiz')
    .setDescription('Jouer à un quiz aléatoire'),
  // 🔐 COMMANDES CAPTCHA
  new SlashCommandBuilder()
    .setName('captcha')
    .setDescription('Gérer le système de captcha')
    .addSubcommand(sub => sub.setName('enable').setDescription('Activer le captcha'))
    .addSubcommand(sub => sub.setName('disable').setDescription('Désactiver le captcha'))
    .addSubcommand(sub => sub
      .setName('type')
      .setDescription('Changer le type de captcha')
      .addStringOption(opt => opt
        .setName('type')
        .setDescription('Type: code, math, image')
        .setRequired(true)
        .addChoices(
          { name: 'Code Simple', value: 'code' },
          { name: 'Problème Mathématique', value: 'math' },
          { name: 'Code Image', value: 'image' }
        )
      )
    )
    .addSubcommand(sub => sub.setName('status').setDescription('Voir l\'état du captcha'))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
  // ⚙️ COMMANDES SETTINGS
  new SlashCommandBuilder()
    .setName('settings')
    .setDescription('Gérer les paramètres du serveur')
    .addSubcommand(sub => sub
      .setName('welcome')
      .setDescription('Configurer le canal de bienvenue')
      .addChannelOption(opt => opt.setName('channel').setDescription('Canal').setRequired(true))
    )
    .addSubcommand(sub => sub
      .setName('logs')
      .setDescription('Configurer le canal de logs')
      .addChannelOption(opt => opt.setName('channel').setDescription('Canal').setRequired(true))
    )
    .addSubcommand(sub => sub
      .setName('prefix')
      .setDescription('Changer le préfixe')
      .addStringOption(opt => opt.setName('prefix').setDescription('Préfixe').setRequired(true).setMaxLength(5))
    )
    .addSubcommand(sub => sub
      .setName('language')
      .setDescription('Changer la langue')
      .addStringOption(opt => opt
        .setName('language')
        .setDescription('Langue')
        .setRequired(true)
        .addChoices(
          { name: 'Français', value: 'fr' },
          { name: 'English', value: 'en' },
          { name: 'Español', value: 'es' }
        )
      )
    )
    .addSubcommand(sub => sub.setName('view').setDescription('Voir tous les paramètres'))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
].map(cmd => cmd.toJSON());

const ensureGuildQueue = (guildId) => {
  if (!queues.has(guildId)) {
    const player = createAudioPlayer();
    queues.set(guildId, { player, tracks: [], connection: null, textChannelId: null });
  }
  return queues.get(guildId);
};

const playNext = async (guildId) => {
  const queue = ensureGuildQueue(guildId);
  const track = queue.tracks.shift();
  if (!track) return;

  const stream = await play.stream(track.url);
  const resource = createAudioResource(stream.stream, { inputType: stream.type });
  queue.player.play(resource);

  queue.player.once(AudioPlayerStatus.Idle, () => {
    playNext(guildId).catch(() => {});
  });

  if (queue.textChannelId) {
    const channel = await client.channels.fetch(queue.textChannelId).catch(() => null);
    if (channel) {
      channel.send(`🎵 Lecture: **${track.title}**`).catch(() => {});
    }
  }
};

const connectToVoice = async (interaction) => {
  const member = await interaction.guild.members.fetch(interaction.user.id);
  const voiceChannel = member.voice.channel;
  if (!voiceChannel) {
    await interaction.reply({ content: 'Tu dois être en vocal.', ephemeral: true });
    return null;
  }

  const queue = ensureGuildQueue(interaction.guild.id);
  const connection = joinVoiceChannel({
    channelId: voiceChannel.id,
    guildId: voiceChannel.guild.id,
    adapterCreator: voiceChannel.guild.voiceAdapterCreator
  });

  await entersState(connection, VoiceConnectionStatus.Ready, 20_000);
  connection.subscribe(queue.player);
  queue.connection = connection;
  return queue;
};

const sendCaptcha = async (member, code) => {
  const message = `Bienvenue ${member.user.username} !\nPour vérifier ton compte: /verify ${code}\nExpiration: ${config.CAPTCHA_EXPIRE_SECONDS}s`;
  try {
    await member.send(message);
    return;
  } catch {
    // ignore
  }
  if (config.CAPTCHA_CHANNEL_ID) {
    const channel = member.guild.channels.cache.get(String(config.CAPTCHA_CHANNEL_ID));
    if (channel) {
      channel.send(`${member} ${message}`).catch(() => {});
    }
  }
};

const applyCaptchaRoles = async (member) => {
  if (config.UNVERIFIED_ROLE_ID) {
    const role = member.guild.roles.cache.get(String(config.UNVERIFIED_ROLE_ID));
    if (role) await member.roles.add(role).catch(() => {});
  }
  if (config.VERIFIED_ROLE_ID) {
    const role = member.guild.roles.cache.get(String(config.VERIFIED_ROLE_ID));
    if (role) await member.roles.remove(role).catch(() => {});
  }
};

const getLogChannel = (guild) => {
  if (!config.LOG_CHANNEL_ID) return null;
  return guild.channels.cache.get(String(config.LOG_CHANNEL_ID)) || null;
};

const createTicketChannel = async (guild, user, categoryLabel) => {
  let category = null;
  if (config.TICKET_CATEGORY_ID) {
    console.log(`🔍 Recherche catégorie ID: ${config.TICKET_CATEGORY_ID}`);
    const channel = guild.channels.cache.get(String(config.TICKET_CATEGORY_ID));
    console.log(`📋 Salon trouvé:`, channel ? `${channel.name} (type: ${channel.type})` : 'Non trouvé');
    
    if (channel && channel.type === 4) {
      category = channel;
      console.log(`✅ Catégorie validée: ${channel.name}`);
    } else if (channel) {
      console.warn(`⚠️ Le salon existe mais n'est pas une catégorie (type: ${channel.type})`);
    } else {
      console.warn(`⚠️ Catégorie de tickets non trouvée dans le cache: ${config.TICKET_CATEGORY_ID}`);
      console.log(`📊 Salons en cache: ${guild.channels.cache.size}`);
    }
  }

  const overwrites = [
    {
      id: guild.roles.everyone.id,
      deny: ['ViewChannel']
    },
    {
      id: user.id,
      allow: ['ViewChannel', 'SendMessages']
    }
  ];

  if (config.STAFF_ROLE_ID) {
    overwrites.push({
      id: String(config.STAFF_ROLE_ID),
      allow: ['ViewChannel', 'SendMessages']
    });
  }

  const safeCategory = categoryLabel
    ? categoryLabel.toLowerCase().replace(/[^a-z0-9-]/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, '')
    : null;

  const channel = await guild.channels.create({
    name: safeCategory ? `ticket-${safeCategory}-${user.username}` : `ticket-${user.username}`,
    type: 0,
    parent: category ? category.id : null,
    topic: categoryLabel ? `Catégorie: ${categoryLabel}` : null,
    permissionOverwrites: overwrites
  });

  storage.setTicket(channel.id, user.id, 'open');

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('ticket_close')
      .setLabel('🔴 Fermer le ticket')
      .setStyle(ButtonStyle.Danger)
  );

  const infoEmbed = new EmbedBuilder()
    .setTitle('🎫 Ticket Ouvert')
    .setDescription(
      `**Utilisateur :** ${user}\n` +
      `**Catégorie :** ${categoryLabel || 'Support Général'}\n\n` +
      'Merci de décrire votre demande clairement.\n' +
      'Un membre du staff vous répondra dès que possible.'
    )
    .setColor(0x5865F2)
    .setFooter({ text: 'LvCreations Bot • Support' })
    .setTimestamp();

  await channel.send({ embeds: [infoEmbed], components: [row] });
  return channel;
};

const updateStatsMessage = async () => {
  try {
    const channel = await client.channels.fetch(STATS_CHANNEL_ID).catch(() => null);
    if (!channel?.isTextBased?.()) return;

    // Calcul de l'uptime
    const uptime = Date.now() - botStartTime;
    const days = Math.floor(uptime / 86400000);
    const hours = Math.floor((uptime % 86400000) / 3600000);
    const minutes = Math.floor((uptime % 3600000) / 60000);
    const seconds = Math.floor((uptime % 60000) / 1000);
    const uptimeStr = `${days}j ${hours}h ${minutes}m ${seconds}s`;

    // Mémoire utilisée
    const memUsage = process.memoryUsage();
    const memUsedMB = (memUsage.heapUsed / 1024 / 1024).toFixed(2);
    const memTotalMB = (os.totalmem() / 1024 / 1024).toFixed(2);
    const memPercent = Math.floor((memUsage.heapUsed / os.totalmem()) * 100);
    const memBarCount = Math.max(0, Math.min(20, Math.floor(memPercent / 5)));
    const memBar = '▰'.repeat(memBarCount) + '▱'.repeat(20 - memBarCount);

    // CPU usage
    const cpus = os.cpus();
    const cpuModel = cpus[0]?.model || 'Unknown';
    const cpuCount = cpus.length;
    
    // Latence avec indicateur
    const ping = client.ws.ping || 0;
    const pingEmoji = ping < 100 ? '🟢' : ping < 200 ? '🟡' : '🔴';
    const pingBarCount = Math.max(0, Math.min(20, Math.floor(ping / 10)));
    const pingBar = '▰'.repeat(pingBarCount) + '▱'.repeat(20 - pingBarCount);

    // Status global avec plusieurs critères
    let statusEmoji = '🟢';
    let statusText = 'Excellent';
    let color = 0x00FF00; // Vert
    
    if (memPercent > 70 || ping > 150) {
      statusEmoji = '🟡';
      statusText = 'Acceptable';
      color = 0xFFAA00; // Orange
    }
    if (memPercent > 85 || ping > 250) {
      statusEmoji = '🔴';
      statusText = 'Critique';
      color = 0xFF0000; // Rouge
    }

    // Compte les files d'attente musique actives
    let activeQueues = 0;
    let totalSongs = 0;
    for (const queue of queues.values()) {
      if (queue.songs && queue.songs.length > 0) {
        activeQueues++;
        totalSongs += queue.songs.length;
      }
    }

    // Statistiques Discord
    let totalMembers = 0;
    let onlineMembers = 0;
    for (const guild of client.guilds.cache.values()) {
      totalMembers += guild.memberCount || 0;
      onlineMembers += guild.members.cache.filter(m => m.presence?.status !== 'offline').size;
    }
    
    let textChannels = 0;
    let voiceChannels = 0;
    let categories = 0;
    let threads = 0;
    for (const channel of client.channels.cache.values()) {
      if (channel.type === 0) textChannels++;
      else if (channel.type === 2) voiceChannels++;
      else if (channel.type === 4) categories++;
      else if (channel.type === 11 || channel.type === 12) threads++;
    }

    // Tickets stats
    const tickets = storage.data?.tickets || {};
    const openTickets = Object.values(tickets).filter(t => t.status === 'open').length;
    const totalTickets = Object.keys(tickets).length;

    // Node.js info
    const nodeVersion = process.version;
    const platform = `${os.platform()} ${os.arch()}`;

    // Embed principal avec design moderne
    const embed = new EmbedBuilder()
      .setAuthor({ 
        name: '🤖 LVCREATIONS BOT - DASHBOARD EN TEMPS RÉEL', 
        iconURL: client.user.avatarURL() 
      })
      .setThumbnail(client.user.avatarURL())
      .setDescription(
        `╔═══════════════════════════════════╗\n` +
        `║ ${statusEmoji} **STATUT: ${statusText.toUpperCase()}** ${statusEmoji}\n` +
        `║ ⏰ Uptime: **${uptimeStr}**\n` +
        `╚═══════════════════════════════════╝`
      )
      .addFields(
        { 
          name: '📊 PERFORMANCE SYSTÈME', 
          value: 
            `**${pingEmoji} Latence API**\n` +
            `\`${ping}ms\` ${pingBar}\n\n` +
            `**💾 Mémoire Utilisée**\n` +
            `\`${memPercent}%\` (${memUsedMB}MB / ${memTotalMB}MB)\n` +
            `${memBar}\n\n` +
            `**⚙️ Processeur**\n` +
            `\`${cpuCount}x ${cpuModel.substring(0, 30)}\``,
          inline: false 
        },
        { 
          name: '🌐 DISCORD RÉSEAU', 
          value: 
            `**🏠 Serveurs:** \`${client.guilds.cache.size}\`\n` +
            `**👥 Membres Totaux:** \`${totalMembers}\`\n` +
            `**🟢 Membres En Ligne:** \`${onlineMembers}\`\n` +
            `**📁 Salons en Cache:** \`${client.channels.cache.size}\``,
          inline: true 
        },
        { 
          name: '📡 INFRASTRUCTURE', 
          value: 
            `**💬 Salons Texte:** \`${textChannels}\`\n` +
            `**🔊 Salons Vocaux:** \`${voiceChannels}\`\n` +
            `**📂 Catégories:** \`${categories}\`\n` +
            `**🧵 Threads:** \`${threads}\``,
          inline: true 
        },
        { 
          name: '🎵 SYSTÈME MUSIQUE', 
          value: 
            `**🎶 Files Actives:** \`${activeQueues}\`\n` +
            `**📀 Chansons en File:** \`${totalSongs}\`\n` +
            `**🎧 Connexions Vocales:** \`${client.voice.adapters.size}\`\n` +
            `**🔊 Status:** ${activeQueues > 0 ? '🟢 Actif' : '⚪ Inactif'}`,
          inline: true 
        },
        { 
          name: '🎫 SYSTÈME TICKETS', 
          value: 
            `**📨 Tickets Ouverts:** \`${openTickets}\`\n` +
            `**📊 Total Créés:** \`${totalTickets}\`\n` +
            `**✅ Tickets Fermés:** \`${totalTickets - openTickets}\`\n` +
            `**📈 Taux Résolution:** \`${totalTickets > 0 ? Math.floor(((totalTickets - openTickets) / totalTickets) * 100) : 0}%\``,
          inline: true 
        },
        { 
          name: '🛡️ PROTECTIONS ACTIVES', 
          value: 
            `✅ **Anti-Spam** | Actif\n` +
            `✅ **Anti-Raid** | Actif\n` +
            `✅ **Anti-Pub** | Actif\n` +
            `✅ **AutoMod** | Actif\n` +
            `✅ **Captcha** | ${config.CAPTCHA_ENABLED ? 'Actif' : 'Inactif'}`,
          inline: true 
        },
        { 
          name: '💻 INFORMATIONS TECHNIQUES', 
          value: 
            `**📦 Node.js:** \`${nodeVersion}\`\n` +
            `**🤖 Discord.js:** \`v14\`\n` +
            `**🖥️ Plateforme:** \`${platform}\`\n` +
            `**🆔 Bot ID:** \`${client.user.id}\`\n` +
            `**📝 Version:** \`LvCreations Bot v2.1\``,
          inline: false 
        }
      )
      .setColor(color)
      .setFooter({ 
        text: `🔄 Actualisé automatiquement toutes les 10s • © LvCreations 2026`
      })
      .setTimestamp();

    if (!statsMessageId) {
      const msg = await channel.send({ embeds: [embed] });
      statsMessageId = msg.id;
      storage.setStatsMessageId(msg.id);
    } else {
      const msg = await channel.messages.fetch(statsMessageId).catch(() => null);
      if (msg) {
        await msg.edit({ embeds: [embed] }).catch(() => {});
      } else {
        const newMsg = await channel.send({ embeds: [embed] });
        statsMessageId = newMsg.id;
        storage.setStatsMessageId(newMsg.id);
      }
    }
  } catch (error) {
    console.error('Erreur updateStats:', error.message);
    console.error('Stack:', error.stack);
  }
};

const updateInfoPanel = async () => {
  try {
    const channel = await client.channels.fetch(INFO_CHANNEL_ID).catch(() => null);
    if (!channel?.isTextBased?.()) return;

    const embed = new EmbedBuilder()
      .setAuthor({ 
        name: '🌐 LVCREATIONS - INFORMATIONS & LIENS', 
        iconURL: client.user.avatarURL() 
      })
      .setThumbnail(client.user.avatarURL())
      .setDescription(
        '**Bienvenue sur le serveur LvCreations !**\n\n' +
        '╔═══════════════════════════════════╗\n' +
        '║ 🌍 **SITE WEB OFFICIEL**\n' +
        '╚═══════════════════════════════════╝'
      )
      .addFields(
        {
          name: '🔗 Lien Principal',
          value: '**[🌐 Visiter LvCreations](https://lvcreations.tip4serv.com/?exit_customizer=true#discord)**\n\n' +
                 '*Découvre nos services, projets et bien plus !*',
          inline: false
        },
        {
          name: '💬 Discord',
          value: 'Tu es déjà sur notre serveur Discord !\nUtilise `/help` pour voir toutes les commandes du bot.',
          inline: true
        },
        {
          name: '🤖 Bot',
          value: `**Version:** \`v2.1\`\n**Status:** 🟢 En Ligne\n**Commandes:** \`50+\``,
          inline: true
        },
        {
          name: '📢 Fonctionnalités',
          value: 
            '✅ **Modération Avancée**\n' +
            '✅ **Système de Tickets**\n' +
            '✅ **Musique HD**\n' +
            '✅ **Giveaways & Events**\n' +
            '✅ **Système de Niveaux**\n' +
            '✅ **Protection Anti-Raid**',
          inline: false
        },
        {
          name: '🎯 Liens Rapides',
          value: 
            '🌐 [Site Web](https://lvcreations.tip4serv.com/?exit_customizer=true#discord)\n' +
            '📱 [Discord](https://discord.gg/lvcreations)\n' +
            '📧 Support: `/ticket create`',
          inline: false
        }
      )
      .setColor(0x5865F2)
      .setFooter({ 
        text: '© LvCreations 2026 • Powered by LvCreations Bot',
        iconURL: client.user.avatarURL()
      })
      .setTimestamp();

    if (!infoMessageId) {
      const msg = await channel.send({ embeds: [embed] });
      infoMessageId = msg.id;
      storage.setInfoMessageId(msg.id);
      console.log('✅ Panneau d\'informations créé');
    } else {
      const msg = await channel.messages.fetch(infoMessageId).catch(() => null);
      if (msg) {
        await msg.edit({ embeds: [embed] }).catch(() => {});
        console.log('✅ Panneau d\'informations mis à jour');
      } else {
        const newMsg = await channel.send({ embeds: [embed] });
        infoMessageId = newMsg.id;
        storage.setInfoMessageId(newMsg.id);
        console.log('✅ Nouveau panneau d\'informations créé');
      }
    }
  } catch (error) {
    console.error('Erreur updateInfoPanel:', error.message);
  }
};

const registerCommands = async () => {
  if (!config.DISCORD_TOKEN || !config.CLIENT_ID) return;
  const rest = new REST({ version: '10' }).setToken(config.DISCORD_TOKEN);
  
  try {
    // Try guild sync first
    if (config.GUILD_ID && config.SYNC_COMMANDS) {
      console.log(`📤 Synchronisation des commandes au serveur ${config.GUILD_ID}...`);
      await rest.put(Routes.applicationGuildCommands(config.CLIENT_ID, String(config.GUILD_ID)), {
        body: commands
      });
      console.log(`✅ ${commands.length} commandes synchronisées au serveur !`);
      return;
    }
    
    // If sync disabled, just log
    if (!config.SYNC_COMMANDS) {
      console.log(`📋 ${commands.length} commandes chargées (sync désactivé - utilisez slash commands)`);
      return;
    }
    
    // Global sync as fallback
    console.log(`📤 Synchronisation globale des commandes...`);
    await rest.put(Routes.applicationCommands(config.CLIENT_ID), { body: commands });
    console.log(`✅ ${commands.length} commandes synchronisées globalement !`);
  } catch (error) {
    console.error(`❌ Erreur lors de la synchronisation des commandes:`, error.message);
  }
};

client.once(Events.ClientReady, async () => {
  await registerCommands();
  const readyLog = `🟢 BOT DÉMARRÉ: ${client.user.tag}`;
  addLog(readyLog, 'SUCCESS', {
    'Bot ID': client.user.id,
    'Serveurs': client.guilds.cache.size,
    'Utilisateurs': client.users.cache.size,
    'Version Node': process.version,
    'Version Discord.js': require('discord.js').version,
    'RAM': `${Math.round(process.memoryUsage().heapUsed / 1024 / 1024)}MB`,
    'Platform': os.platform(),
    'Commandes': commands.length
  });
  console.log(`Connecté en tant que ${client.user.tag}`);
  
  // Créer/Mettre à jour le panneau d'informations
  await updateInfoPanel();
  
  // Changer les statuts toutes les 2 minutes
  const changeStatus = () => {
    const status = statuses[currentStatusIndex];
    client.user.setActivity(status.name, { type: status.type });
    currentStatusIndex = (currentStatusIndex + 1) % statuses.length;
  };
  
  changeStatus(); // Appel initial
  setInterval(changeStatus, 2 * 60 * 1000); // Change toutes les 2 minutes (120000ms)
  console.log(`✅ Système de statuts activé - ${statuses.length} statuts disponibles`);
  
  // Connexion H24 au salon vocal
  if (config.VOICE_CHANNEL_24H) {
    const connectTo24hVoice = async () => {
      try {
        const channel = await client.channels.fetch(String(config.VOICE_CHANNEL_24H)).catch(() => null);
        if (!channel || !channel.isVoiceBased()) {
          console.log(`❌ Canal vocal 24h introuvable ou invalide`);
          return;
        }
        
        const queue = ensureGuildQueue(channel.guildId);
        if (queue.connection) return; // Déjà connecté
        
        const connection = joinVoiceChannel({
          channelId: channel.id,
          guildId: channel.guild.id,
          adapterCreator: channel.guild.voiceAdapterCreator
        });
        
        await entersState(connection, VoiceConnectionStatus.Ready, 20_000).catch(() => null);
        connection.subscribe(queue.player);
        queue.connection = connection;
        
        console.log(`🎤 Bot connecté au salon 24h: ${channel.name}`);
        
        // Reconnecter si déconnecté
        connection.on(VoiceConnectionStatus.Disconnected, async () => {
          try {
            await Promise.race([
              entersState(connection, VoiceConnectionStatus.Signalling, 5_000),
              entersState(connection, VoiceConnectionStatus.Connecting, 5_000)
            ]);
          } catch (error) {
            console.log(`🔄 Reconnexion au salon 24h...`);
            setTimeout(connectTo24hVoice, 5000);
          }
        });
      } catch (error) {
        console.error(`❌ Erreur connexion 24h:`, error.message);
      }
    };
    
    connectTo24hVoice();
  }

  // Afficher les stats en temps réel
  updateStatsMessage();
  if (statsInterval) clearInterval(statsInterval);
  statsInterval = setInterval(updateStatsMessage, 10000); // Mise à jour toutes les 10 secondes
  console.log('✅ Affichage des stats en temps réel activé (mise à jour toutes les 10s)');

  // 🤖 Rappel IA toutes les 5 minutes (édite le même message)
  if (config.AI_CHANNEL_ID) {
    let aiReminderMessageId = null;

    const updateAIReminder = async () => {
      try {
        const aiChannel = client.channels.cache.get(config.AI_CHANNEL_ID);
        if (aiChannel && aiChannel.isTextBased()) {
          const embed = new EmbedBuilder()
            .setTitle('🤖 Intelligence Artificielle Disponible')
            .setDescription('💬 **Posez-moi n\'importe quelle question!**\n\nJe suis une IA québécoise prête à discuter avec vous.')
            .addFields(
              { name: '💡 Exemples', value: '• "Explique-moi comment fonctionne Discord"\n• "Raconte-moi une blague"\n• "C\'est quoi FiveM?"\n• "Aide-moi avec un script Lua"', inline: false },
              { name: '⚡ Réponse', value: 'Instantanée avec Groq AI (llama-3.3-70b)', inline: false }
            )
            .setColor(0x667eea)
            .setFooter({ text: 'LvCreations Bot • IA temps réel' })
            .setTimestamp();

          if (aiReminderMessageId) {
            // Éditer le message existant
            try {
              const msg = await aiChannel.messages.fetch(aiReminderMessageId);
              await msg.edit({ embeds: [embed] });
              console.log('📝 Rappel IA modifié');
            } catch (error) {
              // Message supprimé, en envoyer un nouveau
              const newMsg = await aiChannel.send({ embeds: [embed] });
              aiReminderMessageId = newMsg.id;
              console.log('📢 Nouveau rappel IA envoyé (ancien supprimé)');
            }
          } else {
            // Premier envoi
            const msg = await aiChannel.send({ embeds: [embed] });
            aiReminderMessageId = msg.id;
            console.log('📢 Rappel IA envoyé');
          }
        }
      } catch (error) {
        console.error('Erreur rappel IA:', error.message);
      }
    };

    // Envoyer/modifier immédiatement au démarrage
    setTimeout(updateAIReminder, 5000);
    
    // Puis toutes les 5 minutes
    setInterval(updateAIReminder, 5 * 60 * 1000); // 5 minutes
    console.log('✅ Rappels IA activés (édition du même message toutes les 5 minutes)');
  }
});

client.on(Events.GuildMemberAdd, async (member) => {
  const guildId = member.guild.id;
  const now = Date.now();
  const window = (config.RAID_WINDOW_SECONDS || 20) * 1000;
  const list = joinTimes.get(guildId) || [];
  list.push(now);
  joinTimes.set(guildId, list.filter(t => t >= now - window));

  if (config.RAID_MAX_JOINS && config.RAID_MODE_DURATION) {
    if (joinTimes.get(guildId).length >= config.RAID_MAX_JOINS) {
      raidModeUntil.set(guildId, Date.now() + config.RAID_MODE_DURATION * 1000);
    }
  }

  if (raidModeUntil.get(guildId) && Date.now() < raidModeUntil.get(guildId)) {
    if (config.RAID_ACTION === 'kick') {
      member.kick('Raid protection').catch(() => {});
      return;
    }
  }

  if (config.WELCOME_CHANNEL_ID) {
    const channel = member.guild.channels.cache.get(String(config.WELCOME_CHANNEL_ID));
    if (channel) {
      const embed = new EmbedBuilder()
        .setTitle('Bienvenue')
        .setDescription(`Bienvenue ${member} sur **${member.guild.name}** !`)
        .setColor(0x57F287);
      channel.send({ embeds: [embed] }).catch(() => {});
    }
  }

  if (!config.CAPTCHA_ENABLED) return;

  const code = crypto.randomBytes(3).toString('hex');
  const expiresAt = Date.now() + (config.CAPTCHA_EXPIRE_SECONDS || 600) * 1000;
  captchaCodes.set(member.id, { code, expiresAt, guildId });
  await applyCaptchaRoles(member);
  await sendCaptcha(member, code);
});

client.on(Events.GuildMemberRemove, async (member) => {
  if (!config.WELCOME_CHANNEL_ID) return;
  const channel = member.guild.channels.cache.get(String(config.WELCOME_CHANNEL_ID));
  if (!channel) return;
  const embed = new EmbedBuilder()
    .setTitle('Au revoir')
    .setDescription(`${member.user.tag} a quitté le serveur.`)
    .setColor(0xED4245);
  channel.send({ embeds: [embed] }).catch(() => {});
});

client.on(Events.MessageCreate, async (message) => {
  if (!message.guild || message.author.bot) return;
  
  console.log(`📨 Message reçu: "${message.content}" dans le canal ${message.channelId} (AI_CHANNEL_ID: ${config.AI_CHANNEL_ID})`);
  
  // 🤖 AI Chat System
  if (config.AI_CHANNEL_ID && message.channelId === config.AI_CHANNEL_ID) {
    console.log('🤖 Détecté canal IA - génération réponse...');
    try {
      await message.channel.sendTyping();
      const aiResponse = await generateAIResponse(message.content);
      
      if (aiResponse) {
        await message.reply({
          content: aiResponse,
          allowedMentions: { repliedUser: false }
        });
        
        addLog(`💬 Chat IA: ${message.author.username}`, 'INFO', {
          'Message': message.content.substring(0, 80),
          'Réponse': aiResponse.substring(0, 80)
        });
      }
    } catch (error) {
      console.error('Erreur AI chat:', error);
      await message.reply({ 
        content: `❌ Erreur IA: ${error.message}`, 
        allowedMentions: { repliedUser: false }
      }).catch(() => {});
    }
    return;
  }
  
  // XP System
  const now = Date.now();
  const last = levelCooldowns.get(message.author.id) || 0;
  if (now - last < 30_000) return;
  levelCooldowns.set(message.author.id, now);

  const xpGain = Math.floor(Math.random() * 11) + 5;
  const row = storage.getLevel(message.author.id);
  let xp = row ? row.xp + xpGain : xpGain;
  let level = row ? row.level : 1;
  let next = level * 100;
  let leveled = false;

  while (xp >= next) {
    xp -= next;
    level += 1;
    next = level * 100;
    leveled = true;
  }

  storage.setLevel(message.author.id, xp, level);

  if (leveled) {
    const channelId = config.LEVEL_CHANNEL_ID || message.channel.id;
    const channel = message.guild.channels.cache.get(String(channelId));
    if (channel) channel.send(`${message.author} a atteint le niveau ${level} !`).catch(() => {});
  }
});

client.on(Events.MessageDelete, async (message) => {
  if (!message.guild || message.author?.bot) return;
  const channel = getLogChannel(message.guild);
  if (!channel) return;
  const embed = new EmbedBuilder()
    .setTitle('Message supprimé')
    .addFields(
      { name: 'Auteur', value: message.author?.tag || 'Inconnu', inline: false },
      { name: 'Salon', value: `${message.channel}`, inline: false }
    )
    .setColor(0xFEE75C);
  if (message.content) embed.addFields({ name: 'Contenu', value: message.content.slice(0, 1000) });
  channel.send({ embeds: [embed] }).catch(() => {});
});

client.on(Events.MessageUpdate, async (oldMsg, newMsg) => {
  if (!oldMsg.guild || oldMsg.author?.bot) return;
  if (oldMsg.content === newMsg.content) return;
  const channel = getLogChannel(oldMsg.guild);
  if (!channel) return;
  const embed = new EmbedBuilder()
    .setTitle('Message modifié')
    .addFields(
      { name: 'Auteur', value: oldMsg.author?.tag || 'Inconnu', inline: false },
      { name: 'Salon', value: `${oldMsg.channel}`, inline: false },
      { name: 'Avant', value: oldMsg.content?.slice(0, 1000) || '(vide)', inline: false },
      { name: 'Après', value: newMsg.content?.slice(0, 1000) || '(vide)', inline: false }
    )
    .setColor(0x3498DB);
  channel.send({ embeds: [embed] }).catch(() => {});
});

client.on(Events.MessageReactionAdd, async (reaction, user) => {
  if (user.bot) return;
  if (reaction.partial) await reaction.fetch().catch(() => {});
  const roleId = storage.getReactionRole(reaction.message.id, reaction.emoji.toString());
  if (!roleId) return;
  const member = await reaction.message.guild.members.fetch(user.id).catch(() => null);
  if (!member) return;
  const role = reaction.message.guild.roles.cache.get(String(roleId));
  if (role) member.roles.add(role).catch(() => {});
});

client.on(Events.MessageReactionRemove, async (reaction, user) => {
  if (user.bot) return;
  if (reaction.partial) await reaction.fetch().catch(() => {});
  const roleId = storage.getReactionRole(reaction.message.id, reaction.emoji.toString());
  if (!roleId) return;
  const member = await reaction.message.guild.members.fetch(user.id).catch(() => null);
  if (!member) return;
  const role = reaction.message.guild.roles.cache.get(String(roleId));
  if (role) member.roles.remove(role).catch(() => {});
});

// Helper pour gérer les erreurs de commande
const handleCommandError = async (interaction, error, commandName) => {
  const errorMsg = error?.message || String(error);
  addLog(`❌ ERREUR CMD ${commandName}: ${errorMsg}`, 'ERROR', {
    'Stack': error?.stack?.substring(0, 200) || 'N/A'
  });
  
  try {
    const embed = new EmbedBuilder()
      .setTitle('❌ Erreur lors de l\'exécution')
      .setDescription(`\`\`\`${errorMsg}\`\`\``)
      .setColor(0xFF0000);
    
    if (!interaction.replied && !interaction.deferred) {
      await interaction.reply({ embeds: [embed], ephemeral: true }).catch(() => {});
    } else if (interaction.deferred) {
      await interaction.editReply({ embeds: [embed] }).catch(() => {});
    }
  } catch (e) {
    console.error('Impossible de notifier erreur:', e);
  }
};

client.on(Events.InteractionCreate, async (interaction) => {
  try {
    // Log command interactions
    if (interaction.isCommand?.()) {
      const commandName = interaction.commandName;
      const subcommand = interaction.options.getSubcommand?.(false);
      const user = interaction.user.tag;
      const guild = interaction.guild?.name || 'DM';
      const logMsg = `⚡ Commande: /${commandName}${subcommand ? ` ${subcommand}` : ''} par ${user}`;
      addLog(logMsg, 'INFO', {
        'Utilisateur': user,
        'Serveur': guild,
        'Commande': commandName,
        'Subcommand': subcommand || 'N/A',
        'Channel': interaction.channel?.name || 'N/A'
      });
    }
    
    if (interaction.isStringSelectMenu()) {
      if (interaction.customId === 'ticket_category') {
        const existing = storage.getTicketByUser(interaction.user.id);
        if (existing) {
          const channel = interaction.guild.channels.cache.get(String(existing.channelId));
          return interaction.reply({ content: `❌ Ticket déjà ouvert: ${channel}`, ephemeral: true });
        }

        const selected = interaction.values?.[0];
        const categoryMap = {
          support: 'Support Général',
          report: 'Signalement',
          partnership: 'Partenariat',
          bug: 'Bug / Erreur',
          other: 'Autre'
        };
        const categoryLabel = categoryMap[selected] || 'Support Général';

        await interaction.deferReply({ ephemeral: true });
        try {
          const channel = await createTicketChannel(interaction.guild, interaction.user, categoryLabel);
          if (!channel) {
            return interaction.editReply({ content: '❌ Erreur lors de la création du ticket.' });
          }
          return interaction.editReply({ content: `✅ Ticket créé: ${channel}` });
        } catch (error) {
          console.error('Erreur création ticket:', error);
          return interaction.editReply({ content: `❌ Erreur: ${error.message}` });
        }
      }
    }

    if (interaction.isButton()) {
    if (interaction.customId === 'ticket_create') {
      const existing = storage.getTicketByUser(interaction.user.id);
      if (existing) {
        const channel = interaction.guild.channels.cache.get(String(existing.channelId));
        return interaction.reply({ content: `❌ Ticket déjà ouvert: ${channel}`, ephemeral: true });
      }
      
      await interaction.deferReply({ ephemeral: true });
      try {
        const channel = await createTicketChannel(interaction.guild, interaction.user, null);
        
        if (!channel) {
          return interaction.editReply({ content: '❌ Erreur lors de la création du ticket.' });
        }
        
        return interaction.editReply({ content: `✅ Ticket créé: ${channel}` });
      } catch (error) {
        console.error('Erreur création ticket:', error);
        return interaction.editReply({ content: `❌ Erreur: ${error.message}` });
      }
    }

    if (interaction.customId === 'ticket_close') {
      const row = storage.getTicketByChannel(interaction.channelId);
      if (!row) return interaction.reply({ content: '❌ Ce salon n\'est pas un ticket.', ephemeral: true });
      
      const embed = new EmbedBuilder()
        .setTitle('🔴 Ticket Fermé')
        .setDescription(`Fermé par ${interaction.user.tag}`)
        .setColor(0xFF6B6B)
        .setTimestamp();
      
      storage.closeTicket(interaction.channelId);
      await interaction.reply({ embeds: [embed] });
      
      setTimeout(() => {
        interaction.channel.delete().catch(() => {});
      }, 3000);
      return;
    }
  }

  if (!interaction.isChatInputCommand()) return;

  const { commandName } = interaction;
  
  // 🔐 COMMANDES CAPTCHA
  if (commandName === 'captcha') {
    const subcommand = interaction.options.getSubcommand();
    
    if (subcommand === 'enable') {
      const settings = require('./settings');
      settings.setCaptchaEnabled(interaction.guildId, true);
      const embed = new EmbedBuilder()
        .setColor('#43B581')
        .setTitle('✅ Captcha Activé')
        .setDescription('Le système de captcha a été activé sur ce serveur.');
      return interaction.reply({ embeds: [embed], ephemeral: true });
    }
    
    if (subcommand === 'disable') {
      const settings = require('./settings');
      settings.setCaptchaEnabled(interaction.guildId, false);
      const embed = new EmbedBuilder()
        .setColor('#F04747')
        .setTitle('❌ Captcha Désactivé')
        .setDescription('Le système de captcha a été désactivé.');
      return interaction.reply({ embeds: [embed], ephemeral: true });
    }
    
    if (subcommand === 'type') {
      const settings = require('./settings');
      const type = interaction.options.getString('type');
      settings.setCaptchaType(interaction.guildId, type);
      const typeNames = { code: 'Code Simple', math: 'Problème Mathématique', image: 'Code Image' };
      const embed = new EmbedBuilder()
        .setColor('#5865F2')
        .setTitle('🔄 Type de Captcha Changé')
        .setDescription(`Type: **${typeNames[type]}**`);
      return interaction.reply({ embeds: [embed], ephemeral: true });
    }
    
    if (subcommand === 'status') {
      const captcha = require('./captcha');
      const settings = require('./settings');
      const stats = captcha.getStats();
      const isEnabled = settings.getCaptchaEnabled(interaction.guildId);
      const type = settings.getCaptchaType(interaction.guildId);
      const embed = new EmbedBuilder()
        .setColor('#5865F2')
        .setTitle('📊 État du Captcha')
        .addFields([
          { name: 'Statut', value: isEnabled ? '✅ Activé' : '❌ Désactivé', inline: true },
          { name: 'Type', value: type === 'code' ? 'Code Simple' : type === 'math' ? 'Problème Mathématique' : 'Code Image', inline: true },
          { name: 'Captchas Actifs', value: stats.activeCount.toString(), inline: true },
          { name: 'Utilisateurs Vérifiés', value: stats.verifiedCount.toString(), inline: true }
        ]);
      return interaction.reply({ embeds: [embed], ephemeral: true });
    }
  }

  // ⚙️ COMMANDES SETTINGS
  if (commandName === 'settings') {
    const settings = require('./settings');
    const subcommand = interaction.options.getSubcommand();
    
    if (subcommand === 'welcome') {
      const channel = interaction.options.getChannel('channel');
      settings.setWelcomeChannel(interaction.guildId, channel.id);
      const embed = new EmbedBuilder()
        .setColor('#43B581')
        .setTitle('✅ Canal de Bienvenue Configuré')
        .setDescription(`Canal: ${channel}`);
      return interaction.reply({ embeds: [embed], ephemeral: true });
    }
    
    if (subcommand === 'logs') {
      const channel = interaction.options.getChannel('channel');
      settings.setLogsChannel(interaction.guildId, channel.id);
      const embed = new EmbedBuilder()
        .setColor('#43B581')
        .setTitle('✅ Canal de Logs Configuré')
        .setDescription(`Canal: ${channel}`);
      return interaction.reply({ embeds: [embed], ephemeral: true });
    }
    
    if (subcommand === 'prefix') {
      const prefix = interaction.options.getString('prefix');
      settings.setPrefix(interaction.guildId, prefix);
      const embed = new EmbedBuilder()
        .setColor('#43B581')
        .setTitle('✅ Préfixe Changé')
        .setDescription(`Nouveau préfixe: \`${prefix}\``);
      return interaction.reply({ embeds: [embed], ephemeral: true });
    }
    
    if (subcommand === 'language') {
      const lang = interaction.options.getString('language');
      settings.setLanguage(interaction.guildId, lang);
      const langNames = { fr: 'Français', en: 'English', es: 'Español' };
      const embed = new EmbedBuilder()
        .setColor('#43B581')
        .setTitle('✅ Langue Changée')
        .setDescription(`Nouvelle langue: **${langNames[lang]}**`);
      return interaction.reply({ embeds: [embed], ephemeral: true });
    }
    
    if (subcommand === 'view') {
      const guildSettings = settings.getGuildSettings(interaction.guildId);
      const embed = new EmbedBuilder()
        .setColor('#5865F2')
        .setTitle('⚙️ Paramètres du Serveur')
        .addFields([
          { name: 'Préfixe', value: `\`${guildSettings.prefix}\``, inline: true },
          { name: 'Langue', value: guildSettings.language.toUpperCase(), inline: true },
          { name: 'Captcha', value: guildSettings.captchaEnabled ? '✅ Activé' : '❌ Désactivé', inline: true },
          { name: 'Type de Captcha', value: guildSettings.captchaType === 'code' ? 'Code' : guildSettings.captchaType === 'math' ? 'Maths' : 'Image', inline: true },
          { name: 'Auto-Modération', value: guildSettings.autoModeration ? '✅' : '❌', inline: true },
          { name: 'Anti-Raid', value: guildSettings.antiRaid ? '✅' : '❌', inline: true }
        ]);
      return interaction.reply({ embeds: [embed], ephemeral: true });
    }
  }

  if (commandName === 'kick') {
    try {
      const member = interaction.options.getMember('membre');
      const reason = interaction.options.getString('raison') || 'Aucune raison spécifiée';
      
      if (!member) return interaction.reply({ embeds: [createErrorEmbed('Erreur', '❌ Membre introuvable.')] , ephemeral: true });
      if (!member.kickable) return interaction.reply({ embeds: [createErrorEmbed('Erreur', '❌ Je ne peux pas expulser ce membre (permissions insuffisantes ou hiérarchie insuffisante).')] , ephemeral: true });
      if (member.user.id === interaction.user.id) return interaction.reply({ embeds: [createErrorEmbed('Erreur', '❌ Tu ne peux pas te kick toi-même.')] , ephemeral: true });
      if (member.roles.highest.position >= interaction.member.roles.highest.position) return interaction.reply({ embeds: [createErrorEmbed('Erreur', '❌ Tu ne peux pas kick quelqu\'un de même rang ou supérieur.')] , ephemeral: true });
      
      await member.kick(reason).catch(err => {});
      
      const embed = new EmbedBuilder()
        .setTitle('🦶 Membre Expulsé')
        .setThumbnail(member.user.displayAvatarURL({ size: 128 }))
        .addFields(
          { 
            name: '👤 Utilisateur', 
            value: `${member.user.tag}\n\`${member.user.id}\``, 
            inline: true 
          },
          { 
            name: '👮 Modérateur', 
            value: `${interaction.user.tag}\n\`${interaction.user.id}\``, 
            inline: true 
          },
          { 
            name: '⏰ Date', 
            value: `<t:${Math.floor(Date.now() / 1000)}:F>`, 
            inline: true 
          },
          { 
            name: '📝 Raison', 
            value: reason, 
            inline: false 
          }
        )
        .setColor(0xF39C12)
        .setFooter({ text: 'Action modérée' })
        .setTimestamp();
      
      const logChannel = getLogChannel(interaction.guild);
      if (logChannel) logChannel.send({ embeds: [embed] }).catch(() => {});
      
      return interaction.reply({ embeds: [embed] });
    } catch (error) {
      console.error('Erreur kick:', error);
      return interaction.reply({ embeds: [createErrorEmbed('Erreur', '❌ Une erreur est survenue.')] , ephemeral: true });
    }
  }

  if (commandName === 'ban') {
    try {
      const member = interaction.options.getMember('membre');
      const reason = interaction.options.getString('raison') || 'Aucune raison spécifiée';
      
      if (!member) return interaction.reply({ embeds: [createErrorEmbed('Erreur', '❌ Membre introuvable.')], ephemeral: true });
      if (!member.bannable) return interaction.reply({ embeds: [createErrorEmbed('Erreur', '❌ Je ne peux pas bannir ce membre.')] , ephemeral: true });
      if (member.user.id === interaction.user.id) return interaction.reply({ embeds: [createErrorEmbed('Erreur', '❌ Tu ne peux pas te ban toi-même.')] , ephemeral: true });
      
      await member.ban({ reason, deleteMessageDays: 7 }).catch(() => {});
      
      const embed = new EmbedBuilder()
        .setTitle('🚫 Membre Banni')
        .setThumbnail(member.user.displayAvatarURL({ size: 128 }))
        .addFields(
          { name: '👤 Utilisateur', value: `${member.user.tag}\n\`${member.user.id}\``, inline: true },
          { name: '👮 Modérateur', value: `${interaction.user.tag}\n\`${interaction.user.id}\``, inline: true },
          { name: '⏰ Date', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true },
          { name: '📝 Raison', value: reason, inline: false }
        )
        .setColor(0xE74C3C)
        .setFooter({ text: 'Action modérée' })
        .setTimestamp();
      
      const logChannel = getLogChannel(interaction.guild);
      if (logChannel) logChannel.send({ embeds: [embed] }).catch(() => {});
      
      return interaction.reply({ embeds: [embed] });
    } catch (error) {
      console.error('Erreur ban:', error);
      return interaction.reply({ embeds: [createErrorEmbed('Erreur', '❌ Une erreur est survenue.')], ephemeral: true });
    }
  }

  if (commandName === 'timeout') {
    const member = interaction.options.getMember('membre');
    const duration = interaction.options.getString('duree');
    const reason = interaction.options.getString('raison') || 'Aucune raison';
    const seconds = parseDuration(duration);
    if (!member) return interaction.reply({ content: 'Membre introuvable.', ephemeral: true });
    if (!seconds) return interaction.reply({ content: 'Durée invalide (ex: 10m, 2h, 1d).', ephemeral: true });
    if (!member.moderatable) return interaction.reply({ content: 'Impossible de timeout ce membre.', ephemeral: true });
    if (seconds > 2419200) return interaction.reply({ content: 'Durée max: 28 jours.', ephemeral: true });
    
    await member.timeout(seconds * 1000, reason).catch(() => {});
    const embed = new EmbedBuilder()
      .setTitle('⏱️ Timeout Appliqué')
      .addFields(
        { name: 'Utilisateur', value: member.user.tag, inline: true },
        { name: 'Durée', value: duration, inline: true },
        { name: 'Modérateur', value: interaction.user.tag, inline: true },
        { name: 'Raison', value: reason, inline: false }
      )
      .setColor(0xF39C12)
      .setTimestamp();
    
    const logChannel = getLogChannel(interaction.guild);
    if (logChannel) logChannel.send({ embeds: [embed] }).catch(() => {});
    
    return interaction.reply({ embeds: [embed] });
  }

  if (commandName === 'untimeout') {
    const member = interaction.options.getMember('membre');
    if (!member) return interaction.reply({ content: 'Membre introuvable.', ephemeral: true });
    if (!member.moderatable) return interaction.reply({ content: 'Impossible de retirer le timeout.', ephemeral: true });
    
    await member.timeout(null).catch(() => {});
    const embed = new EmbedBuilder()
      .setTitle('✅ Timeout Retiré')
      .addFields(
        { name: 'Utilisateur', value: member.user.tag, inline: true },
        { name: 'Modérateur', value: interaction.user.tag, inline: true }
      )
      .setColor(0x2ECC71)
      .setTimestamp();
    
    const logChannel = getLogChannel(interaction.guild);
    if (logChannel) logChannel.send({ embeds: [embed] }).catch(() => {});
    
    return interaction.reply({ embeds: [embed] });
  }

  if (commandName === 'clear') {
    try {
      const amount = interaction.options.getInteger('nombre');
      if (amount <= 0) return interaction.reply({ embeds: [createErrorEmbed('Erreur', '❌ Nombre doit être positif.')], ephemeral: true });
      if (amount > 100) return interaction.reply({ embeds: [createWarningEmbed('Attention', '⚠️ Maximum 100 messages à la fois.')], ephemeral: true });
      
      const messages = await interaction.channel.bulkDelete(amount, true).catch(() => []);
      
      const embed = new EmbedBuilder()
        .setTitle('🧹 Messages Supprimés')
        .addFields(
          { name: '📊 Nombre de messages', value: `\`${messages.size || 0}\``, inline: true },
          { name: '💬 Salon', value: `${interaction.channel}`, inline: true },
          { name: '👮 Par', value: `${interaction.user.tag}`, inline: true },
          { name: '🕐 Heure', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: false }
        )
        .setColor(0x3498DB)
        .setFooter({ text: 'Modération' })
        .setTimestamp();
      
      const logChannel = getLogChannel(interaction.guild);
      if (logChannel) logChannel.send({ embeds: [embed] }).catch(() => {});
      
      return interaction.reply({ embeds: [createSuccessEmbed('Suppression', `🧹 **${messages.size || 0}** messages supprimés avec succès.`)], ephemeral: true });
    } catch (error) {
      console.error('Erreur clear:', error);
      return interaction.reply({ embeds: [createErrorEmbed('Erreur', '❌ Erreur lors de la suppression.')] , ephemeral: true });
    }
  }

  if (commandName === 'ticket') {
    const action = interaction.options.getString('action');
    if (action === 'create') {
      const existing = storage.getTicketByUser(interaction.user.id);
      if (existing) {
        const channel = interaction.guild.channels.cache.get(String(existing.channelId));
        return interaction.reply({ content: `❌ Ticket déjà ouvert: ${channel}`, ephemeral: true });
      }
      
      const channel = await createTicketChannel(interaction.guild, interaction.user, null);
      if (!channel) return interaction.reply({ content: '❌ Impossible de créer le ticket.', ephemeral: true });
      
      const embed = new EmbedBuilder()
        .setTitle('🎫 Ticket Créé')
        .setDescription('Explique ton problème, l\'équipe va t\'aider!')
        .setFooter({ text: 'Ferme le ticket quand tu as fini' })
        .setColor(0x2ECC71);
      
      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId('ticket_close')
          .setLabel('Fermer')
          .setStyle(ButtonStyle.Danger)
      );
      
      await channel.send({ embeds: [embed], components: [row] }).catch(() => {});
      return interaction.reply({ content: `✅ Ticket créé: ${channel}`, ephemeral: true });
    }
    
    const row = storage.getTicketByChannel(interaction.channelId);
    if (!row) return interaction.reply({ content: '❌ Ce salon n\'est pas un ticket.', ephemeral: true });
    
    const embed = new EmbedBuilder()
      .setTitle('🎫 Ticket Fermé')
      .setDescription(`Ticket fermé par ${interaction.user.tag}`)
      .setColor(0xFF6B6B)
      .setTimestamp();
    
    await interaction.reply({ embeds: [embed] });
    storage.closeTicket(interaction.channelId);
    
    setTimeout(() => {
      interaction.channel.delete().catch(() => {});
    }, 3000);
  }

  if (commandName === 'ticketpanel') {
    const categoryRow = new ActionRowBuilder().addComponents(
      new StringSelectMenuBuilder()
        .setCustomId('ticket_category')
        .setPlaceholder('Sélectionne une catégorie')
        .addOptions(
          { label: 'Support Général', value: 'support', emoji: '🛟' },
          { label: 'Signalement', value: 'report', emoji: '🚨' },
          { label: 'Partenariat', value: 'partnership', emoji: '🤝' },
          { label: 'Bug / Erreur', value: 'bug', emoji: '🐛' },
          { label: 'Autre', value: 'other', emoji: '💬' }
        )
    );

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('ticket_create')
        .setLabel('🎫 Créer un Ticket (Rapide)')
        .setStyle(ButtonStyle.Success)
    );
    
    const embed = new EmbedBuilder()
      .setTitle('🎫 Centre de Support')
      .setDescription(
        '**Bienvenue dans le centre de support !**\n\n' +
        'Sélectionne une catégorie dans le menu pour ouvrir un ticket dédié.\n' +
        'Tu peux aussi créer un ticket rapide avec le bouton.\n\n' +
        '**ℹ️ Informations :**\n' +
        '• Réponse généralement en moins de 30 minutes\n' +
        '• Un salon privé sera créé pour toi\n' +
        '• Tu peux fermer le ticket à tout moment\n\n' +
        '**📋 Règles :**\n' +
        '• Reste respectueux\n' +
        '• Explique clairement ton problème\n' +
        '• Pas de spam ni contenu offensant'
      )
      .setColor(0x5865F2)
      .setThumbnail(interaction.client.user.avatarURL({ size: 256 }))
      .setFooter({ text: 'LvCreations Bot • Support 24/7' })
      .setTimestamp();
    
    return interaction.reply({ embeds: [embed], components: [categoryRow, row] });
  }

  if (commandName === 'setup') {
    const option = interaction.options.getString('option');
    const channel = interaction.options.getChannel('canal');
    
    let envVar = '';
    let message = '';
    
    if (option === 'logchannel') {
      envVar = 'LOG_CHANNEL_ID';
      message = `Canal de logs configuré: ${channel}`;
    } else if (option === 'welcomechannel') {
      envVar = 'WELCOME_CHANNEL_ID';
      message = `Canal de bienvenue configuré: ${channel}`;
    } else if (option === 'levelchannel') {
      envVar = 'LEVEL_CHANNEL_ID';
      message = `Canal de niveaux configuré: ${channel}`;
    } else if (option === 'ticketcategory') {
      envVar = 'TICKET_CATEGORY_ID';
      message = `Catégorie de tickets configurée: ${channel}`;
    }
    
    const embed = new EmbedBuilder()
      .setTitle('⚙️ Configuration Mise à Jour')
      .addFields(
        { name: 'Option', value: option, inline: true },
        { name: 'ID', value: channel.id, inline: true },
        { name: 'Message', value: message, inline: false }
      )
      .setColor(0x3498DB)
      .setTimestamp();
    
    console.log(`📝 Configuration: ${envVar} = ${channel.id}`);
    return interaction.reply({ embeds: [embed] });
  }

  if (commandName === 'verify') {
    const code = interaction.options.getString('code');
    const entry = captchaCodes.get(interaction.user.id);
    if (!entry) return interaction.reply({ content: 'Aucune vérification en attente.', ephemeral: true });
    if (entry.guildId !== interaction.guild.id) return interaction.reply({ content: 'Mauvais serveur.', ephemeral: true });
    if (Date.now() > entry.expiresAt) {
      captchaCodes.delete(interaction.user.id);
      return interaction.reply({ content: 'Code expiré.', ephemeral: true });
    }
    if (entry.code !== code) return interaction.reply({ content: 'Code invalide.', ephemeral: true });

    if (config.UNVERIFIED_ROLE_ID) {
      const role = interaction.guild.roles.cache.get(String(config.UNVERIFIED_ROLE_ID));
      if (role) await interaction.member.roles.remove(role).catch(() => {});
    }
    if (config.VERIFIED_ROLE_ID) {
      const role = interaction.guild.roles.cache.get(String(config.VERIFIED_ROLE_ID));
      if (role) await interaction.member.roles.add(role).catch(() => {});
    }

    captchaCodes.delete(interaction.user.id);
    return interaction.reply({ content: 'Vérification réussie ✅', ephemeral: true });
  }

  if (commandName === 'raidmode') {
    const action = interaction.options.getString('action');
    if (action === 'on') {
      const duration = (config.RAID_MODE_DURATION || 300) * 1000;
      raidModeUntil.set(interaction.guild.id, Date.now() + duration);
      const embed = new EmbedBuilder()
        .setTitle('🛡️ Raid Mode Activé')
        .addFields({ name: 'Durée', value: `${duration / 1000}s`, inline: false })
        .setColor(0xFF6B6B);
      return interaction.reply({ embeds: [embed] });
    }
    raidModeUntil.set(interaction.guild.id, 0);
    return interaction.reply('✅ Raid mode désactivé.');
  }

  if (commandName === 'rank') {
    try {
      const member = interaction.options.getUser('membre') || interaction.user;
      const memberObj = await interaction.guild.members.fetch(member.id).catch(() => null);
      const row = storage.getLevel(member.id);
      
      if (!row || row.xp === 0) {
        return interaction.reply({ 
          embeds: [createInfoEmbed('Profil XP', `${member.username} n'a pas encore d'XP.`)], 
          ephemeral: true 
        });
      }
      
      const level = row.level;
      const xp = row.xp;
      const nextLevelXp = level * 100;
      const progressPercent = (xp / nextLevelXp * 100).toFixed(1);
      const progressBar = utils.createBar(xp, nextLevelXp, 15);
      
      const achievements = advanced.getUserAchievements(member.id);
      const achievementsStr = achievements.length > 0 
        ? achievements.map(a => `${a.emoji} ${a.name}`).join(' • ')
        : '*Aucun achievement*';
      
      const embed = new EmbedBuilder()
        .setTitle(`📊 Profil XP de ${member.username}`)
        .setThumbnail(member.displayAvatarURL({ size: 256 }))
        .addFields(
          { 
            name: '🎖️ Niveau', 
            value: `\`${level}\``, 
            inline: true 
          },
          { 
            name: '⭐ Expérience', 
            value: `\`${xp}/${nextLevelXp}\``, 
            inline: true 
          },
          { 
            name: '📈 Progression', 
            value: progressBar, 
            inline: false 
          },
          { 
            name: '🏆 Achievements', 
            value: achievementsStr, 
            inline: false 
          }
        )
        .setColor(0xF39C12)
        .setFooter({ text: `${progressPercent}% vers le prochain niveau` })
        .setTimestamp();
      
      return interaction.reply({ embeds: [embed] });
    } catch (error) {
      console.error('Erreur rank:', error);
      return interaction.reply({ embeds: [createErrorEmbed('Erreur', '❌ Erreur lors de la récupération du profil.')] , ephemeral: true });
    }
  }

  if (commandName === 'giveaway') {
    const duration = parseDuration(interaction.options.getString('duree'));
    const winners = interaction.options.getInteger('gagnants');
    const prize = interaction.options.getString('prix');
    if (!duration) return interaction.reply({ content: 'Durée invalide.', ephemeral: true });
    const embed = new EmbedBuilder()
      .setTitle('🎉 Giveaway')
      .addFields(
        { name: 'Prix', value: prize, inline: false },
        { name: 'Durée', value: interaction.options.getString('duree'), inline: false },
        { name: 'Gagnants', value: `${winners}`, inline: false }
      )
      .setColor(0x9B59B6);

    const message = await interaction.reply({ embeds: [embed], fetchReply: true });
    await message.react('🎉');

    setTimeout(async () => {
      const fetched = await interaction.channel.messages.fetch(message.id).catch(() => null);
      if (!fetched) return;
      const reaction = fetched.reactions.cache.get('🎉');
      if (!reaction) return interaction.channel.send('Aucune participation.');
      const users = await reaction.users.fetch();
      const eligible = users.filter(u => !u.bot);
      if (eligible.size < winners) return interaction.channel.send('Pas assez de participants.');
      const shuffled = [...eligible.values()].sort(() => 0.5 - Math.random());
      const selected = shuffled.slice(0, winners);
      interaction.channel.send(`🎉 Gagnant(s): ${selected.map(u => `<@${u.id}>`).join(', ')} | Prix: ${prize}`);
    }, duration * 1000);
    return;
  }

  if (commandName === 'reroll') {
    const messageId = interaction.options.getString('message_id');
    const winners = interaction.options.getInteger('gagnants') || 1;
    const message = await interaction.channel.messages.fetch(messageId).catch(() => null);
    if (!message) return interaction.reply({ content: 'Message introuvable.', ephemeral: true });
    const reaction = message.reactions.cache.get('🎉');
    if (!reaction) return interaction.reply({ content: 'Pas de 🎉.', ephemeral: true });
    const users = await reaction.users.fetch();
    const eligible = users.filter(u => !u.bot);
    if (eligible.size < winners) return interaction.reply({ content: 'Pas assez de participants.', ephemeral: true });
    const shuffled = [...eligible.values()].sort(() => 0.5 - Math.random());
    const selected = shuffled.slice(0, winners);
    return interaction.reply(`🎉 Nouveau(x) gagnant(s): ${selected.map(u => `<@${u.id}>`).join(', ')}`);
  }

  if (commandName === 'rr') {
    const action = interaction.options.getString('action');
    const messageId = interaction.options.getString('message_id');
    const emoji = interaction.options.getString('emoji');
    const role = interaction.options.getRole('role');
    const message = await interaction.channel.messages.fetch(messageId).catch(() => null);
    if (!message) return interaction.reply({ content: 'Message introuvable.', ephemeral: true });

    if (action === 'add') {
      storage.setReactionRole(messageId, emoji, role.id);
      await message.react(emoji).catch(() => {});
      return interaction.reply('Reaction role ajouté.');
    }

    storage.removeReactionRole(messageId, emoji);
    return interaction.reply('Reaction role supprimé.');
  }

  if (commandName === 'join') {
    const queue = await connectToVoice(interaction);
    if (!queue) return;
    return interaction.reply('✅ Connecté au vocal.');
  }

  if (commandName === 'leave') {
    const queue = ensureGuildQueue(interaction.guild.id);
    if (queue.connection) {
      queue.connection.destroy();
      queue.tracks = [];
      queue.player.stop();
    }
    return interaction.reply('✅ Déconnecté du vocal.');
  }

  if (commandName === 'play') {
    try {
      const member = await interaction.guild.members.fetch(interaction.user.id);
      const voiceChannel = member.voice.channel;
      if (!voiceChannel) return interaction.reply({ content: '❌ Tu dois être en vocal.', ephemeral: true });
      
      const query = interaction.options.getString('query');
      await interaction.deferReply();
      
      const search = await play.search(query, { limit: 1 }).catch(() => null);
      if (!search || !search[0]) return interaction.editReply('❌ Aucun résultat trouvé.');
      
      const track = search[0];
      const queue = ensureGuildQueue(interaction.guild.id);
      
      if (!queue.connection) {
        const connection = joinVoiceChannel({
          channelId: voiceChannel.id,
          guildId: voiceChannel.guild.id,
          adapterCreator: voiceChannel.guild.voiceAdapterCreator
        });
        await entersState(connection, VoiceConnectionStatus.Ready, 20_000).catch(() => null);
        connection.subscribe(queue.player);
        queue.connection = connection;
      }
      
      queue.tracks.push({ title: track.title, url: track.url, thumbnail: track.thumbnail });
      queue.textChannelId = interaction.channelId;
      
      const embed = new EmbedBuilder()
        .setTitle('🎵 Chanson Ajoutée')
        .setDescription(`[${track.title}](${track.url})`)
        .setThumbnail(track.thumbnail)
        .addFields(
          { name: 'Position', value: `${queue.tracks.length}`, inline: true },
          { name: 'Durée', value: track.durationInSec ? `${Math.floor(track.durationInSec / 60)}:${(track.durationInSec % 60).toString().padStart(2, '0')}` : 'N/A', inline: true }
        )
        .setColor(0x9B59B6);
      
      if (queue.player.state.status !== AudioPlayerStatus.Playing) {
        await playNext(interaction.guild.id).catch(() => {});
      }
      
      return interaction.editReply({ embeds: [embed] });
    } catch (error) {
      console.error('Erreur play:', error);
      return interaction.editReply('❌ Erreur lors de la lecture.');
    }
  }

  if (commandName === 'pause') {
    const queue = ensureGuildQueue(interaction.guild.id);
    if (queue.player.state.status !== AudioPlayerStatus.Playing) {
      return interaction.reply({ content: '❌ Aucune musique en lecture.', ephemeral: true });
    }
    queue.player.pause(true);
    return interaction.reply('⏸️ Musique mise en pause.');
  }

  if (commandName === 'resume') {
    const queue = ensureGuildQueue(interaction.guild.id);
    if (queue.player.state.status === AudioPlayerStatus.Playing) {
      return interaction.reply({ content: '❌ La musique est déjà en lecture.', ephemeral: true });
    }
    queue.player.unpause();
    return interaction.reply('▶️ Musique reprise.');
  }

  if (commandName === 'skip') {
    const queue = ensureGuildQueue(interaction.guild.id);
    if (queue.tracks.length === 0) {
      return interaction.reply({ content: '❌ File vide.', ephemeral: true });
    }
    queue.player.stop();
    return interaction.reply('⏭️ Musique passée.');
  }

  if (commandName === 'stop') {
    const queue = ensureGuildQueue(interaction.guild.id);
    queue.tracks = [];
    queue.player.stop();
    return interaction.reply('⏹️ Musique stoppée.');
  }

  if (commandName === 'queue') {
    const queue = ensureGuildQueue(interaction.guild.id);
    if (!queue.tracks.length) {
      return interaction.reply({ content: '❌ File vide.', ephemeral: true });
    }
    
    const pages = [];
    for (let i = 0; i < queue.tracks.length; i += 10) {
      const chunk = queue.tracks.slice(i, i + 10);
      const list = chunk.map((t, idx) => `**${i + idx + 1}.** ${t.title}`).join('\n');
      pages.push(list);
    }
    
    const embed = new EmbedBuilder()
      .setTitle('🎵 File de Lecture')
      .setDescription(pages[0] || 'Vide')
      .setFooter({ text: `Total: ${queue.tracks.length} chanson(s)` })
      .setColor(0x9B59B6);
    
    return interaction.reply({ embeds: [embed] });
  }

  if (commandName === 'warn') {
    try {
      const member = interaction.options.getUser('membre');
      const raison = interaction.options.getString('raison');
      const guildId = interaction.guild.id;
    
    if (!warns.has(guildId)) warns.set(guildId, new Map());
    const guildWarns = warns.get(guildId);
    if (!guildWarns.has(member.id)) guildWarns.set(member.id, []);
    
    const warnCount = guildWarns.get(member.id).length + 1;
    guildWarns.get(member.id).push({ 
      raison, 
      date: new Date().toISOString(), 
      by: interaction.user.id,
      byTag: interaction.user.tag
    });
    
    // Auto-actions après 3 avertissements
    let action = '';
    if (warnCount === 3) {
      const memberObj = await interaction.guild.members.fetch(member.id).catch(() => null);
      if (memberObj) await memberObj.timeout(3600000, 'Auto-mute: 3 avertissements').catch(() => {});
      action = ' - Auto-mute 1h appliqué';
    } else if (warnCount >= 5) {
      const memberObj = await interaction.guild.members.fetch(member.id).catch(() => null);
      if (memberObj && memberObj.bannable) await memberObj.ban({ reason: 'Auto-ban: 5 avertissements' }).catch(() => {});
      action = ' - Auto-ban appliqué';
    }
    
    const embed = new EmbedBuilder()
      .setTitle('⚠️ Avertissement Donné')
      .addFields(
        { name: 'Utilisateur', value: member.tag, inline: true },
        { name: 'Raison', value: raison, inline: false },
        { name: 'Total', value: `${warnCount}/5`, inline: true },
        { name: 'Modérateur', value: interaction.user.tag, inline: true }
      )
      .setColor(0xFF6B6B)
      .setTimestamp();
    
    if (action) embed.addFields({ name: 'Action Auto', value: action, inline: false });
    
    const logChannel = getLogChannel(interaction.guild);
    if (logChannel) logChannel.send({ embeds: [embed] }).catch(() => {});
    
    return interaction.reply({ embeds: [embed] });
    } catch (error) {
      await handleCommandError(interaction, error, 'warn');
    }
  }

  if (commandName === 'warns') {
    const member = interaction.options.getUser('membre') || interaction.user;
    const guildId = interaction.guild.id;
    const guildWarns = warns.get(guildId)?.get(member.id) || [];
    
    if (!guildWarns.length) {
      return interaction.reply({ content: '✅ Aucun avertissement.', ephemeral: true });
    }
    
    const list = guildWarns.map((w, i) => 
      `**${i + 1}.** ${w.raison}\n┗ Par ${w.byTag} le <t:${Math.floor(new Date(w.date).getTime() / 1000)}:d>`
    ).join('\n');
    
    const embed = new EmbedBuilder()
      .setTitle(`⚠️ Avertissements de ${member.tag}`)
      .setDescription(list)
      .setFooter({ text: `Total: ${guildWarns.length}` })
      .setColor(0xFF6B6B);
    
    return interaction.reply({ embeds: [embed] });
  }

  if (commandName === 'clearwarn') {
    const member = interaction.options.getUser('membre');
    const guildId = interaction.guild.id;
    const previousCount = warns.get(guildId)?.get(member.id)?.length || 0;
    
    if (warns.has(guildId)) {
      warns.get(guildId).delete(member.id);
    }
    
    const embed = new EmbedBuilder()
      .setTitle('🧹 Avertissements Effacés')
      .addFields(
        { name: 'Utilisateur', value: member.tag, inline: true },
        { name: 'Nombre', value: `${previousCount}`, inline: true },
        { name: 'Modérateur', value: interaction.user.tag, inline: true }
      )
      .setColor(0x2ECC71)
      .setTimestamp();
    
    const logChannel = getLogChannel(interaction.guild);
    if (logChannel) logChannel.send({ embeds: [embed] }).catch(() => {});
    
    return interaction.reply({ embeds: [embed] });
  }

  if (commandName === 'mute') {
    const user = interaction.options.getUser('membre');
    const member = await interaction.guild.members.fetch(user.id).catch(() => null);
    
    if (!member) return interaction.reply({ content: 'Membre introuvable.', ephemeral: true });
    if (!member.voice.channel) return interaction.reply({ content: 'Cet utilisateur n\'est pas en vocal.', ephemeral: true });
    
    await member.voice.setMute(true).catch(() => {});
    
    const embed = new EmbedBuilder()
      .setTitle('🔇 Mute Appliqué')
      .addFields(
        { name: 'Utilisateur', value: member.user.tag, inline: true },
        { name: 'Modérateur', value: interaction.user.tag, inline: true }
      )
      .setColor(0xFF9800)
      .setTimestamp();
    
    return interaction.reply({ embeds: [embed] });
  }

  if (commandName === 'unmute') {
    const user = interaction.options.getUser('membre');
    const member = await interaction.guild.members.fetch(user.id).catch(() => null);
    
    if (!member) return interaction.reply({ content: 'Membre introuvable.', ephemeral: true });
    if (!member.voice.channel) return interaction.reply({ content: 'Cet utilisateur n\'est pas en vocal.', ephemeral: true });
    
    await member.voice.setMute(false).catch(() => {});
    
    const embed = new EmbedBuilder()
      .setTitle('🔊 Mute Retiré')
      .addFields(
        { name: 'Utilisateur', value: member.user.tag, inline: true },
        { name: 'Modérateur', value: interaction.user.tag, inline: true }
      )
      .setColor(0x2ECC71)
      .setTimestamp();
    
    return interaction.reply({ embeds: [embed] });
  }

  if (commandName === 'remind') {
    const duration = parseDuration(interaction.options.getString('duree'));
    const message = interaction.options.getString('message');
    if (!duration) return interaction.reply({ content: 'Durée invalide (ex: 10m, 2h, 1d).', ephemeral: true });
    
    const embed = new EmbedBuilder()
      .setTitle('⏰ Rappel Programmé')
      .addFields({ name: 'Message', value: message, inline: false })
      .setColor(0x3498DB);
    
    setTimeout(() => {
      interaction.user.send({ 
        content: `⏰ **Rappel**: ${message}`,
        embeds: [embed]
      }).catch(() => {});
    }, duration * 1000);
    
    return interaction.reply({ embeds: [embed] });
  }

  if (commandName === 'poll') {
    const question = interaction.options.getString('question');
    const options = [
      interaction.options.getString('option1'),
      interaction.options.getString('option2'),
      interaction.options.getString('option3'),
      interaction.options.getString('option4')
    ].filter(Boolean);
    
    const emojis = ['1️⃣', '2️⃣', '3️⃣', '4️⃣'];
    const embed = new EmbedBuilder()
      .setTitle('📊 Sondage')
      .setDescription(question)
      .addFields(options.map((opt, i) => ({ name: emojis[i], value: opt, inline: false })))
      .setColor(0x3498DB);
    
    const msg = await interaction.reply({ embeds: [embed], fetchReply: true });
    for (let i = 0; i < options.length; i++) {
      await msg.react(emojis[i]);
    }
  }

  if (commandName === 'userinfo') {
    try {
      const user = interaction.options.getUser('membre') || interaction.user;
      const memberObj = await interaction.guild.members.fetch(user.id).catch(() => null);
      
      if (!memberObj && user.id !== interaction.user.id) {
        return interaction.reply({ content: '❌ Impossible de trouver ce membre.', ephemeral: true });
      }

      const joinedDate = memberObj?.joinedTimestamp 
        ? `<t:${Math.floor(memberObj.joinedTimestamp / 1000)}:d>` 
        : 'Non disponible';
      const createdDate = `<t:${Math.floor(user.createdTimestamp / 1000)}:d>`;
      
      const roles = memberObj?.roles.cache
        .filter(r => r.id !== interaction.guild.id)
        .map(r => r.toString())
        .slice(0, 10)
        .join(' ') || '*Aucun rôle*';
      
      const isBot = user.bot ? '🤖 Oui' : '👤 Non';
      const status = memberObj?.user.presence?.status 
        ? { online: '🟢 En ligne', idle: '🟡 Inactif', dnd: '🔴 Ne pas déranger', offline: '⚫ Hors ligne' }[memberObj.user.presence.status]
        : '⚫ Hors ligne';

      const embed = new EmbedBuilder()
        .setTitle(`👤 Profil de ${user.username}`)
        .setThumbnail(user.displayAvatarURL({ size: 256 }))
        .addFields(
          { 
            name: '🆔 ID Utilisateur', 
            value: `\`${user.id}\``, 
            inline: true 
          },
          { 
            name: '🤖 Bot?', 
            value: isBot, 
            inline: true 
          },
          { 
            name: '💬 Statut', 
            value: status, 
            inline: true 
          },
          { 
            name: '📅 Compte créé', 
            value: createdDate, 
            inline: true 
          },
          { 
            name: '🎫 A rejoint le serveur', 
            value: joinedDate, 
            inline: true 
          },
          { 
            name: '👥 Rôles (' + (memberObj?.roles.cache.size - 1 || 0) + ')', 
            value: roles, 
            inline: false 
          }
        )
        .setColor(0x5865F2)
        .setFooter({ text: `Demandé par ${interaction.user.username}` })
        .setTimestamp();
      
      return interaction.reply({ embeds: [embed] });
    } catch (error) {
      return interaction.reply({ content: '❌ Erreur lors de la récupération des infos.', ephemeral: true });
    }
  }

  if (commandName === 'serverinfo') {
    try {
      const guild = interaction.guild;
      const owner = await guild.fetchOwner().catch(() => null);
      
      const textChannels = guild.channels.cache.filter(c => c.isTextBased()).size;
      const voiceChannels = guild.channels.cache.filter(c => c.isVoiceBased()).size;
      const categories = guild.channels.cache.filter(c => c.type === 4).size;
      
      const members = guild.memberCount || 0;
      const bots = guild.members.cache.filter(m => m.user.bot).size;
      const humans = members - bots;
      
      const createdDate = `<t:${Math.floor(guild.createdTimestamp / 1000)}:d>`;
      
      const verificationLevel = {
        0: 'Aucune',
        1: 'Email vérifié',
        2: '1+ mois',
        3: '5+ minutes',
        4: 'Téléphone vérifié'
      }[guild.verificationLevel] || 'Inconnue';

      const embed = new EmbedBuilder()
        .setTitle(`🏰 ${guild.name}`)
        .setThumbnail(guild.iconURL({ size: 256 }))
        .addFields(
          { 
            name: '🆔 ID Serveur', 
            value: `\`${guild.id}\``, 
            inline: true 
          },
          { 
            name: '👑 Propriétaire', 
            value: owner ? owner.toString() : 'Inconnu', 
            inline: true 
          },
          { 
            name: '📅 Créé le', 
            value: createdDate, 
            inline: true 
          },
          { 
            name: '👥 Membres', 
            value: `**${members}** total\n👤 ${humans} humains\n🤖 ${bots} bots`, 
            inline: true 
          },
          { 
            name: '📊 Canaux', 
            value: `💬 ${textChannels} texte\n🔊 ${voiceChannels} vocaux\n📁 ${categories} catégories`, 
            inline: true 
          },
          { 
            name: '🔐 Sécurité', 
            value: `Vérification: ${verificationLevel}\nRôles: **${guild.roles.cache.size}**`, 
            inline: true 
          }
        )
        .setColor(0x9B59B6)
        .setFooter({ text: `Serveur depuis le ${createdDate}` })
        .setTimestamp();
      
      return interaction.reply({ embeds: [embed] });
    } catch (error) {
      return interaction.reply({ content: '❌ Erreur lors de la récupération des infos.', ephemeral: true });
    }
  }

  if (commandName === 'avatar') {
    const member = interaction.options.getUser('membre') || interaction.user;
    const embed = new EmbedBuilder()
      .setTitle(`Avatar de ${member.tag}`)
      .setImage(member.displayAvatarURL({ size: 1024 }))
      .setColor(0x1ABC9C);
    return interaction.reply({ embeds: [embed] });
  }

  if (commandName === 'ping') {
    const msg = await interaction.reply({ content: '🏓 Pong!', fetchReply: true });
    const latency = msg.createdTimestamp - interaction.createdTimestamp;
    return interaction.editReply(`🏓 Pong! \`${latency}ms\` - API: \`${client.ws.ping}ms\``);
  }

  if (commandName === 'help') {
    const embed = new EmbedBuilder()
      .setTitle('📚 Aide Complète - Toutes les Commandes')
      .setThumbnail(interaction.client.user.avatarURL({ size: 256 }))
      .addFields(
        {
          name: '🛡️ Modération',
          value: '`/kick` `/ban` `/timeout` `/untimeout` `/clear` `/warn` `/warns` `/clearwarn` `/mute` `/unmute`',
          inline: false
        },
        {
          name: '🎫 Tickets',
          value: '`/ticket create` `/ticket close` `/ticketpanel`',
          inline: false
        },
        {
          name: '🎵 Musique',
          value: '`/play` `/pause` `/resume` `/skip` `/stop` `/queue` `/join` `/leave`',
          inline: false
        },
        {
          name: '🎉 Giveaways',
          value: '`/giveaway` `/reroll` `/rr add` `/rr remove`',
          inline: false
        },
        {
          name: '📊 Profil & Stats',
          value: '`/rank` `/userinfo` `/serverinfo` `/botinfo` `/avatar` `/stats` `/uptime` `/ping`',
          inline: false
        },
        {
          name: '🔐 Sécurité & Système',
          value: '`/verify` `/raidmode` `/protections` `/settings` `/setup`',
          inline: false
        },
        {
          name: '🎮 Divertissement',
          value: '`/8ball` `/dice` `/joke` `/quote` `/slots` `/rps` `/calc` `/color` `/afk`',
          inline: false
        },
        {
          name: '📢 Annonces',
          value: '`/announce` `/suggestion` `/poll` `/remind`',
          inline: false
        },
        {
          name: '⚙️ Admin',
          value: '`/eval` `/reload` `/poweroff` `/setstatus` `/logs`',
          inline: false
        }
      )
      .setColor(0x5865F2)
      .setFooter({ text: 'LvCreations Bot v2.0.1 • Tapez les commandes pour voir les détails' })
      .setTimestamp();
    
    return interaction.reply({ embeds: [embed] });
  }

  if (commandName === 'announce') {
    const titre = interaction.options.getString('titre');
    const message = interaction.options.getString('message');
    const canal = interaction.options.getChannel('canal') || interaction.channel;
    const embed = new EmbedBuilder()
      .setTitle(`📣 ${titre}`)
      .setDescription(message)
      .setColor(0xE74C3C)
      .setFooter({ text: `Annoncé par ${interaction.user.tag}` });
    await canal.send({ embeds: [embed] });
    return interaction.reply('✅ Annonce envoyée.');
  }

  if (commandName === 'stats') {
    const guild = interaction.guild;
    const embed = new EmbedBuilder()
      .setTitle('📊 Statistiques')
      .addFields(
        { name: 'Serveur', value: guild.name, inline: true },
        { name: 'Membres', value: `${guild.memberCount}`, inline: true },
        { name: 'Bots', value: `${guild.members.cache.filter(m => m.user.bot).size}`, inline: true },
        { name: 'Canaux Texte', value: `${guild.channels.cache.filter(c => c.isTextBased()).size}`, inline: true },
        { name: 'Canaux Vocal', value: `${guild.channels.cache.filter(c => c.isVoiceBased()).size}`, inline: true },
        { name: 'Rôles', value: `${guild.roles.cache.size}`, inline: true }
      )
      .setColor(0x1ABC9C);
    return interaction.reply({ embeds: [embed] });
  }

  if (commandName === 'suggestion') {
    const titre = interaction.options.getString('titre');
    const description = interaction.options.getString('description');
    if (config.LOG_CHANNEL_ID) {
      const logChannel = interaction.guild.channels.cache.get(String(config.LOG_CHANNEL_ID));
      if (logChannel) {
        const embed = new EmbedBuilder()
          .setTitle(`💡 Suggestion: ${titre}`)
          .setDescription(description)
          .setAuthor({ name: interaction.user.tag, iconURL: interaction.user.displayAvatarURL() })
          .setColor(0xF39C12);
        const msg = await logChannel.send({ embeds: [embed] });
        await msg.react('👍');
        await msg.react('👎');
      }
    }
    return interaction.reply('✅ Suggestion envoyée.');
  }

  if (commandName === '8ball') {
    const question = interaction.options.getString('question');
    const responses = ['Oui', 'Non', 'Peut-être', 'Absolument', 'Impossible', 'Demande plus tard', 'Très probable', 'Doute fortement', 'Les signes pointent vers oui', 'Pas ma spécialité'];
    const response = responses[Math.floor(Math.random() * responses.length)];
    const embed = new EmbedBuilder()
      .setTitle('🔮 Boule Magique')
      .addFields(
        { name: 'Question', value: question, inline: false },
        { name: 'Réponse', value: `**${response}**`, inline: false }
      )
      .setColor(0x9B59B6);
    return interaction.reply({ embeds: [embed] });
  }

  if (commandName === 'dice') {
    const faces = interaction.options.getInteger('faces') || 6;
    if (faces < 2 || faces > 100) return interaction.reply({ content: 'Entre 2 et 100 faces.', ephemeral: true });
    const result = Math.floor(Math.random() * faces) + 1;
    const embed = new EmbedBuilder()
      .setTitle('🎲 Lancer de Dé')
      .addFields(
        { name: 'Faces', value: `${faces}`, inline: true },
        { name: 'Résultat', value: `**${result}**`, inline: true }
      )
      .setColor(0x3498DB);
    return interaction.reply({ embeds: [embed] });
  }

  if (commandName === 'report') {
    const user = interaction.options.getUser('utilisateur');
    const raison = interaction.options.getString('raison');
    if (config.LOG_CHANNEL_ID) {
      const logChannel = interaction.guild.channels.cache.get(String(config.LOG_CHANNEL_ID));
      if (logChannel) {
        const embed = new EmbedBuilder()
          .setTitle('🚨 Signalement')
          .addFields(
            { name: 'Utilisateur signalé', value: user.tag, inline: true },
            { name: 'Signalé par', value: interaction.user.tag, inline: true },
            { name: 'Raison', value: raison, inline: false }
          )
          .setColor(0xFF0000)
          .setTimestamp();
        logChannel.send({ embeds: [embed] }).catch(() => {});
      }
    }
    return interaction.reply({ content: '✅ Signalement envoyé aux modérateurs.', ephemeral: true });
  }

  if (commandName === 'bug') {
    const description = interaction.options.getString('description');
    if (config.LOG_CHANNEL_ID) {
      const logChannel = interaction.guild.channels.cache.get(String(config.LOG_CHANNEL_ID));
      if (logChannel) {
        const embed = new EmbedBuilder()
          .setTitle('🐛 Signalement de Bug')
          .setDescription(description)
          .setAuthor({ name: interaction.user.tag, iconURL: interaction.user.displayAvatarURL() })
          .setColor(0xFF6347)
          .setTimestamp();
        logChannel.send({ embeds: [embed] }).catch(() => {});
      }
    }
    return interaction.reply('✅ Bug signalé, merci !');
  }

  if (commandName === 'joke') {
    const jokes = [
      'Pourquoi les plongeurs plongent-ils toujours en arrière et jamais en avant ? Parce que sinon ils tombent dans le bateau !',
      'Qu\'est-ce qu\'un crocodile qui surveille la pharmacie ? Un Lacoste-guard !',
      'Comment appelle-t-on un chat tombé dans un pot de peinture le jour de Noël ? Un chat-peint de Noël !',
      'Quel est le comble pour un électricien ? De ne pas être au courant !',
      'Pourquoi les poissons n\'aiment pas jouer au tennis ? Parce qu\'ils ont peur du filet !',
      'Qu\'est-ce qu\'un cannibale végétarien ? Un humanitaire !',
      'Comment on appelle un ouf qui jette son pain ? Un boulanger fou !'
    ];
    const joke = jokes[Math.floor(Math.random() * jokes.length)];
    const embed = new EmbedBuilder()
      .setTitle('😂 Blague du Jour')
      .setDescription(joke)
      .setColor(0xFFD700);
    return interaction.reply({ embeds: [embed] });
  }

  if (commandName === 'quote') {
    const quotes = [
      'La vie est ce qui arrive pendant que tu fais d\'autres plans. - John Lennon',
      'Le seul moyen de faire du bon travail est d\'aimer ce que tu fais. - Steve Jobs',
      'La vraie intelligence c\'est de reconnaître son ignorance. - Socrate',
      'Les grandes choses ne se font jamais seul. - Richard Branson',
      'Le succès, c\'est d\'aller d\'échec en échec sans perdre son enthousiasme. - Winston Churchill',
      'La créativité c\'est l\'intelligence qui s\'amuse. - Albert Einstein'
    ];
    const quote = quotes[Math.floor(Math.random() * quotes.length)];
    const embed = new EmbedBuilder()
      .setTitle('💭 Citation du Jour')
      .setDescription(quote)
      .setColor(0x1ABC9C);
    return interaction.reply({ embeds: [embed] });
  }

  if (commandName === 'slots') {
    const symbols = ['🍎', '🍊', '🍋', '🍌', '🍒', '💎', '🎰'];
    const slot1 = symbols[Math.floor(Math.random() * symbols.length)];
    const slot2 = symbols[Math.floor(Math.random() * symbols.length)];
    const slot3 = symbols[Math.floor(Math.random() * symbols.length)];
    const win = slot1 === slot2 && slot2 === slot3;
    const embed = new EmbedBuilder()
      .setTitle('🎰 Machine à Sous')
      .setDescription(`**${slot1} ${slot2} ${slot3}**`)
      .addFields({ name: 'Résultat', value: win ? '🎉 GAGNANT !' : '😢 Perdu...', inline: false })
      .setColor(win ? 0x2ECC71 : 0xFF6B6B);
    return interaction.reply({ embeds: [embed] });
  }

  if (commandName === 'rps') {
    const choix = interaction.options.getString('choix');
    const choices = ['pierre', 'papier', 'ciseaux'];
    const botChoice = choices[Math.floor(Math.random() * choices.length)];
    let result = '';
    if (choix === botChoice) result = '🤝 Égalité !';
    else if ((choix === 'pierre' && botChoice === 'ciseaux') || (choix === 'papier' && botChoice === 'pierre') || (choix === 'ciseaux' && botChoice === 'papier')) result = '🎉 Tu as gagné !';
    else result = '😢 Tu as perdu !';
    
    const embed = new EmbedBuilder()
      .setTitle('✋ Pierre-Papier-Ciseaux')
      .addFields(
        { name: 'Ton choix', value: choix, inline: true },
        { name: 'Mon choix', value: botChoice, inline: true },
        { name: 'Résultat', value: result, inline: false }
      )
      .setColor(0xF39C12);
    return interaction.reply({ embeds: [embed] });
  }

  if (commandName === 'calc') {
    try {
      const expr = interaction.options.getString('expression');
      if (!/^[0-9+\-*/().%\s]*$/.test(expr)) return interaction.reply({ content: '❌ Expression invalide.', ephemeral: true });
      const result = eval(expr);
      const embed = new EmbedBuilder()
        .setTitle('🧮 Calculatrice')
        .addFields(
          { name: 'Expression', value: `\`${expr}\``, inline: true },
          { name: 'Résultat', value: `\`${result}\``, inline: true }
        )
        .setColor(0x3498DB);
      return interaction.reply({ embeds: [embed] });
    } catch (e) {
      return interaction.reply({ content: '❌ Erreur de calcul.', ephemeral: true });
    }
  }

  if (commandName === 'afk') {
    const raison = interaction.options.getString('raison') || 'AFK';
    const member = await interaction.guild.members.fetch(interaction.user.id).catch(() => null);
    if (member) {
      await member.setNickname(`[AFK] ${member.user.username}`).catch(() => {});
    }
    const embed = new EmbedBuilder()
      .setTitle('😴 Statut AFK Activé')
      .addFields({ name: 'Raison', value: raison, inline: false })
      .setColor(0x95A5A6);
    return interaction.reply({ embeds: [embed] });
  }

  if (commandName === 'color') {
    const nom = interaction.options.getString('nom');
    const hex = interaction.options.getString('hex');
    try {
      const color = parseInt(hex.replace('#', ''), 16);
      const role = await interaction.guild.roles.create({
        name: nom,
        color: color,
        reason: `Couleur personnalisée par ${interaction.user.tag}`
      });
      await interaction.member.roles.add(role);
      const embed = new EmbedBuilder()
        .setTitle('🎨 Couleur Créée')
        .addFields(
          { name: 'Nom', value: nom, inline: true },
          { name: 'Code', value: `#${hex}`, inline: true }
        )
        .setColor(color);
      return interaction.reply({ embeds: [embed] });
    } catch (e) {
      return interaction.reply({ content: '❌ Couleur hex invalide.', ephemeral: true });
    }
  }

  // Staff Commands
  if (commandName === 'botinfo') {
    const uptime = Date.now() - botStartTime;
    const days = Math.floor(uptime / 86400000);
    const hours = Math.floor((uptime % 86400000) / 3600000);
    const minutes = Math.floor((uptime % 3600000) / 60000);
    const seconds = Math.floor((uptime % 60000) / 1000);
    const uptimeStr = `${days}j ${hours}h ${minutes}m ${seconds}s`;
    
    const memUsage = process.memoryUsage();
    const memUsedMB = (memUsage.heapUsed / 1024 / 1024).toFixed(2);
    const memTotalMB = (memUsage.heapTotal / 1024 / 1024).toFixed(2);
    const memPercent = ((memUsage.heapUsed / memUsage.heapTotal) * 100).toFixed(1);
    
    const ping = client.ws.ping || 0;
    const pingStatus = ping < 100 ? '🟢 Excellent' : ping < 200 ? '🟡 Bon' : '🔴 Lent';
    
    const embed = new EmbedBuilder()
      .setTitle('🤖 Infos du Bot')
      .setThumbnail(client.user.avatarURL({ size: 256 }))
      .addFields(
        { 
          name: '📦 Bot', 
          value: `${client.user.username}\n\`${client.user.id}\``, 
          inline: true 
        },
        { 
          name: '📊 Statistiques', 
          value: `🖥️ Serveurs: **${client.guilds.cache.size}**\n👥 Utilisateurs: **${client.users.cache.size}**\n📝 Commandes: **43+**`, 
          inline: true 
        },
        { 
          name: '⏱️ Uptime', 
          value: `\`${uptimeStr}\``, 
          inline: true 
        },
        { 
          name: '🌍 Canaux', 
          value: `💬 ${client.channels.cache.filter(c => c.isTextBased()).size} texte\n🔊 ${client.channels.cache.filter(c => c.isVoiceBased()).size} vocaux`, 
          inline: true 
        },
        { 
          name: '💻 Mémoire', 
          value: `${memUsedMB}MB / ${memTotalMB}MB (${memPercent}%)`, 
          inline: true 
        },
        { 
          name: '🌐 Ping API', 
          value: `${pingStatus}\n\`${ping}ms\``, 
          inline: true 
        }
      )
      .setColor(0x3498DB)
      .setFooter({ text: 'LvCreations Bot v2.0.1' })
      .setTimestamp();
    return interaction.reply({ embeds: [embed] });
  }

  if (commandName === 'uptime') {
    const uptime = Date.now() - botStartTime;
    const days = Math.floor(uptime / 86400000);
    const hours = Math.floor((uptime % 86400000) / 3600000);
    const minutes = Math.floor((uptime % 3600000) / 60000);
    const seconds = Math.floor((uptime % 60000) / 1000);
    
    const uptimeStr = `${days}j ${hours}h ${minutes}m ${seconds}s`;
    const embed = new EmbedBuilder()
      .setTitle('⏱️ Uptime du Bot')
      .setDescription(`Le bot est en ligne depuis **${uptimeStr}**`)
      .setColor(0x2ECC71)
      .setTimestamp();
    return interaction.reply({ embeds: [embed] });
  }

  if (commandName === 'setstatus') {
    const newStatus = interaction.options.getString('statut');
    await client.user.setActivity(newStatus, { type: ActivityType.Playing });
    addLog(`Statut changé en: ${newStatus}`);
    const embed = new EmbedBuilder()
      .setTitle('✅ Statut Mis à Jour')
      .setDescription(`Nouveau statut: \`${newStatus}\``)
      .setColor(0x2ECC71);
    return interaction.reply({ embeds: [embed] });
  }

  if (commandName === 'protections') {
    const embed = createProtectionEmbed(interaction.guildId);
    return interaction.reply({ embeds: [embed] });
  }

  if (commandName === 'protectionsettings') {
    const protection = interaction.options.getString('protection');
    const action = interaction.options.getString('action') === 'on';
    const settings = getProtection(interaction.guildId);
    
    const settingsMap = {
      'antispam': 'antiSpam',
      'antiraid': 'antiRaid',
      'antiads': 'antiAds',
      'automod': 'autoMod',
      'logging': 'logging'
    };

    const key = settingsMap[protection];
    if (key && settings[key]) {
      settings[key].enabled = action;
      addLog(`Protection ${protection} ${action ? 'activée' : 'désactivée'} sur ${interaction.guild.name}`);
      
      const embed = createSuccessEmbed(
        'Protection Mise à Jour',
        `🛡️ **${protection.toUpperCase()}** est maintenant **${action ? '✅ Activée' : '❌ Désactivée'}**`
      );
      return interaction.reply({ embeds: [embed] });
    }

    const embed = createErrorEmbed('Erreur', 'Protection non trouvée.');
    return interaction.reply({ embeds: [embed], ephemeral: true });
  }

  if (commandName === 'settings') {
    const subcommand = interaction.options.getSubcommand();
    
    if (subcommand === 'welcome') {
      const channel = interaction.options.getChannel('channel');
      const embed = createSuccessEmbed('Canal de Bienvenue', `📥 Configuré sur ${channel}`);
      return interaction.reply({ embeds: [embed] });
    }
    
    if (subcommand === 'logs') {
      const channel = interaction.options.getChannel('channel');
      const embed = createSuccessEmbed('Canal de Logs', `📋 Configuré sur ${channel}`);
      return interaction.reply({ embeds: [embed] });
    }
    
    if (subcommand === 'prefix') {
      const prefix = interaction.options.getString('prefix');
      const embed = createSuccessEmbed('Préfixe', `✅ Préfixe changé en: \`${prefix}\``);
      return interaction.reply({ embeds: [embed] });
    }
    
    if (subcommand === 'language') {
      const lang = interaction.options.getString('language');
      const langNames = { 'fr': 'Français', 'en': 'English', 'es': 'Español' };
      const embed = createSuccessEmbed('Langue', `🌐 Langue changée en: **${langNames[lang]}**`);
      return interaction.reply({ embeds: [embed] });
    }
    
    if (subcommand === 'view') {
      const embed = new EmbedBuilder()
        .setTitle('⚙️ Paramètres du Serveur')
        .setColor(0x3498DB)
        .addFields(
          { name: '📥 Canal de Bienvenue', value: 'Non configuré', inline: true },
          { name: '📋 Canal de Logs', value: 'Non configuré', inline: true },
          { name: '🔤 Préfixe', value: '/', inline: true },
          { name: '🌐 Langue', value: 'Français', inline: true }
        )
        .setTimestamp();
      return interaction.reply({ embeds: [embed] });
    }
  }

  if (commandName === 'reload') {
    try {
      const embed = new EmbedBuilder()
        .setTitle('🔄 Redémarrage du Bot')
        .setDescription('Le bot redémarre...')
        .setColor(0xF39C12);
      await interaction.reply({ embeds: [embed] });
      addLog('Redémarrage du bot demandé par ' + interaction.user.tag);
      setTimeout(() => process.exit(0), 2000);
    } catch (error) {
      await handleCommandError(interaction, error, 'reload');
    }
    return;
  }

  if (commandName === 'poweroff') {
    const embed = new EmbedBuilder()
      .setTitle('⛔ Arrêt du Bot')
      .setDescription('Le bot s\'éteint...')
      .setColor(0xFF6B6B);
    await interaction.reply({ embeds: [embed] });
    addLog('Arrêt du bot demandé par ' + interaction.user.tag);
    setTimeout(() => process.exit(0), 1000);
  }

  if (commandName === 'leaderboard') {
    const guild = interaction.guild;
    const levels = storage.get('levels') || {};
    const sorted = Object.entries(levels)
      .map(([userId, data]) => ({ userId, xp: data.xp || 0, level: data.level || 1 }))
      .sort((a, b) => b.xp - a.xp)
      .slice(0, 10);
    
    let description = '';
    for (let i = 0; i < sorted.length; i++) {
      const user = await guild.members.fetch(sorted[i].userId).catch(() => null);
      const medal = i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : `${i + 1}️⃣`;
      description += `${medal} **${user?.user?.username || 'Utilisateur supprimé'}** - Niveau **${sorted[i].level}** | ${utils.formatNumber(sorted[i].xp)} XP\n`;
    }

    const embed = new EmbedBuilder()
      .setTitle('🏆 Classement XP')
      .setDescription(description || 'Aucune donnée disponible')
      .setColor(0xF39C12)
      .setTimestamp();
    
    interaction.reply({ embeds: [embed] });
  }

  if (commandName === 'serverstat') {
    const guild = interaction.guild;
    const members = await guild.members.fetch();
    const humans = members.filter(m => !m.user.bot).size;
    const bots = members.filter(m => m.user.bot).size;
    const channels = guild.channels.cache;
    const roles = guild.roles.cache.size;

    const embed = new EmbedBuilder()
      .setTitle(`📊 Statistiques de ${guild.name}`)
      .addFields(
        { name: '👥 Membres', value: `**Total:** ${members.size}\n**Humains:** ${humans}\n**Bots:** ${bots}`, inline: true },
        { name: '📺 Canaux', value: `**Total:** ${channels.size}\n**Texte:** ${channels.filter(c => c.isTextBased()).size}\n**Vocal:** ${channels.filter(c => c.isVoiceBased()).size}`, inline: true },
        { name: '🏷️ Rôles', value: `**Total:** ${roles}`, inline: true },
        { name: '📅 Créé le', value: `<t:${Math.floor(guild.createdTimestamp / 1000)}:d>`, inline: true },
        { name: '🛡️ Niveau de vérification', value: guild.verificationLevel, inline: true },
        { name: '🚀 Boost', value: `${guild.premiumSubscriptionCount || 0} boosts (Niveau ${guild.premiumTier})`, inline: true }
      )
      .setThumbnail(guild.iconURL())
      .setColor(0x3498DB)
      .setTimestamp();

    interaction.reply({ embeds: [embed] });
  }

  if (commandName === 'memberslist') {
    const guild = interaction.guild;
    const members = await guild.members.fetch();
    const sorted = [...members.values()]
      .sort((a, b) => (b.joinedTimestamp || 0) - (a.joinedTimestamp || 0))
      .slice(0, 15);

    let description = '';
    sorted.forEach((member, idx) => {
      description += `${idx + 1}. **${member.user.username}** - Rejoint <t:${Math.floor(member.joinedTimestamp / 1000)}:R>\n`;
    });

    const embed = new EmbedBuilder()
      .setTitle('👥 Membres Récemment Actifs')
      .setDescription(description || 'Aucun membre')
      .setColor(0x9B59B6)
      .setFooter({ text: `Total: ${members.size} membres` })
      .setTimestamp();

    interaction.reply({ embeds: [embed] });
  }

  if (commandName === 'invite') {
    const botUser = await client.user.fetch();
    const invite = `https://discord.com/api/oauth2/authorize?client_id=${botUser.id}&permissions=8&scope=bot%20applications.commands`;
    
    const embed = new EmbedBuilder()
      .setTitle('🔗 Ajouter le Bot')
      .setDescription(`[Cliquez ici pour ajouter ${botUser.username} à votre serveur](${invite})`)
      .setColor(0x2ECC71)
      .setThumbnail(botUser.displayAvatarURL());

    interaction.reply({ embeds: [embed] });
  }

  if (commandName === 'support') {
    const embed = new EmbedBuilder()
      .setTitle('💬 Support')
      .setDescription('**Besoin d\'aide ?**\n\n• Utilisez `/help` pour voir toutes les commandes\n• Visitez notre serveur de support\n• Contactez les administrateurs')
      .setColor(0x3498DB)
      .addFields(
        { name: '📧 Email', value: 'support@example.com', inline: false },
        { name: '🌐 Site Web', value: '[Visiter notre site](https://example.com)', inline: false }
      );

    interaction.reply({ embeds: [embed] });
  }

  if (commandName === 'randomquiz') {
    const quiz = advanced.getRandomQuiz();
    if (!quiz) {
      return interaction.reply({ content: '❌ Aucun quiz disponible.', ephemeral: true });
    }

    const embed = new EmbedBuilder()
      .setTitle('❓ Quiz Aléatoire')
      .setDescription(`**Question:** ${quiz.question}`)
      .addFields(
        { name: '📝 Réponses', value: quiz.answers.map((a, i) => `${i + 1}️⃣ ${a}`).join('\n'), inline: false }
      )
      .setColor(0xE74C3C)
      .setFooter({ text: `La réponse correcte est: ${quiz.correct}` })
      .setTimestamp();

    return interaction.reply({ embeds: [embed] });
  }

  if (commandName === 'eval') {
    // Security: Only allow bot owner/admins
    if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
      return interaction.reply({ content: '❌ Accès refusé. Seul un administrateur peut utiliser cette commande.', ephemeral: true });
    }
    
    const code = interaction.options.getString('code');
    try {
      // Use Function instead of eval for better security
      const AsyncFunction = Object.getPrototypeOf(async function(){}).constructor;
      const fn = new AsyncFunction('client', 'interaction', 'config', code);
      let result = await fn(client, interaction, config);
      if (typeof result !== 'string') result = JSON.stringify(result, null, 2);
      if (result.length > 2000) result = result.substring(0, 1997) + '...';
      const embed = new EmbedBuilder()
        .setTitle('📝 Résultat Eval')
        .setDescription('```js\n' + result + '\n```')
        .setColor(0x2ECC71);
      addLog(`Eval exécuté: ${code}`);
      return interaction.reply({ embeds: [embed] });
    } catch (error) {
      const embed = new EmbedBuilder()
        .setTitle('❌ Erreur Eval')
        .setDescription('```js\n' + error.message + '\n```')
        .setColor(0xFF6B6B);
      addLog(`Erreur Eval: ${error.message}`);
      return interaction.reply({ embeds: [embed] });
    }
  }

  if (commandName === 'logs') {
    const logsText = botLogs.slice(-20).join('\n');
    const embed = new EmbedBuilder()
      .setTitle('📋 Derniers Logs')
      .setDescription('```\n' + (logsText || 'Aucun logs') + '\n```')
      .setColor(0x3498DB);
    return interaction.reply({ embeds: [embed] });
  }
  
  } catch (error) {
    addLog(`Erreur interaction: ${error.message}`);
    console.error('Erreur:', error);
    try {
      if (!interaction.replied && !interaction.deferred) {
        await interaction.reply({ content: '❌ Erreur lors de l\'exécution de la commande.', ephemeral: true });
      } else if (interaction.deferred) {
        await interaction.editReply({ content: '❌ Erreur lors de l\'exécution de la commande.' });
      }
    } catch (e) {
      console.error('Impossible de notifier erreur:', e);
    }
  }
});

// Nettoyage lors de l'arrêt du bot
process.on('SIGINT', () => {
  console.log('\n🛑 Arrêt du bot...');
  
  if (statsInterval) {
    clearInterval(statsInterval);
    console.log('✅ Intervalle des stats arrêté');
  }
  
  // Déconnecter de tous les salons vocaux
  for (const queue of queues.values()) {
    if (queue.connection) {
      queue.connection.destroy();
    }
  }
  
  client.destroy();
  console.log('✅ Bot désactivé avec succès');
  process.exit(0);
});

// Error handling
client.on(Events.Error, (error) => {
  addLog(`⚠️ ERREUR CLIENT: ${error.message}`, 'ERROR', {
    'Stack': error.stack?.substring(0, 500) || 'N/A'
  });
});

process.on('uncaughtException', (error) => {
  addLog(`💥 EXCEPTION NON GÉRÉE: ${error.message}`, 'ERROR', {
    'Stack': error.stack?.substring(0, 500) || 'N/A'
  });
  console.error('Uncaught Exception:', error);
});

process.on('unhandledRejection', (reason) => {
  addLog(`⚡ PROMESSE REJETÉE: ${String(reason).substring(0, 200)}`, 'ERROR', {});
  console.error('Unhandled Rejection:', reason);
});

client.login(config.DISCORD_TOKEN);