const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const crypto = require('crypto');

class CaptchaManager {
  constructor() {
    this.activeCaptchas = new Map();
    this.verifiedUsers = new Set();
  }

  generateCode() {
    // Génère un code captcha simple (4 chiffres)
    return Math.floor(1000 + Math.random() * 9000).toString();
  }

  generateMathCaptcha() {
    // Génère un problème mathématique simple
    const operations = ['+', '-', '*'];
    const operation = operations[Math.floor(Math.random() * operations.length)];
    const num1 = Math.floor(Math.random() * 20) + 1;
    const num2 = Math.floor(Math.random() * 20) + 1;
    
    let result;
    switch (operation) {
      case '+': result = num1 + num2; break;
      case '-': result = num1 - num2; break;
      case '*': result = num1 * num2; break;
    }

    return {
      question: `${num1} ${operation} ${num2} = ?`,
      answer: result.toString()
    };
  }

  generateImageCaptcha() {
    // Génère un code visuel simple (6 caractères aléatoires)
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let code = '';
    for (let i = 0; i < 6; i++) {
      code += chars[Math.floor(Math.random() * chars.length)];
    }
    return code;
  }

  createCaptchaEmbed(userId, type = 'code') {
    const embed = new EmbedBuilder()
      .setColor('#5865F2')
      .setTitle('🔐 Vérification Requise')
      .setDescription('Veuillez compléter le captcha pour accéder au serveur.')
      .setThumbnail('https://cdn.discordapp.com/emojis/1087930833836666972.png');

    if (type === 'code') {
      const code = this.generateCode();
      this.activeCaptchas.set(userId, {
        code,
        type: 'code',
        timestamp: Date.now(),
        attempts: 0
      });
      embed.addFields([
        { name: '📝 Entrez ce code:', value: `\`${code}\``, inline: false },
        { name: '⏱️ Expire dans:', value: '10 minutes', inline: false }
      ]);
    } else if (type === 'math') {
      const math = this.generateMathCaptcha();
      this.activeCaptchas.set(userId, {
        answer: math.answer,
        type: 'math',
        timestamp: Date.now(),
        attempts: 0
      });
      embed.addFields([
        { name: '🧮 Résolvez:', value: `\`${math.question}\``, inline: false },
        { name: '⏱️ Expire dans:', value: '10 minutes', inline: false }
      ]);
    } else if (type === 'image') {
      const code = this.generateImageCaptcha();
      this.activeCaptchas.set(userId, {
        code,
        type: 'image',
        timestamp: Date.now(),
        attempts: 0
      });
      embed.addFields([
        { name: '🖼️ Entrez ce code:', value: `\`${code}\``, inline: false },
        { name: '⏱️ Expire dans:', value: '10 minutes', inline: false }
      ]);
    }

    return embed;
  }

  createCaptchaButtons() {
    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('captcha_submit')
          .setLabel('✅ Soumettre')
          .setStyle(ButtonStyle.Success),
        new ButtonBuilder()
          .setCustomId('captcha_refresh')
          .setLabel('🔄 Nouveau Code')
          .setStyle(ButtonStyle.Primary)
      );
    return row;
  }

  verifyCaptcha(userId, answer, type = 'code') {
    const captcha = this.activeCaptchas.get(userId);
    if (!captcha) return { success: false, message: '❌ Aucun captcha actif trouvé.' };

    // Vérifier l'expiration (10 minutes)
    if (Date.now() - captcha.timestamp > 600000) {
      this.activeCaptchas.delete(userId);
      return { success: false, message: '❌ Le captcha a expiré.' };
    }

    // Vérifier les tentatives
    if (captcha.attempts >= 5) {
      this.activeCaptchas.delete(userId);
      return { success: false, message: '❌ Trop de tentatives échouées. Recommencez.' };
    }

    // Vérifier le captcha
    let isCorrect = false;
    if (type === 'code' || type === 'image') {
      isCorrect = answer.trim().toUpperCase() === captcha.code.toUpperCase();
    } else if (type === 'math') {
      isCorrect = answer.trim() === captcha.answer;
    }

    if (isCorrect) {
      this.activeCaptchas.delete(userId);
      this.verifiedUsers.add(userId);
      return { success: true, message: '✅ Vérification réussie!' };
    } else {
      captcha.attempts++;
      return { success: false, message: `❌ Réponse incorrecte. (${5 - captcha.attempts} tentatives restantes)` };
    }
  }

  isVerified(userId) {
    return this.verifiedUsers.has(userId);
  }

  markVerified(userId) {
    this.verifiedUsers.add(userId);
  }

  clearVerified(userId) {
    this.verifiedUsers.delete(userId);
  }

  getStats() {
    return {
      activeCount: this.activeCaptchas.size,
      verifiedCount: this.verifiedUsers.size
    };
  }
}

module.exports = new CaptchaManager();
