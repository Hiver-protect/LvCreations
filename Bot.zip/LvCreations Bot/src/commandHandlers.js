const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const captchaManager = require('./captcha');
const settingsManager = require('./settings');

const handleCaptcha = async (interaction, client) => {
  const { commandName, options, guildId, user, member } = interaction;

  if (commandName === 'captcha') {
    const subcommand = options.getSubcommand();

    if (subcommand === 'enable') {
      settingsManager.setCaptchaEnabled(guildId, true);
      const embed = new EmbedBuilder()
        .setColor('#43B581')
        .setTitle('✅ Captcha Activé')
        .setDescription('Le système de captcha a été activé sur ce serveur.');
      await interaction.reply({ embeds: [embed], ephemeral: true });
    }

    else if (subcommand === 'disable') {
      settingsManager.setCaptchaEnabled(guildId, false);
      const embed = new EmbedBuilder()
        .setColor('#F04747')
        .setTitle('❌ Captcha Désactivé')
        .setDescription('Le système de captcha a été désactivé.');
      await interaction.reply({ embeds: [embed], ephemeral: true });
    }

    else if (subcommand === 'type') {
      const type = options.getString('type');
      settingsManager.setCaptchaType(guildId, type);
      const typeNames = { code: 'Code Simple', math: 'Problème Mathématique', image: 'Code Image' };
      const embed = new EmbedBuilder()
        .setColor('#5865F2')
        .setTitle('🔄 Type de Captcha Changé')
        .setDescription(`Type: **${typeNames[type]}**`);
      await interaction.reply({ embeds: [embed], ephemeral: true });
    }

    else if (subcommand === 'status') {
      const stats = captchaManager.getStats();
      const isEnabled = settingsManager.getCaptchaEnabled(guildId);
      const type = settingsManager.getCaptchaType(guildId);
      const embed = new EmbedBuilder()
        .setColor('#5865F2')
        .setTitle('📊 État du Captcha')
        .addFields([
          { name: 'Statut', value: isEnabled ? '✅ Activé' : '❌ Désactivé', inline: true },
          { name: 'Type', value: type === 'code' ? 'Code Simple' : type === 'math' ? 'Problème Mathématique' : 'Code Image', inline: true },
          { name: 'Captchas Actifs', value: stats.activeCount.toString(), inline: true },
          { name: 'Utilisateurs Vérifiés', value: stats.verifiedCount.toString(), inline: true }
        ]);
      await interaction.reply({ embeds: [embed], ephemeral: true });
    }
  }
};

const handleSettings = async (interaction, client) => {
  const { commandName, options, guildId } = interaction;

  if (commandName === 'settings') {
    const subcommand = options.getSubcommand();

    if (subcommand === 'welcome') {
      const channel = options.getChannel('channel');
      settingsManager.setWelcomeChannel(guildId, channel.id);
      const embed = new EmbedBuilder()
        .setColor('#43B581')
        .setTitle('✅ Canal de Bienvenue Configuré')
        .setDescription(`Canal: ${channel}`);
      await interaction.reply({ embeds: [embed], ephemeral: true });
    }

    else if (subcommand === 'logs') {
      const channel = options.getChannel('channel');
      settingsManager.setLogsChannel(guildId, channel.id);
      const embed = new EmbedBuilder()
        .setColor('#43B581')
        .setTitle('✅ Canal de Logs Configuré')
        .setDescription(`Canal: ${channel}`);
      await interaction.reply({ embeds: [embed], ephemeral: true });
    }

    else if (subcommand === 'prefix') {
      const prefix = options.getString('prefix');
      settingsManager.setPrefix(guildId, prefix);
      const embed = new EmbedBuilder()
        .setColor('#43B581')
        .setTitle('✅ Préfixe Changé')
        .setDescription(`Nouveau préfixe: \`${prefix}\``);
      await interaction.reply({ embeds: [embed], ephemeral: true });
    }

    else if (subcommand === 'language') {
      const lang = options.getString('language');
      settingsManager.setLanguage(guildId, lang);
      const langNames = { fr: 'Français', en: 'English', es: 'Español' };
      const embed = new EmbedBuilder()
        .setColor('#43B581')
        .setTitle('✅ Langue Changée')
        .setDescription(`Nouvelle langue: **${langNames[lang]}**`);
      await interaction.reply({ embeds: [embed], ephemeral: true });
    }

    else if (subcommand === 'view') {
      const settings = settingsManager.getGuildSettings(guildId);
      const embed = new EmbedBuilder()
        .setColor('#5865F2')
        .setTitle('⚙️ Paramètres du Serveur')
        .addFields([
          { name: 'Préfixe', value: `\`${settings.prefix}\``, inline: true },
          { name: 'Langue', value: settings.language.toUpperCase(), inline: true },
          { name: 'Captcha', value: settings.captchaEnabled ? '✅ Activé' : '❌ Désactivé', inline: true },
          { name: 'Type de Captcha', value: settings.captchaType === 'code' ? 'Code' : settings.captchaType === 'math' ? 'Maths' : 'Image', inline: true },
          { name: 'Auto-Modération', value: settings.autoModeration ? '✅' : '❌', inline: true },
          { name: 'Anti-Raid', value: settings.antiRaid ? '✅' : '❌', inline: true },
          { name: 'Anti-Spam', value: settings.antiSpam ? '✅' : '❌', inline: true },
          { name: 'Système de Niveaux', value: settings.levelSystem ? '✅' : '❌', inline: true },
          { name: 'Format Musique', value: settings.musicFormat, inline: true },
          { name: 'Timezone', value: settings.timezone, inline: true }
        ]);
      await interaction.reply({ embeds: [embed], ephemeral: true });
    }
  }
};

module.exports = {
  handleCaptcha,
  handleSettings
};
