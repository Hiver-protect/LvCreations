const fs = require('fs');
const path = require('path');

class SettingsManager {
  constructor() {
    this.dataFile = path.join(__dirname, '../data.json');
    this.defaultSettings = {
      prefix: '/',
      language: 'fr',
      captchaEnabled: true,
      captchaType: 'code',
      welcomeChannel: null,
      logsChannel: null,
      ticketCategory: null,
      staffRole: null,
      modLogChannel: null,
      autoModeration: true,
      antiRaid: true,
      antiSpam: true,
      levelSystem: true,
      musicFormat: 'high',
      timezone: 'Europe/Paris'
    };
    this.guildSettings = new Map();
    this.loadSettings();
  }

  loadSettings() {
    try {
      if (fs.existsSync(this.dataFile)) {
        const data = fs.readFileSync(this.dataFile, 'utf-8');
        const parsed = JSON.parse(data);
        if (parsed.guildSettings) {
          Object.entries(parsed.guildSettings).forEach(([guildId, settings]) => {
            this.guildSettings.set(guildId, { ...this.defaultSettings, ...settings });
          });
        }
      }
    } catch (error) {
      console.error('Erreur lors du chargement des settings:', error);
    }
  }

  saveSettings() {
    try {
      const data = {
        guildSettings: Object.fromEntries(this.guildSettings)
      };
      fs.writeFileSync(this.dataFile, JSON.stringify(data, null, 2));
    } catch (error) {
      console.error('Erreur lors de la sauvegarde des settings:', error);
    }
  }

  getGuildSettings(guildId) {
    if (!this.guildSettings.has(guildId)) {
      this.guildSettings.set(guildId, { ...this.defaultSettings });
      this.saveSettings();
    }
    return this.guildSettings.get(guildId);
  }

  setSetting(guildId, key, value) {
    const settings = this.getGuildSettings(guildId);
    settings[key] = value;
    this.saveSettings();
    return settings;
  }

  updateSettings(guildId, updates) {
    const settings = this.getGuildSettings(guildId);
    const updated = { ...settings, ...updates };
    this.guildSettings.set(guildId, updated);
    this.saveSettings();
    return updated;
  }

  resetSettings(guildId) {
    this.guildSettings.set(guildId, { ...this.defaultSettings });
    this.saveSettings();
    return this.guildSettings.get(guildId);
  }

  // CAPTCHA SETTINGS
  setCaptchaEnabled(guildId, enabled) {
    return this.setSetting(guildId, 'captchaEnabled', enabled);
  }

  getCaptchaEnabled(guildId) {
    return this.getGuildSettings(guildId).captchaEnabled;
  }

  setCaptchaType(guildId, type) {
    if (!['code', 'math', 'image'].includes(type)) {
      throw new Error('Type de captcha invalide');
    }
    return this.setSetting(guildId, 'captchaType', type);
  }

  getCaptchaType(guildId) {
    return this.getGuildSettings(guildId).captchaType;
  }

  // CHANNEL SETTINGS
  setWelcomeChannel(guildId, channelId) {
    return this.setSetting(guildId, 'welcomeChannel', channelId);
  }

  getWelcomeChannel(guildId) {
    return this.getGuildSettings(guildId).welcomeChannel;
  }

  setLogsChannel(guildId, channelId) {
    return this.setSetting(guildId, 'logsChannel', channelId);
  }

  getLogsChannel(guildId) {
    return this.getGuildSettings(guildId).logsChannel;
  }

  setModLogChannel(guildId, channelId) {
    return this.setSetting(guildId, 'modLogChannel', channelId);
  }

  getModLogChannel(guildId) {
    return this.getGuildSettings(guildId).modLogChannel;
  }

  // ROLE SETTINGS
  setStaffRole(guildId, roleId) {
    return this.setSetting(guildId, 'staffRole', roleId);
  }

  getStaffRole(guildId) {
    return this.getGuildSettings(guildId).staffRole;
  }

  // PREFIX & LANGUAGE
  setPrefix(guildId, prefix) {
    if (prefix.length > 5) {
      throw new Error('Préfixe trop long');
    }
    return this.setSetting(guildId, 'prefix', prefix);
  }

  getPrefix(guildId) {
    return this.getGuildSettings(guildId).prefix;
  }

  setLanguage(guildId, lang) {
    if (!['fr', 'en', 'es'].includes(lang)) {
      throw new Error('Langue invalide');
    }
    return this.setSetting(guildId, 'language', lang);
  }

  getLanguage(guildId) {
    return this.getGuildSettings(guildId).language;
  }

  // FEATURES SETTINGS
  setAutoModeration(guildId, enabled) {
    return this.setSetting(guildId, 'autoModeration', enabled);
  }

  getAutoModeration(guildId) {
    return this.getGuildSettings(guildId).autoModeration;
  }

  setAntiRaid(guildId, enabled) {
    return this.setSetting(guildId, 'antiRaid', enabled);
  }

  getAntiRaid(guildId) {
    return this.getGuildSettings(guildId).antiRaid;
  }

  setAntiSpam(guildId, enabled) {
    return this.setSetting(guildId, 'antiSpam', enabled);
  }

  getAntiSpam(guildId) {
    return this.getGuildSettings(guildId).antiSpam;
  }

  setLevelSystem(guildId, enabled) {
    return this.setSetting(guildId, 'levelSystem', enabled);
  }

  getLevelSystem(guildId) {
    return this.getGuildSettings(guildId).levelSystem;
  }

  // MUSIC SETTINGS
  setMusicFormat(guildId, format) {
    if (!['low', 'medium', 'high'].includes(format)) {
      throw new Error('Format invalide');
    }
    return this.setSetting(guildId, 'musicFormat', format);
  }

  getMusicFormat(guildId) {
    return this.getGuildSettings(guildId).musicFormat;
  }

  // TIMEZONE
  setTimezone(guildId, timezone) {
    return this.setSetting(guildId, 'timezone', timezone);
  }

  getTimezone(guildId) {
    return this.getGuildSettings(guildId).timezone;
  }

  // EXPORT SETTINGS
  exportSettings(guildId) {
    return JSON.stringify(this.getGuildSettings(guildId), null, 2);
  }

  // IMPORT SETTINGS
  importSettings(guildId, settingsJSON) {
    try {
      const settings = JSON.parse(settingsJSON);
      this.updateSettings(guildId, settings);
      return true;
    } catch (error) {
      console.error('Erreur lors de l\'import des settings:', error);
      return false;
    }
  }

  // GET ALL STATS
  getAllStats() {
    return {
      guilds: this.guildSettings.size,
      totalSettings: this.guildSettings.size * Object.keys(this.defaultSettings).length,
      defaultSettings: this.defaultSettings
    };
  }
}

module.exports = new SettingsManager();
