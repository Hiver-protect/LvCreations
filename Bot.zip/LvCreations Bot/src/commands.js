const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');

const commands = [
  // === COMMANDES CAPTCHA ===
  new SlashCommandBuilder()
    .setName('captcha')
    .setDescription('Gérer le système de captcha')
    .addSubcommand(sub => sub
      .setName('enable')
      .setDescription('Activer le captcha sur le serveur')
    )
    .addSubcommand(sub => sub
      .setName('disable')
      .setDescription('Désactiver le captcha')
    )
    .addSubcommand(sub => sub
      .setName('type')
      .setDescription('Changer le type de captcha')
      .addStringOption(opt => opt
        .setName('type')
        .setDescription('Type: code, math, image')
        .setRequired(true)
        .addChoices(
          { name: 'Code Simple', value: 'code' },
          { name: 'Problème Mathématique', value: 'math' },
          { name: 'Code Image', value: 'image' }
        )
      )
    )
    .addSubcommand(sub => sub
      .setName('status')
      .setDescription('Voir l\'état du captcha')
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  // === COMMANDES UTILITAIRES ===
  new SlashCommandBuilder()
    .setName('settings')
    .setDescription('Gérer les paramètres du serveur')
    .addSubcommand(sub => sub
      .setName('welcome')
      .setDescription('Configurer le message de bienvenue')
      .addChannelOption(opt => opt
        .setName('channel')
        .setDescription('Canal de bienvenue')
        .setRequired(true)
      )
    )
    .addSubcommand(sub => sub
      .setName('logs')
      .setDescription('Configurer le canal de logs')
      .addChannelOption(opt => opt
        .setName('channel')
        .setDescription('Canal de logs')
        .setRequired(true)
      )
    )
    .addSubcommand(sub => sub
      .setName('prefix')
      .setDescription('Changer le préfixe du bot')
      .addStringOption(opt => opt
        .setName('prefix')
        .setDescription('Nouveau préfixe')
        .setRequired(true)
        .setMinLength(1)
        .setMaxLength(5)
      )
    )
    .addSubcommand(sub => sub
      .setName('language')
      .setDescription('Changer la langue du bot')
      .addStringOption(opt => opt
        .setName('language')
        .setDescription('Langue')
        .setRequired(true)
        .addChoices(
          { name: 'Français', value: 'fr' },
          { name: 'English', value: 'en' },
          { name: 'Español', value: 'es' }
        )
      )
    )
    .addSubcommand(sub => sub
      .setName('view')
      .setDescription('Voir tous les paramètres')
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  // === COMMANDES MODÉRATION ===
  new SlashCommandBuilder()
    .setName('warn')
    .setDescription('Avertir un utilisateur')
    .addUserOption(opt => opt
      .setName('user')
      .setDescription('Utilisateur à avertir')
      .setRequired(true)
    )
    .addStringOption(opt => opt
      .setName('reason')
      .setDescription('Raison du warn')
      .setRequired(false)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  new SlashCommandBuilder()
    .setName('kick')
    .setDescription('Expulser un utilisateur')
    .addUserOption(opt => opt
      .setName('user')
      .setDescription('Utilisateur à expulser')
      .setRequired(true)
    )
    .addStringOption(opt => opt
      .setName('reason')
      .setDescription('Raison du kick')
      .setRequired(false)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers),

  new SlashCommandBuilder()
    .setName('ban')
    .setDescription('Bannir un utilisateur')
    .addUserOption(opt => opt
      .setName('user')
      .setDescription('Utilisateur à bannir')
      .setRequired(true)
    )
    .addStringOption(opt => opt
      .setName('reason')
      .setDescription('Raison du ban')
      .setRequired(false)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),

  new SlashCommandBuilder()
    .setName('timeout')
    .setDescription('Mettre un utilisateur en timeout')
    .addUserOption(opt => opt
      .setName('user')
      .setDescription('Utilisateur')
      .setRequired(true)
    )
    .addStringOption(opt => opt
      .setName('duration')
      .setDescription('Durée (1m, 1h, 1d, etc.)')
      .setRequired(true)
    )
    .addStringOption(opt => opt
      .setName('reason')
      .setDescription('Raison')
      .setRequired(false)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  // === COMMANDES INFO ===
  new SlashCommandBuilder()
    .setName('serverinfo')
    .setDescription('Voir les informations du serveur'),

  new SlashCommandBuilder()
    .setName('userinfo')
    .setDescription('Voir les informations d\'un utilisateur')
    .addUserOption(opt => opt
      .setName('user')
      .setDescription('Utilisateur')
      .setRequired(false)
    ),

  new SlashCommandBuilder()
    .setName('stats')
    .setDescription('Voir les statistiques du bot'),

  new SlashCommandBuilder()
    .setName('help')
    .setDescription('Afficher l\'aide'),

  // === COMMANDES MUSIQUE ===
  new SlashCommandBuilder()
    .setName('play')
    .setDescription('Jouer une musique')
    .addStringOption(opt => opt
      .setName('song')
      .setDescription('Nom ou URL de la chanson')
      .setRequired(true)
    ),

  new SlashCommandBuilder()
    .setName('stop')
    .setDescription('Arrêter la musique'),

  new SlashCommandBuilder()
    .setName('pause')
    .setDescription('Mettre en pause'),

  new SlashCommandBuilder()
    .setName('resume')
    .setDescription('Reprendre la musique'),

  new SlashCommandBuilder()
    .setName('skip')
    .setDescription('Passer à la chanson suivante'),

  new SlashCommandBuilder()
    .setName('queue')
    .setDescription('Voir la file d\'attente'),

  // === COMMANDES GIVEAWAY ===
  new SlashCommandBuilder()
    .setName('giveaway')
    .setDescription('Créer un giveaway')
    .addStringOption(opt => opt
      .setName('prize')
      .setDescription('Prix du giveaway')
      .setRequired(true)
    )
    .addStringOption(opt => opt
      .setName('duration')
      .setDescription('Durée (1m, 1h, 1d, etc.)')
      .setRequired(true)
    )
    .addIntegerOption(opt => opt
      .setName('winners')
      .setDescription('Nombre de gagnants')
      .setRequired(false)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),

  // === COMMANDES TICKETS ===
  new SlashCommandBuilder()
    .setName('ticket')
    .setDescription('Gérer les tickets')
    .addSubcommand(sub => sub
      .setName('create')
      .setDescription('Créer un panel de tickets')
    )
    .addSubcommand(sub => sub
      .setName('close')
      .setDescription('Fermer le ticket')
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),

  // === COMMANDES ADMIN ===
  new SlashCommandBuilder()
    .setName('reload')
    .setDescription('Recharger les commandes')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  new SlashCommandBuilder()
    .setName('ping')
    .setDescription('Voir le ping du bot'),

  new SlashCommandBuilder()
    .setName('clear')
    .setDescription('Supprimer des messages')
    .addIntegerOption(opt => opt
      .setName('amount')
      .setDescription('Nombre de messages à supprimer')
      .setRequired(true)
      .setMinValue(1)
      .setMaxValue(100)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
];

module.exports = commands;
