const fs = require('fs');
const path = require('path');

const dataPath = path.join(__dirname, '..', 'data.json');

const defaultData = {
  levels: {},
  tickets: {},
  reactionRoles: {},
  statsMessageId: null,
  infoMessageId: null
};

const load = () => {
  if (!fs.existsSync(dataPath)) {
    fs.writeFileSync(dataPath, JSON.stringify(defaultData, null, 2));
    return { ...defaultData };
  }
  try {
    const raw = fs.readFileSync(dataPath, 'utf8');
    const parsed = JSON.parse(raw);
    return { ...defaultData, ...parsed };
  } catch {
    fs.writeFileSync(dataPath, JSON.stringify(defaultData, null, 2));
    return { ...defaultData };
  }
};

let data = load();

const save = () => {
  fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
};

const getLevel = (userId) => data.levels[String(userId)] || null;

const setLevel = (userId, xp, level) => {
  data.levels[String(userId)] = { xp, level };
  save();
};

const getTicketByUser = (userId) => {
  const entry = Object.entries(data.tickets).find(([, value]) => value.userId === String(userId) && value.status === 'open');
  return entry ? { channelId: entry[0], ...entry[1] } : null;
};

const getTicketByChannel = (channelId) => {
  const value = data.tickets[String(channelId)];
  return value ? { channelId, ...value } : null;
};

const setTicket = (channelId, userId, status) => {
  data.tickets[String(channelId)] = { userId: String(userId), status };
  save();
};

const closeTicket = (channelId) => {
  if (data.tickets[String(channelId)]) {
    data.tickets[String(channelId)].status = 'closed';
    save();
  }
};

const reactionKey = (messageId, emoji) => `${messageId}:${emoji}`;

const setReactionRole = (messageId, emoji, roleId) => {
  data.reactionRoles[reactionKey(messageId, emoji)] = roleId;
  save();
};

const removeReactionRole = (messageId, emoji) => {
  delete data.reactionRoles[reactionKey(messageId, emoji)];
  save();
};

const getReactionRole = (messageId, emoji) => data.reactionRoles[reactionKey(messageId, emoji)] || null;

const getStatsMessageId = () => data.statsMessageId || null;

const setStatsMessageId = (messageId) => {
  data.statsMessageId = messageId;
  save();
};

const getInfoMessageId = () => data.infoMessageId || null;

const setInfoMessageId = (messageId) => {
  data.infoMessageId = messageId;
  save();
};

module.exports = {
  getLevel,
  setLevel,
  getTicketByUser,
  getTicketByChannel,
  setTicket,
  closeTicket,
  setReactionRole,
  removeReactionRole,
  getReactionRole,
  getStatsMessageId,
  setStatsMessageId,
  getInfoMessageId,
  setInfoMessageId,
  data
};
