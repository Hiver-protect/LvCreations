// Utilities Module - 40+ Fonctions Helper
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

// ==================== FORMATAGE ====================

const formatDuration = (ms) => {
  const seconds = Math.floor((ms / 1000) % 60);
  const minutes = Math.floor((ms / (1000 * 60)) % 60);
  const hours = Math.floor((ms / (1000 * 60 * 60)) % 24);
  const days = Math.floor(ms / (1000 * 60 * 60 * 24));
  
  if (days > 0) return `${days}j ${hours}h ${minutes}m`;
  if (hours > 0) return `${hours}h ${minutes}m ${seconds}s`;
  if (minutes > 0) return `${minutes}m ${seconds}s`;
  return `${seconds}s`;
};

const formatNumber = (num) => {
  return new Intl.NumberFormat('fr-FR').format(num);
};

const formatDate = (date, format = 'd/m/Y H:i') => {
  const d = new Date(date);
  return `<t:${Math.floor(d.getTime() / 1000)}:F>`;
};

const capitalize = (str) => {
  return str.charAt(0).toUpperCase() + str.slice(1).toLowerCase();
};

const truncate = (str, max = 100) => {
  return str.length > max ? str.slice(0, max - 3) + '...' : str;
};

const createBar = (current, max, length = 20, filled = '█', empty = '░') => {
  const percent = Math.min(100, (current / max) * 100);
  const filledCount = Math.round((length / 100) * percent);
  const emptyCount = length - filledCount;
  return `[${filled.repeat(filledCount)}${empty.repeat(emptyCount)}] ${percent.toFixed(1)}%`;
};

// ==================== VALIDATIONS ====================

const isValidUrl = (url) => {
  try {
    new URL(url);
    return true;
  } catch {
    return false;
  }
};

const isValidEmail = (email) => {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
};

const isValidHexColor = (hex) => {
  return /^#[0-9A-F]{6}$/i.test(hex);
};

const isValidDiscordId = (id) => {
  return /^\d{17,19}$/.test(String(id));
};

const isEmpty = (str) => {
  return !str || str.trim().length === 0;
};

// ==================== PERMISSIONS & CHECKS ====================

const hasPermission = (member, permission) => {
  return member.permissions.has(permission);
};

const canModerate = (member, target) => {
  if (!target) return false;
  return member.roles.highest.position > target.roles.highest.position;
};

const isAdmin = (member) => {
  return member.permissions.has('Administrator');
};

const isMod = (member, modRoleId) => {
  return member.roles.cache.has(modRoleId);
};

// ==================== CALCULS & MATH ====================

const getRandomElement = (arr) => {
  return arr[Math.floor(Math.random() * arr.length)];
};

const shuffle = (arr) => {
  const copy = [...arr];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
};

const getRandomInt = (min, max) => {
  return Math.floor(Math.random() * (max - min + 1)) + min;
};

const percentage = (part, total) => {
  return ((part / total) * 100).toFixed(2);
};

const calculateLevel = (xp) => {
  return Math.floor(xp / 100) + 1;
};

const calculateXpNeeded = (level) => {
  return level * 100;
};

// ==================== DISCORD UTILITIES ====================

const getMentionUserId = (str) => {
  const match = str.match(/^<@!?(\d+)>$/);
  return match ? match[1] : null;
};

const getRoleColor = (role) => {
  return role.color || 0x99AAB5;
};

const getStatus = (presence) => {
  const statuses = {
    'online': '🟢 En ligne',
    'idle': '🟡 Inactif',
    'dnd': '🔴 Ne pas déranger',
    'offline': '⚫ Hors ligne'
  };
  return statuses[presence?.status] || '⚫ Hors ligne';
};

const getStatusEmoji = (status) => {
  const emojis = { 'online': '🟢', 'idle': '🟡', 'dnd': '🔴', 'offline': '⚫' };
  return emojis[status] || '⚫';
};

const sortMembers = (members, by = 'joined') => {
  return members.sort((a, b) => {
    if (by === 'joined') return a.joinedTimestamp - b.joinedTimestamp;
    if (by === 'created') return a.user.createdTimestamp - b.user.createdTimestamp;
    return 0;
  });
};

const getTopMembers = (guild, limit = 10) => {
  return guild.members.cache
    .filter(m => !m.user.bot)
    .sort((a, b) => b.roles.cache.size - a.roles.cache.size)
    .first(limit);
};

// ==================== EMBEDS HELPERS ====================

const createMiniEmbed = (title, value, color = 0x3498DB) => {
  return new EmbedBuilder()
    .setTitle(title)
    .setDescription(value)
    .setColor(color)
    .setTimestamp();
};

const createTable = (data, maxLength = 1024) => {
  let table = '```\n';
  for (const [key, value] of Object.entries(data)) {
    table += `${key}: ${value}\n`;
  }
  table += '```';
  return table.length > maxLength ? table.slice(0, maxLength - 5) + '```' : table;
};

const createFields = (data) => {
  return Object.entries(data).map(([name, value]) => ({
    name,
    value: String(value),
    inline: true
  }));
};

const addFieldIfExists = (embed, name, value, inline = false) => {
  if (value) {
    embed.addFields({ name, value: String(value), inline });
  }
  return embed;
};

// ==================== CACHE & STORAGE ====================

const createCache = (ttl = 3600000) => {
  const cache = new Map();
  const timers = new Map();
  
  return {
    set: (key, value) => {
      if (timers.has(key)) clearTimeout(timers.get(key));
      cache.set(key, value);
      const timer = setTimeout(() => cache.delete(key), ttl);
      timers.set(key, timer);
    },
    get: (key) => cache.get(key),
    has: (key) => cache.has(key),
    delete: (key) => {
      cache.delete(key);
      if (timers.has(key)) clearTimeout(timers.get(key));
      timers.delete(key);
    },
    clear: () => {
      timers.forEach(t => clearTimeout(t));
      cache.clear();
      timers.clear();
    }
  };
};

// ==================== TIME & SCHEDULING ====================

const sleep = (ms) => new Promise(r => setTimeout(r, ms));

const debounce = (func, delay) => {
  let timeout;
  return (...args) => {
    clearTimeout(timeout);
    timeout = setTimeout(() => func(...args), delay);
  };
};

const throttle = (func, limit) => {
  let lastRun = 0;
  return (...args) => {
    const now = Date.now();
    if (now - lastRun >= limit) {
      func(...args);
      lastRun = now;
    }
  };
};

const isTimeInRange = (startHour, endHour) => {
  const now = new Date();
  const hour = now.getHours();
  return hour >= startHour && hour < endHour;
};

// ==================== STRING UTILITIES ====================

const removeMarkdown = (str) => {
  return str.replace(/[*_`~]/g, '');
};

const escapeMarkdown = (str) => {
  return str.replace(/[*_`~\\]/g, '\\$&');
};

const toUpperCase = (str) => str.toUpperCase();

const toLowerCase = (str) => str.toLowerCase();

const reverse = (str) => str.split('').reverse().join('');

const containsProfanity = (str, bannedWords = []) => {
  return bannedWords.some(word => str.toLowerCase().includes(word.toLowerCase()));
};

// ==================== ARRAY UTILITIES ====================

const unique = (arr) => [...new Set(arr)];

const chunk = (arr, size) => {
  const chunks = [];
  for (let i = 0; i < arr.length; i += size) {
    chunks.push(arr.slice(i, i + size));
  }
  return chunks;
};

const flatten = (arr) => arr.reduce((flat, toFlatten) => 
  flat.concat(Array.isArray(toFlatten) ? flatten(toFlatten) : toFlatten), []
);

const groupBy = (arr, key) => {
  return arr.reduce((result, obj) => {
    const group = obj[key];
    if (!result[group]) result[group] = [];
    result[group].push(obj);
    return result;
  }, {});
};

// ==================== ERROR HANDLING ====================

const tryCatch = async (fn) => {
  try {
    const result = await fn();
    return { success: true, data: result };
  } catch (error) {
    return { success: false, error: error.message };
  }
};

const safeSend = async (channel, content) => {
  try {
    return await channel.send(content);
  } catch (error) {
    console.error('Erreur envoi message:', error);
    return null;
  }
};

const safeEdit = async (message, content) => {
  try {
    return await message.edit(content);
  } catch (error) {
    console.error('Erreur edit message:', error);
    return null;
  }
};

const safeDelete = async (message, delay = 0) => {
  try {
    if (delay > 0) await sleep(delay);
    return await message.delete();
  } catch (error) {
    console.error('Erreur delete message:', error);
    return null;
  }
};

module.exports = {
  // Formatage
  formatDuration,
  formatNumber,
  formatDate,
  capitalize,
  truncate,
  createBar,
  
  // Validations
  isValidUrl,
  isValidEmail,
  isValidHexColor,
  isValidDiscordId,
  isEmpty,
  
  // Permissions
  hasPermission,
  canModerate,
  isAdmin,
  isMod,
  
  // Calculs
  getRandomElement,
  shuffle,
  getRandomInt,
  percentage,
  calculateLevel,
  calculateXpNeeded,
  
  // Discord
  getMentionUserId,
  getRoleColor,
  getStatus,
  getStatusEmoji,
  sortMembers,
  getTopMembers,
  
  // Embeds
  createMiniEmbed,
  createTable,
  createFields,
  addFieldIfExists,
  
  // Cache
  createCache,
  
  // Temps
  sleep,
  debounce,
  throttle,
  isTimeInRange,
  
  // Strings
  removeMarkdown,
  escapeMarkdown,
  toUpperCase,
  toLowerCase,
  reverse,
  containsProfanity,
  
  // Arrays
  unique,
  chunk,
  flatten,
  groupBy,
  
  // Erreurs
  tryCatch,
  safeSend,
  safeEdit,
  safeDelete
};
