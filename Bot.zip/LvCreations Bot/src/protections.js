// Module de protections avancées
const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');

const protectionSettings = new Map();

const getProtection = (guildId) => {
  if (!protectionSettings.has(guildId)) {
    protectionSettings.set(guildId, {
      antiSpam: { enabled: true, maxMessages: 5, timeWindow: 5000 },
      antiRaid: { enabled: true, maxJoins: 5, timeWindow: 10000, action: 'kick' },
      antiAds: { enabled: true },
      autoMod: { enabled: true },
      logging: { enabled: true, channelId: null },
      memberVerification: { enabled: false, roleId: null }
    });
  }
  return protectionSettings.get(guildId);
};

const createProtectionEmbed = (guildId) => {
  const settings = getProtection(guildId);
  
  const statusEmoji = (enabled) => enabled ? '🟢' : '🔴';
  
  return new EmbedBuilder()
    .setTitle('🛡️ Protections Actives')
    .setDescription('État de toutes les protections du serveur')
    .addFields(
      { 
        name: '🚨 Anti-Spam', 
        value: `${statusEmoji(settings.antiSpam.enabled)} ${settings.antiSpam.enabled ? 'Activé' : 'Désactivé'}\n\`${settings.antiSpam.maxMessages} messages en ${settings.antiSpam.timeWindow/1000}s\``, 
        inline: true 
      },
      { 
        name: '⚔️ Anti-Raid', 
        value: `${statusEmoji(settings.antiRaid.enabled)} ${settings.antiRaid.enabled ? 'Activé' : 'Désactivé'}\n\`${settings.antiRaid.maxJoins} joins en ${settings.antiRaid.timeWindow/1000}s\``, 
        inline: true 
      },
      { 
        name: '📢 Anti-Pub', 
        value: `${statusEmoji(settings.antiAds.enabled)} ${settings.antiAds.enabled ? 'Activé' : 'Désactivé'}`, 
        inline: true 
      },
      { 
        name: '🤖 AutoMod', 
        value: `${statusEmoji(settings.autoMod.enabled)} ${settings.autoMod.enabled ? 'Activé' : 'Désactivé'}`, 
        inline: true 
      },
      { 
        name: '📝 Logging', 
        value: `${statusEmoji(settings.logging.enabled)} ${settings.logging.enabled ? 'Activé' : 'Désactivé'}`, 
        inline: true 
      },
      { 
        name: '✅ Vérification', 
        value: `${statusEmoji(settings.memberVerification.enabled)} ${settings.memberVerification.enabled ? 'Activé' : 'Désactivé'}`, 
        inline: true 
      }
    )
    .setColor(0xFF6B6B)
    .setFooter({ text: 'Utilisez /settings pour modifier' })
    .setTimestamp();
};

module.exports = {
  getProtection,
  protectionSettings,
  createProtectionEmbed
};
