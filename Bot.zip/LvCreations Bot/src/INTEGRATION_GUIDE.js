/**
 * INTEGRATION GUIDE - Système de Captcha, Commandes et Settings
 * 
 * Ce fichier montre comment intégrer les nouveaux systèmes au bot principal
 * Incluez ces sections dans src/index.js
 */

// ============================================
// 1. IMPORTS DES NOUVEAUX MODULES
// ============================================

const captchaManager = require('./captcha');
const settingsManager = require('./settings');
const commandsData = require('./commands');
const { handleCaptcha, handleSettings } = require('./commandHandlers');

// ============================================
// 2. ENREGISTREMENT DES COMMANDES SLASH
// ============================================

const rest = new REST({ version: '10' }).setToken(config.DISCORD_TOKEN);

async function registerSlashCommands() {
  try {
    const commandData = commandsData.map(cmd => cmd.toJSON());
    
    console.log(`⏳ Enregistrement de ${commandData.length} commandes slash...`);
    
    await rest.put(
      Routes.applicationCommands(config.CLIENT_ID),
      { body: commandData }
    );
    
    console.log(`✅ ${commandData.length} commandes slash enregistrées!`);
  } catch (error) {
    console.error('❌ Erreur lors de l\'enregistrement des commandes:', error);
  }
}

// Appelez cette fonction au démarrage du bot
client.once('ready', () => {
  registerSlashCommands();
});

// ============================================
// 3. GESTIONNAIRE D'INTERACTIONS
// ============================================

client.on('interactionCreate', async (interaction) => {
  if (!interaction.isChatInputCommand()) return;

  try {
    // Captcha Commands
    await handleCaptcha(interaction, client);
    
    // Settings Commands
    await handleSettings(interaction, client);
    
    // Autres commandes...
    const { commandName } = interaction;
    
    if (commandName === 'ping') {
      const embed = new EmbedBuilder()
        .setColor('#5865F2')
        .setTitle('🏓 Pong!')
        .setDescription(`Ping du bot: ${Math.round(client.ws.ping)}ms`)
        .setTimestamp();
      
      await interaction.reply({ embeds: [embed] });
    }
    
  } catch (error) {
    console.error('Erreur lors de la gestion de l\'interaction:', error);
    
    const errorEmbed = new EmbedBuilder()
      .setColor('#F04747')
      .setTitle('❌ Erreur')
      .setDescription('Une erreur s\'est produite lors de l\'exécution de la commande.');
    
    if (interaction.replied || interaction.deferred) {
      await interaction.followUp({ embeds: [errorEmbed], ephemeral: true });
    } else {
      await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
    }
  }
});

// ============================================
// 4. CAPTCHA VERIFICATION ON MEMBER JOIN
// ============================================

client.on('guildMemberAdd', async (member) => {
  const { guild, user, id } = member;
  
  if (!settingsManager.getCaptchaEnabled(guild.id)) {
    console.log(`⏭️ Captcha désactivé pour ${guild.name}`);
    return;
  }
  
  try {
    // Envoyer un DM avec le captcha
    const captchaType = settingsManager.getCaptchaType(guild.id);
    const embed = captchaManager.createCaptchaEmbed(id, captchaType);
    const buttons = captchaManager.createCaptchaButtons();
    
    await user.send({
      content: `👋 Bienvenue sur **${guild.name}**! Veuillez compléter le captcha pour accéder au serveur.`,
      embeds: [embed],
      components: [buttons]
    });
    
    console.log(`✅ Captcha envoyé à ${user.tag}`);
    
    // Ajouter le rôle non vérifié
    const unverifiedRole = guild.roles.cache.get(
      settingsManager.getGuildSettings(guild.id).unverifiedRole
    );
    
    if (unverifiedRole) {
      await member.roles.add(unverifiedRole);
    }
    
  } catch (error) {
    console.error(`❌ Erreur lors de l\'envoi du captcha à ${user.tag}:`, error);
  }
});

// ============================================
// 5. CAPTCHA BUTTON INTERACTIONS
// ============================================

client.on('interactionCreate', async (interaction) => {
  if (!interaction.isButton()) return;
  
  if (interaction.customId === 'captcha_submit') {
    // Créer un modal de soumission
    const modal = new ModalBuilder()
      .setCustomId('captcha_modal')
      .setTitle('Captcha Verification')
      .addComponents(
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId('captcha_answer')
            .setLabel('Veuillez entrer votre réponse')
            .setStyle(TextInputStyle.Short)
            .setRequired(true)
            .setMaxLength(10)
        )
      );
    
    await interaction.showModal(modal);
  }
  
  else if (interaction.customId === 'captcha_refresh') {
    const captchaType = settingsManager.getCaptchaType(interaction.guildId);
    const embed = captchaManager.createCaptchaEmbed(interaction.user.id, captchaType);
    const buttons = captchaManager.createCaptchaButtons();
    
    await interaction.update({ embeds: [embed], components: [buttons] });
    
    await interaction.followUp({
      content: '🔄 Nouveau captcha généré!',
      ephemeral: true
    });
  }
});

// ============================================
// 6. CAPTCHA MODAL SUBMISSION
// ============================================

client.on('interactionCreate', async (interaction) => {
  if (!interaction.isModalSubmit()) return;
  
  if (interaction.customId === 'captcha_modal') {
    const answer = interaction.fields.getTextInputValue('captcha_answer');
    const userId = interaction.user.id;
    const guildId = interaction.guildId;
    const captchaType = settingsManager.getCaptchaType(guildId);
    
    // Vérifier la réponse
    const result = captchaManager.verifyCaptcha(userId, answer, captchaType);
    
    if (result.success) {
      // Marquer comme vérifiés
      captchaManager.markVerified(userId);
      
      // Ajouter le rôle vérifiés et retirer le rôle non vérifiés
      const guild = client.guilds.cache.get(guildId);
      const member = await guild.members.fetch(userId);
      const settings = settingsManager.getGuildSettings(guildId);
      
      if (settings.verifiedRole) {
        await member.roles.add(settings.verifiedRole);
      }
      if (settings.unverifiedRole) {
        await member.roles.remove(settings.unverifiedRole);
      }
      
      const successEmbed = new EmbedBuilder()
        .setColor('#43B581')
        .setTitle('✅ Vérification Réussie!')
        .setDescription(`Bienvenue sur **${guild.name}**! Vous avez accès au serveur.`)
        .setTimestamp();
      
      await interaction.reply({ embeds: [successEmbed], ephemeral: true });
      
      console.log(`✅ ${interaction.user.tag} vérifié sur ${guild.name}`);
      
    } else {
      const errorEmbed = new EmbedBuilder()
        .setColor('#F04747')
        .setTitle('❌ Réponse Incorrecte')
        .setDescription(result.message)
        .setTimestamp();
      
      await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
    }
  }
});

// ============================================
// 7. LOGGING ET MONITORING
// ============================================

// Afficher les stats du captcha régulièrement
setInterval(() => {
  const captchaStats = captchaManager.getStats();
  const settingsStats = settingsManager.getAllStats();
  
  console.log(`
    📊 STATISTIQUES:
    🔐 Captchas actifs: ${captchaStats.activeCount}
    👤 Utilisateurs vérifiés: ${captchaStats.verifiedCount}
    🖥️ Serveurs configurés: ${settingsStats.guilds}
  `);
}, 60000); // Chaque minute

// ============================================
// 8. COMMANDES ADMIN POUR LE RELOAD
// ============================================

const handleReloadCommand = async (interaction) => {
  if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
    return interaction.reply({
      content: '❌ Vous n\'avez pas la permission.',
      ephemeral: true
    });
  }
  
  try {
    await registerSlashCommands();
    
    const embed = new EmbedBuilder()
      .setColor('#43B581')
      .setTitle('✅ Rechargement Réussi')
      .setDescription('Les commandes slash ont été rechargées.')
      .setTimestamp();
    
    await interaction.reply({ embeds: [embed], ephemeral: true });
    
  } catch (error) {
    console.error('Erreur lors du rechargement:', error);
    await interaction.reply({
      content: '❌ Erreur lors du rechargement.',
      ephemeral: true
    });
  }
};

// ============================================
// NOTES IMPORTANTES
// ============================================

/*
 * 1. N'oubliez pas d'installer les dépendances:
 *    npm install discord.js
 * 
 * 2. Configurez les variables d'environnement (.env):
 *    DISCORD_TOKEN=votre_token
 *    CLIENT_ID=votre_client_id
 *    CAPTCHA_ENABLED=true
 *    CAPTCHA_CHANNEL_ID=id_du_canal
 *    UNVERIFIED_ROLE_ID=id_du_role
 *    VERIFIED_ROLE_ID=id_du_role
 * 
 * 3. Les données sont stockées dans data.json
 *    Assurez-vous que ce fichier est dans le répertoire racine
 * 
 * 4. Le dashboard web se trouve dans /web/dashboard.html
 *    Ouvrez-le dans votre navigateur pour gérer les paramètres
 * 
 * 5. Chaque serveur peut avoir ses propres paramètres
 *    Utilisez le guildId pour accéder aux settings
 * 
 * 6. Le captcha expire après 10 minutes (configurable)
 *    Les utilisateurs ont 5 tentatives maximum
 */

module.exports = {
  registerSlashCommands,
  handleReloadCommand,
  captchaManager,
  settingsManager
};
