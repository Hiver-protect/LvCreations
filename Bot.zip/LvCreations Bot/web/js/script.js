// Animation smooth scroll
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        const href = this.getAttribute('href');
        if (href !== '#') {
            e.preventDefault();
            const target = document.querySelector(href);
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        }
    });
});

// Active nav link
window.addEventListener('scroll', () => {
    let current = '';
    const sections = document.querySelectorAll('section');
    
    sections.forEach(section => {
        const sectionTop = section.offsetTop;
        if (pageYOffset >= sectionTop - 200) {
            current = section.getAttribute('id');
        }
    });

    document.querySelectorAll('.nav-menu a').forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('href').includes(current)) {
            link.classList.add('active');
        }
    });
});

// Animations on scroll
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -100px 0px'
};

const observer = new IntersectionObserver(function(entries) {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateY(0)';
        }
    });
}, observerOptions);

document.querySelectorAll('.feature-card, .command-item, .doc-card, .stat').forEach(el => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(20px)';
    el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
    observer.observe(el);
});

// Copy command to clipboard
document.querySelectorAll('.command h4').forEach(cmd => {
    cmd.style.cursor = 'pointer';
    cmd.addEventListener('click', function() {
        const text = this.textContent;
        navigator.clipboard.writeText(text).then(() => {
            const original = this.textContent;
            this.textContent = '✅ Copié!';
            setTimeout(() => {
                this.textContent = original;
            }, 2000);
        });
    });
});

// Dark mode toggle (optional)
const toggleDarkMode = () => {
    document.body.classList.toggle('light-mode');
    localStorage.setItem('darkMode', document.body.classList.contains('light-mode'));
};

// Load dark mode preference
if (localStorage.getItem('darkMode') === 'false') {
    document.body.classList.add('light-mode');
}

// Particle background effect
const createParticles = () => {
    const canvas = document.createElement('canvas');
    canvas.style.position = 'fixed';
    canvas.style.top = '0';
    canvas.style.left = '0';
    canvas.style.zIndex = '-1';
    canvas.style.opacity = '0.5';
    
    const ctx = canvas.getContext('2d');
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    
    const particles = [];
    
    class Particle {
        constructor() {
            this.x = Math.random() * canvas.width;
            this.y = Math.random() * canvas.height;
            this.size = Math.random() * 2 + 1;
            this.speedX = Math.random() * 0.5 - 0.25;
            this.speedY = Math.random() * 0.5 - 0.25;
        }
        
        update() {
            this.x += this.speedX;
            this.y += this.speedY;
            
            if (this.x > canvas.width) this.x = 0;
            if (this.x < 0) this.x = canvas.width;
            if (this.y > canvas.height) this.y = 0;
            if (this.y < 0) this.y = canvas.height;
        }
        
        draw() {
            ctx.fillStyle = 'rgba(88, 101, 242, 0.5)';
            ctx.beginPath();
            ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
            ctx.fill();
        }
    }
    
    for (let i = 0; i < 50; i++) {
        particles.push(new Particle());
    }
    
    const animate = () => {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        particles.forEach(p => {
            p.update();
            p.draw();
        });
        requestAnimationFrame(animate);
    };
    
    animate();
    document.body.appendChild(canvas);
    
    window.addEventListener('resize', () => {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
    });
};

// createParticles(); // Décommenter pour activer les particules

// ============================================
// COMMANDS PAGE - Search and Filter
// ============================================

document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('searchCommands');
    const filterButtons = document.querySelectorAll('.filter-btn');
    const categories = document.querySelectorAll('.commands-category');
    const commands = document.querySelectorAll('.command');
    const noResults = document.getElementById('noResults');

    // Search functionality
    if (searchInput) {
        searchInput.addEventListener('input', function(e) {
            const searchTerm = e.target.value.toLowerCase().trim();
            filterCommands(searchTerm, getCurrentCategory());
        });
    }

    // Filter buttons
    filterButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Update active button
            filterButtons.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');

            const category = this.getAttribute('data-category');
            const searchTerm = searchInput ? searchInput.value.toLowerCase().trim() : '';
            filterCommands(searchTerm, category);
        });
    });

    // Filter function
    function filterCommands(searchTerm, category) {
        let visibleCount = 0;

        categories.forEach(cat => {
            const catName = cat.getAttribute('data-category');
            const categoryCommands = cat.querySelectorAll('.command');
            let categoryHasVisible = false;

            categoryCommands.forEach(cmd => {
                const commandName = cmd.querySelector('h4').textContent.toLowerCase();
                const commandDesc = cmd.querySelector('p').textContent.toLowerCase();
                const commandData = cmd.getAttribute('data-command') || '';

                // Check if matches search
                const matchesSearch = !searchTerm || 
                    commandName.includes(searchTerm) || 
                    commandDesc.includes(searchTerm) ||
                    commandData.includes(searchTerm);

                // Check if matches category
                const matchesCategory = category === 'all' || catName === category;

                // Show/hide command
                if (matchesSearch && matchesCategory) {
                    cmd.classList.remove('hidden');
                    categoryHasVisible = true;
                    visibleCount++;
                } else {
                    cmd.classList.add('hidden');
                }
            });

            // Show/hide category
            if (categoryHasVisible && (category === 'all' || catName === category)) {
                cat.classList.remove('hidden');
            } else {
                cat.classList.add('hidden');
            }
        });

        // Show/hide no results message
        if (noResults) {
            if (visibleCount === 0) {
                noResults.classList.add('show');
            } else {
                noResults.classList.remove('show');
            }
        }
    }

    // Get current active category
    function getCurrentCategory() {
        const activeButton = document.querySelector('.filter-btn.active');
        return activeButton ? activeButton.getAttribute('data-category') : 'all';
    }

    // Add keyboard shortcut (Ctrl+K or Cmd+K) to focus search
    if (searchInput) {
        document.addEventListener('keydown', function(e) {
            if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
                e.preventDefault();
                searchInput.focus();
            }
        });
    }

    // Add stagger animation to commands
    commands.forEach((cmd, index) => {
        cmd.style.animationDelay = `${index * 0.05}s`;
    });
});

console.log('LvCreations Bot - Website loaded successfully!');
