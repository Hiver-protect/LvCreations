// Dashboard Navigation
document.querySelectorAll('.nav-link').forEach(link => {
    link.addEventListener('click', (e) => {
        e.preventDefault();
        const href = link.getAttribute('href');
        
        // Remove active class from all links and sections
        document.querySelectorAll('.nav-link').forEach(l => l.classList.remove('active'));
        document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
        
        // Add active class to clicked link and target section
        link.classList.add('active');
        if (href.startsWith('#')) {
            document.querySelector(href).classList.add('active');
            window.scrollTo(0, 0);
        }
    });
});

// Initialize with first section
document.addEventListener('DOMContentLoaded', () => {
    document.querySelector('.nav-link').classList.add('active');
    document.querySelector('.section').classList.add('active');
    updateDashboardStats();
    startStatsRefresh();
});

// Update Dashboard Stats
function updateDashboardStats() {
    // Simulate stats (dans une vraie app, cela viendrait de l'API)
    document.getElementById('botStatus').textContent = '🟢 En Ligne';
    document.getElementById('verifiedUsers').textContent = Math.floor(Math.random() * 500) + 100;
    document.getElementById('activeCaptchas').textContent = Math.floor(Math.random() * 20) + 5;
    document.getElementById('commandsExecuted').textContent = Math.floor(Math.random() * 1000) + 200;
    
    // Calculate uptime
    const now = new Date();
    const uptime = Math.floor(Math.random() * 30) + 1;
    document.getElementById('uptimeInfo').textContent = `✅ Bot en ligne depuis ${uptime} jours`;
    
    // Performance
    const latency = Math.floor(Math.random() * 100) + 50;
    document.getElementById('performanceInfo').textContent = `📊 Ping: ${latency}ms • CPU: Normal`;
    
    // Servers
    document.getElementById('serversCount').textContent = `🔗 ${Math.floor(Math.random() * 150) + 50} serveurs connectés`;
}

// Refresh stats every 30 seconds
function startStatsRefresh() {
    setInterval(updateDashboardStats, 30000);
}

// Captcha Settings Functions
document.getElementById('captchaStatus').addEventListener('change', function() {
    const label = document.getElementById('captchaStatusLabel');
    label.textContent = this.checked ? '✅ Activé' : '❌ Désactivé';
    label.style.color = this.checked ? 'var(--success)' : 'var(--danger)';
});

function saveCaptchaSettings() {
    const status = document.getElementById('captchaStatus').checked;
    const type = document.getElementById('captchaType').value;
    const expiry = document.getElementById('captchaExpiry').value;
    
    const settings = {
        captchaEnabled: status,
        captchaType: type,
        captchaExpiry: parseInt(expiry)
    };
    
    console.log('Captcha Settings Saved:', settings);
    
    // Simulate API call
    setTimeout(() => {
        showNotification('✅ Paramètres du captcha sauvegardés!', 'success');
    }, 300);
}

function testCaptcha() {
    const type = document.getElementById('captchaType').value;
    const preview = document.getElementById('captchaPreview');
    
    let html = '<div class="captcha-demo">';
    
    if (type === 'code') {
        const code = Math.floor(1000 + Math.random() * 9000);
        html += `<div class="captcha-code">${code}</div>`;
        html += '<p>Code Simple - Exemple</p>';
    } else if (type === 'math') {
        const num1 = Math.floor(Math.random() * 20) + 1;
        const num2 = Math.floor(Math.random() * 20) + 1;
        const ops = ['+', '-', '*'];
        const op = ops[Math.floor(Math.random() * ops.length)];
        html += `<div class="captcha-code">${num1} ${op} ${num2} = ?</div>`;
        html += '<p>Problème Mathématique - Exemple</p>';
    } else if (type === 'image') {
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        let code = '';
        for (let i = 0; i < 6; i++) {
            code += chars[Math.floor(Math.random() * chars.length)];
        }
        html += `<div class="captcha-code" style="font-size: 2.5rem;">${code}</div>`;
        html += '<p>Code Image - Exemple</p>';
    }
    
    html += '</div>';
    preview.innerHTML = html;
    
    showNotification('🧪 Captcha testé!', 'info');
}

// All Settings Functions
function saveAllSettings() {
    const settings = {
        prefix: document.getElementById('settingsPrefix').value,
        language: document.getElementById('settingsLanguage').value,
        timezone: document.getElementById('settingsTimezone').value,
        autoModeration: document.getElementById('settingsAutoMod').checked,
        antiRaid: document.getElementById('settingsAntiRaid').checked,
        antiSpam: document.getElementById('settingsAntiSpam').checked,
        levelSystem: document.getElementById('settingsLevelSystem').checked,
        musicFormat: document.getElementById('settingsMusicFormat').value
    };
    
    console.log('All Settings Saved:', settings);
    
    // Simulate API call
    setTimeout(() => {
        showNotification('✅ Tous les paramètres ont été sauvegardés!', 'success');
    }, 300);
}

function resetSettings() {
    if (confirm('⚠️ Êtes-vous sûr? Tous les paramètres seront réinitialisés.')) {
        document.getElementById('settingsPrefix').value = '/';
        document.getElementById('settingsLanguage').value = 'fr';
        document.getElementById('settingsTimezone').value = 'Europe/Paris';
        document.getElementById('settingsAutoMod').checked = true;
        document.getElementById('settingsAntiRaid').checked = true;
        document.getElementById('settingsAntiSpam').checked = true;
        document.getElementById('settingsLevelSystem').checked = true;
        document.getElementById('settingsMusicFormat').value = 'high';
        
        showNotification('🔄 Paramètres réinitialisés', 'info');
    }
}

// Notification System
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.style.cssText = `
        position: fixed;
        bottom: 20px;
        right: 20px;
        padding: 1rem 2rem;
        border-radius: 8px;
        font-weight: 600;
        z-index: 1000;
        animation: slideIn 0.3s ease;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
    `;
    
    if (type === 'success') {
        notification.style.backgroundColor = 'var(--success)';
    } else if (type === 'error') {
        notification.style.backgroundColor = 'var(--danger)';
    } else {
        notification.style.backgroundColor = 'var(--primary)';
    }
    
    notification.style.color = 'white';
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

// Add animation styles
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(400px);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOut {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(400px);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);

// Keyboard shortcuts
document.addEventListener('keydown', (e) => {
    // Alt + S to save settings
    if (e.altKey && e.key === 's') {
        e.preventDefault();
        saveAllSettings();
    }
    
    // Alt + R to reset settings
    if (e.altKey && e.key === 'r') {
        e.preventDefault();
        resetSettings();
    }
});

// Auto-save feature (optional)
let autoSaveTimer;
document.querySelectorAll('.form-input, .form-select, .toggle-switch input').forEach(el => {
    el.addEventListener('change', () => {
        clearTimeout(autoSaveTimer);
        autoSaveTimer = setTimeout(() => {
            // Auto-save logic here
        }, 2000);
    });
});
